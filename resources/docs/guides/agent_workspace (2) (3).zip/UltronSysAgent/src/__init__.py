"""
UltronSysAgent - Fully Autonomous AI Voice Assistant
Author: MiniMax Agent
"""

__version__ = "1.0.0"
__author__ = "MiniMax Agent"
__description__ = "Fully autonomous AI voice assistant for Windows 11"
