import os
import sys
import json
import time
import threading
import subprocess
import tkinter as tk
from tkinter import ttk, scrolledtext
import psutil
import speech_recognition as sr
import openai
import pyautogui
from PIL import Image, ImageTk
import pyttsx3
import pygame
from pygame import mixer
import math
import random

# Configuration
CONFIG_PATH = r"D:\ultron\config.json"
WAKE_WORDS = ["ultron", "hello", "speak", "ultra", "ultro", "alta"]
SYSTEM_ROLE = ("You are Ultron - an advanced AI system controller with full access. "
               "Respond concisely, execute commands when appropriate, and provide system insights.")
ICON_PATH = r"D:\ultron\icon.png"  # Replace with actual icon path

# Load configuration
def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            return json.load(f)
    return {"openai_api_key": "", "voice": "male", "hotkeys": {}}

# Save configuration
def save_config(config):
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=2)

# Initialize
config = load_config()
openai.api_key = config.get("openai_api_key", "")
pygame.init()
mixer.init()

class UltronAssistant:
    def __init__(self, root):
        self.root = root
        self.root.title("Ultron AI Assistant")
        self.root.geometry("1200x800")
        self.root.configure(bg='black')
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # System status
        self.cpu_usage = tk.StringVar()
        self.mem_usage = tk.StringVar()
        self.disk_usage = tk.StringVar()
        self.status = tk.StringVar(value="Status: Ready")
        
        # Animation variables
        self.animating = False
        self.mouth_open = False
        self.glow_phase = 0
        self.eye_glow = [100, 100]  # Left and right eye glow intensity
        
        # Initialize components
        self.create_gui()
        self.recognizer = sr.Recognizer()
        self.microphone = sr.Microphone()
        self.engine = pyttsx3.init()
        self.set_voice(config.get("voice", "male"))
        self.listening = False
        self.processing = False
        
        # Adjust for ambient noise
        with self.microphone as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=1)
        
        # Start monitoring
        self.update_system_stats()
        self.root.after(1000, self.update_system_stats)
        
        # Start listening thread
        self.listen_thread = threading.Thread(target=self.wake_word_detection, daemon=True)
        self.listen_thread.start()
        
        # Initialize hotkeys
        self.setup_hotkeys()
        
        # Start animation
        self.root.after(50, self.update_animation)
    
    def create_gui(self):
        # Create main frames
        main_frame = tk.Frame(self.root, bg='black')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Left panel - Ultron face
        left_frame = tk.Frame(main_frame, bg='black', width=400)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=False)
        
        # Canvas for Ultron face
        self.canvas = tk.Canvas(left_frame, bg='black', highlightthickness=0, width=400, height=500)
        self.canvas.pack(fill=tk.BOTH, expand=True, pady=(0, 20))
        
        # Draw static face elements
        self.draw_static_face()
        
        # System info panel
        info_frame = tk.LabelFrame(
            main_frame, 
            text="System Status", 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10, "bold"),
            relief=tk.FLAT
        )
        info_frame.pack(side=tk.RIGHT, fill=tk.X, pady=(0, 10))
        
        # System info labels
        tk.Label(
            info_frame, 
            text="CPU:", 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).grid(row=0, column=0, padx=5, pady=2, sticky=tk.W)
        
        tk.Label(
            info_frame, 
            textvariable=self.cpu_usage, 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).grid(row=0, column=1, padx=5, pady=2, sticky=tk.W)
        
        tk.Label(
            info_frame, 
            text="Memory:", 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).grid(row=1, column=0, padx=5, pady=2, sticky=tk.W)
        
        tk.Label(
            info_frame, 
            textvariable=self.mem_usage, 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).grid(row=1, column=1, padx=5, pady=2, sticky=tk.W)
        
        tk.Label(
            info_frame, 
            text="Disk:", 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).grid(row=2, column=0, padx=5, pady=2, sticky=tk.W)
        
        tk.Label(
            info_frame, 
            textvariable=self.disk_usage, 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).grid(row=2, column=1, padx=5, pady=2, sticky=tk.W)
        
        # Conversation panel
        conv_frame = tk.LabelFrame(
            main_frame, 
            text="Conversation", 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10, "bold"),
            relief=tk.FLAT
        )
        conv_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.conversation = scrolledtext.ScrolledText(
            conv_frame, 
            wrap=tk.WORD, 
            state=tk.DISABLED,
            bg='black',
            fg='#00ff00',
            insertbackground='#00ff00',
            font=("Courier New", 10),
            relief=tk.FLAT
        )
        self.conversation.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Control panel
        ctrl_frame = tk.Frame(main_frame, bg='black')
        ctrl_frame.pack(side=tk.RIGHT, fill=tk.X, pady=(0, 10))
        
        # Custom button style
        button_style = {
            'bg': '#111', 
            'fg': '#00ff00', 
            'activebackground': '#222',
            'activeforeground': '#00ff00',
            'font': ("Courier New", 10, "bold"),
            'relief': tk.FLAT,
            'bd': 1,
            'highlightthickness': 0,
            'padx': 10,
            'pady': 5
        }
        
        self.btn_listen = tk.Button(
            ctrl_frame, 
            text="Start Listening", 
            command=self.toggle_listening,
            **button_style
        )
        self.btn_listen.pack(side=tk.LEFT, padx=5)
        
        self.btn_config = tk.Button(
            ctrl_frame, 
            text="Configuration", 
            command=self.show_config,
            **button_style
        )
        self.btn_config.pack(side=tk.LEFT, padx=5)
        
        tk.Button(
            ctrl_frame, 
            text="Clear", 
            command=self.clear_conversation,
            **button_style
        ).pack(side=tk.LEFT, padx=5)
        
        tk.Button(
            ctrl_frame, 
            text="Execute Command", 
            command=self.execute_manual,
            **button_style
        ).pack(side=tk.LEFT, padx=5)
        
        # Status bar
        status_bar = tk.Frame(self.root, bg='black')
        status_bar.pack(fill=tk.X, padx=20, pady=(0, 10))
        
        tk.Label(
            status_bar, 
            textvariable=self.status, 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).pack(side=tk.LEFT)
        
        self.wake_light = tk.Canvas(
            status_bar, 
            width=20, 
            height=20, 
            bg="black",
            highlightthickness=0
        )
        self.wake_light.pack(side=tk.RIGHT, padx=10)
        
        # Draw status light
        self.status_light = self.wake_light.create_oval(5, 5, 15, 15, fill="red")
        
        # Set icon
        try:
            img = Image.open(ICON_PATH)
            img = img.resize((32, 32), Image.Resampling.LANCZOS)
            self.icon = ImageTk.PhotoImage(img)
            self.root.iconphoto(True, self.icon)
        except Exception as e:
            print(f"Error loading icon: {e}")
    
    def draw_static_face(self):
        # Clear canvas
        self.canvas.delete("all")
        
        # Draw head
        head_radius = 120
        head_x, head_y = 200, 200
        
        # Create glowing effect
        for i in range(10, 0, -1):
            alpha = int(255 * (1 - i/10))
            color = f"#{alpha:02x}ff{alpha:02x}"  # Red glow
            self.canvas.create_oval(
                head_x - head_radius - i*2, 
                head_y - head_radius - i*2,
                head_x + head_radius + i*2, 
                head_y + head_radius + i*2,
                outline=color,
                width=1
            )
        
        # Draw head
        self.canvas.create_oval(
            head_x - head_radius, 
            head_y - head_radius,
            head_x + head_radius, 
            head_y + head_radius,
            fill="#333",
            outline="#555"
        )
        
        # Draw decorative lines
        for i in range(8):
            angle = i * (360/8)
            rad = math.radians(angle)
            length = 80
            x1 = head_x + head_radius * math.cos(rad)
            y1 = head_y + head_radius * math.sin(rad)
            x2 = head_x + (head_radius + length) * math.cos(rad)
            y2 = head_y + (head_radius + length) * math.sin(rad)
            
            # Create glowing effect
            for j in range(3):
                self.canvas.create_line(
                    x1, y1, x2, y2,
                    fill="#ff0000",
                    width=1,
                    dash=(4, 4)
                )
        
        # Draw eyes
        eye_width = 30
        eye_height = 40
        eye_y = head_y - 20
        
        # Left eye
        self.left_eye = self.canvas.create_oval(
            head_x - 60 - eye_width/2, 
            eye_y - eye_height/2,
            head_x - 60 + eye_width/2, 
            eye_y + eye_height/2,
            fill="#111",
            outline="#555"
        )
        
        # Right eye
        self.right_eye = self.canvas.create_oval(
            head_x + 60 - eye_width/2, 
            eye_y - eye_height/2,
            head_x + 60 + eye_width/2, 
            eye_y + eye_height/2,
            fill="#111",
            outline="#555"
        )
        
        # Draw mouth
        self.update_mouth()
        
        # Create eye glows (initially hidden)
        eye_size = 15
        self.left_glow = self.canvas.create_oval(
            head_x - 60 - eye_size/2, 
            head_y - 20 - eye_size/2,
            head_x - 60 + eye_size/2, 
            head_y - 20 + eye_size/2,
            fill="#400000",  # Dark red
            outline=""
        )
        
        self.right_glow = self.canvas.create_oval(
            head_x + 60 - eye_size/2, 
            head_y - 20 - eye_size/2,
            head_x + 60 + eye_size/2, 
            head_y - 20 + eye_size/2,
            fill="#400000",  # Dark red
            outline=""
        )
    
    def update_mouth(self):
        head_x, head_y = 200, 200
        mouth_width = 120
        mouth_height = 20 if self.mouth_open else 5
        mouth_y = head_y + 60
        
        # Create or update mouth
        if hasattr(self, 'mouth'):
            self.canvas.coords(
                self.mouth,
                head_x - mouth_width/2, 
                mouth_y - mouth_height/2,
                head_x + mouth_width/2, 
                mouth_y + mouth_height/2
            )
        else:
            self.mouth = self.canvas.create_rectangle(
                head_x - mouth_width/2, 
                mouth_y - mouth_height/2,
                head_x + mouth_width/2, 
                mouth_y + mouth_height/2,
                fill="#111",
                outline="#555"
            )
    
    def update_animation(self):
        # Update glow phase
        self.glow_phase = (self.glow_phase + 0.1) % (2 * math.pi)
        glow_intensity = int(100 + 100 * abs(math.sin(self.glow_phase)))
        
        # Update status light
        if self.listening:
            self.wake_light.itemconfig(self.status_light, fill="green")
        else:
            self.wake_light.itemconfig(self.status_light, fill="red")
        
        # Update eye glow
        if self.animating:
            self.eye_glow[0] = random.randint(150, 255)
            self.eye_glow[1] = random.randint(150, 255)
        else:
            # Gentle pulsing when idle
            self.eye_glow[0] = int(100 + 50 * abs(math.sin(self.glow_phase)))
            self.eye_glow[1] = int(100 + 50 * abs(math.sin(self.glow_phase + math.pi/2)))
        
        # Update eyes
        left_color = f"#{self.eye_glow[0]:02x}0000"
        right_color = f"#{self.eye_glow[1]:02x}0000"
        
        self.canvas.itemconfig(self.left_glow, fill=left_color)
        self.canvas.itemconfig(self.right_glow, fill=right_color)
        
        # Update mouth
        self.update_mouth()
        
        # Schedule next animation update
        self.root.after(50, self.update_animation)
    
    def start_animation(self):
        self.animating = True
        self.mouth_open = True
    
    def stop_animation(self):
        self.animating = False
        self.mouth_open = False
    
    def set_voice(self, gender):
        voices = self.engine.getProperty('voices')
        if gender == "female" and len(voices) > 1:
            self.engine.setProperty('voice', voices[1].id)
        else:
            self.engine.setProperty('voice', voices[0].id)
        self.engine.setProperty('rate', 150)
    
    def update_system_stats(self):
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent()
            self.cpu_usage.set(f"{cpu_percent}%")
            
            # Memory usage
            mem = psutil.virtual_memory()
            self.mem_usage.set(f"{mem.percent}% ({mem.used//(1024**2)}MB/{mem.total//(1024**2)}MB)")
            
            # Disk usage
            disk = psutil.disk_usage('/')
            self.disk_usage.set(f"{disk.percent}% ({disk.used//(1024**3)}GB/{disk.total//(1024**3)}GB)")
            
            # Schedule next update
            self.root.after(2000, self.update_system_stats)
        except Exception as e:
            self.add_to_conversation(f"System Error: {str(e)}")
    
    def toggle_listening(self):
        self.listening = not self.listening
        if self.listening:
            self.btn_listen.config(text="Stop Listening", fg="#ff0000")
            self.status.set("Status: Listening...")
        else:
            self.btn_listen.config(text="Start Listening", fg="#00ff00")
            self.status.set("Status: Ready")
    
    def wake_word_detection(self):
        while True:
            if self.listening and not self.processing:
                try:
                    with self.microphone as source:
                        audio = self.recognizer.listen(source, phrase_time_limit=3)
                    
                    text = self.recognizer.recognize_google(audio).lower()
                    if any(word in text for word in WAKE_WORDS):
                        self.root.after(0, self.process_command)
                except (sr.UnknownValueError, sr.WaitTimeoutError):
                    pass
                except Exception as e:
                    self.add_to_conversation(f"Recognition Error: {str(e)}")
            time.sleep(1)
    
    def process_command(self):
        if self.processing:
            return
            
        self.processing = True
        self.status.set("Status: Processing...")
        
        try:
            # Start animation
            self.start_animation()
            
            # Listen for command
            self.add_to_conversation("Listening for command...")
            with self.microphone as source:
                audio = self.recognizer.listen(source, phrase_time_limit=10)
            command = self.recognizer.recognize_google(audio)
            self.add_to_conversation(f"You: {command}")
            
            # Process with AI
            response = self.ai_process(command)
            self.add_to_conversation(f"Ultron: {response}")
            self.speak(response)
            
        except sr.UnknownValueError:
            self.add_to_conversation("Could not understand audio")
        except sr.RequestError as e:
            self.add_to_conversation(f"Speech service error: {e}")
        except Exception as e:
            self.add_to_conversation(f"Processing error: {str(e)}")
        finally:
            self.processing = False
            self.stop_animation()
            self.status.set("Status: Ready" if not self.listening else "Status: Listening...")
    
    def ai_process(self, prompt):
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": SYSTEM_ROLE},
                    {"role": "user", "content": prompt}
                ],
                functions=self.get_functions(),
                function_call="auto"
            )
            
            response_message = response["choices"][0]["message"]
            
            # Handle function calls
            if response_message.get("function_call"):
                func_name = response_message["function_call"]["name"]
                args = json.loads(response_message["function_call"]["arguments"])
                
                # Execute function
                if hasattr(self, func_name):
                    result = getattr(self, func_name)(**args)
                    return f"Executed {func_name}. Result: {result}"
                else:
                    return f"Function {func_name} not implemented"
            else:
                return response_message["content"]
                
        except openai.error.OpenAIError as e:
            return f"AI error: {str(e)}"
        except Exception as e:
            return f"Processing error: {str(e)}"
    
    def get_functions(self):
        return [
            {
                "name": "execute_command",
                "description": "Execute system commands on the host machine",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "Terminal command to execute"
                        }
                    },
                    "required": ["command"]
                }
            },
            {
                "name": "open_application",
                "description": "Open an application on the system",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "app_name": {
                            "type": "string",
                            "description": "Name of application to open"
                        }
                    },
                    "required": ["app_name"]
                }
            },
            {
                "name": "system_info",
                "description": "Get detailed system information",
                "parameters": {"type": "object", "properties": {}}
            },
            {
                "name": "file_operation",
                "description": "Perform file operations",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "operation": {
                            "type": "string",
                            "enum": ["list", "read", "delete"],
                            "description": "Type of operation"
                        },
                        "path": {
                            "type": "string",
                            "description": "File path to operate on"
                        }
                    },
                    "required": ["operation", "path"]
                }
            }
        ]
    
    # System functions
    def execute_command(self, command):
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            return result.stdout.strip() or "Command executed"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def open_application(self, app_name):
        try:
            if sys.platform == "win32":
                os.startfile(app_name)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", app_name])
            else:
                subprocess.Popen([app_name])
            return f"Opened {app_name}"
        except Exception as e:
            return f"Error: {str(e)}"
    
    def system_info(self):
        cpu = psutil.cpu_percent()
        mem = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        net = psutil.net_io_counters()
        
        return (
            f"CPU: {cpu}% | "
            f"Memory: {mem.percent}% | "
            f"Disk: {disk.percent}% | "
            f"Network: Sent: {net.bytes_sent//(1024**2)}MB, Recv: {net.bytes_recv//(1024**2)}MB"
        )
    
    def file_operation(self, operation, path):
        try:
            if operation == "list":
                return ", ".join(os.listdir(path))
            elif operation == "read":
                with open(path, 'r') as f:
                    return f.read(1000)  # Read first 1000 characters
            elif operation == "delete":
                if os.path.isfile(path):
                    os.remove(path)
                    return f"Deleted {path}"
                else:
                    return "Path is not a file"
            else:
                return "Invalid operation"
        except Exception as e:
            return f"Error: {str(e)}"
    
    # GUI functions
    def speak(self, text):
        # Start animation in main thread
        self.start_animation()
        
        # Run speech in separate thread
        def speak_thread():
            self.engine.say(text)
            self.engine.runAndWait()
            self.stop_animation()
            
        threading.Thread(target=speak_thread, daemon=True).start()
    
    def add_to_conversation(self, text):
        self.conversation.config(state=tk.NORMAL)
        self.conversation.insert(tk.END, text + "\n")
        self.conversation.see(tk.END)
        self.conversation.config(state=tk.DISABLED)
    
    def clear_conversation(self):
        self.conversation.config(state=tk.NORMAL)
        self.conversation.delete(1.0, tk.END)
        self.conversation.config(state=tk.DISABLED)
    
    def execute_manual(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Execute Command")
        dialog.geometry("400x200")
        dialog.configure(bg='black')
        
        tk.Label(
            dialog, 
            text="Enter command:", 
            bg='black', 
            fg='#00ff00', 
            font=("Courier New", 10)
        ).pack(pady=5)
        
        cmd_entry = tk.Entry(
            dialog, 
            width=50, 
            bg='#111', 
            fg='#00ff00', 
            insertbackground='#00ff00',
            relief=tk.FLAT
        )
        cmd_entry.pack(pady=5)
        
        def execute():
            command = cmd_entry.get()
            if command:
                self.add_to_conversation(f"Manual command: {command}")
                result = self.execute_command(command)
                self.add_to_conversation(f"Result: {result}")
            dialog.destroy()
        
        # Button style
        button_style = {
            'bg': '#111', 
            'fg': '#00ff00', 
            'activebackground': '#222',
            'activeforeground': '#00ff00',
            'font': ("Courier New", 10),
            'relief': tk.FLAT,
            'bd': 1,
            'highlightthickness': 0,
            'padx': 10,
            'pady': 5
        }
        
        tk.Button(dialog, text="Execute", command=execute, **button_style).pack(pady=10)
        tk.Button(dialog, text="Cancel", command=dialog.destroy, **button_style).pack()
    
    def show_config(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Configuration")
        dialog.geometry("500x400")
        dialog.configure(bg='black')
        
        # Labels
        label_style = {
            'bg': 'black', 
            'fg': '#00ff00', 
            'font': ("Courier New", 10)
        }
        
        entry_style = {
            'bg': '#111', 
            'fg': '#00ff00', 
            'insertbackground': '#00ff00',
            'relief': tk.FLAT
        }
        
        tk.Label(dialog, text="OpenAI API Key:", **label_style).grid(row=0, column=0, padx=10, pady=5, sticky=tk.W)
        api_entry = tk.Entry(dialog, width=50, **entry_style)
        api_entry.grid(row=0, column=1, padx=10, pady=5)
        api_entry.insert(0, config.get("openai_api_key", ""))
        
        tk.Label(dialog, text="Voice:", **label_style).grid(row=1, column=0, padx=10, pady=5, sticky=tk.W)
        
        voice_var = tk.StringVar(value=config.get("voice", "male"))
        
        tk.Radiobutton(
            dialog, 
            text="Male", 
            variable=voice_var, 
            value="male",
            bg='black',
            fg='#00ff00',
            selectcolor='black',
            activebackground='black',
            activeforeground='#00ff00'
        ).grid(row=1, column=1, padx=10, pady=5, sticky=tk.W)
        
        tk.Radiobutton(
            dialog, 
            text="Female", 
            variable=voice_var, 
            value="female",
            bg='black',
            fg='#00ff00',
            selectcolor='black',
            activebackground='black',
            activeforeground='#00ff00'
        ).grid(row=2, column=1, padx=10, pady=5, sticky=tk.W)
        
        tk.Label(dialog, text="Hotkeys:", **label_style).grid(row=3, column=0, padx=10, pady=5, sticky=tk.W)
        
        hotkey_frame = tk.Frame(dialog, bg='black')
        hotkey_frame.grid(row=3, column=1, padx=10, pady=5, sticky=tk.W)
        
        hotkeys = config.get("hotkeys", {})
        hotkey_entries = {}
        
        for i, (name, key) in enumerate(hotkeys.items()):
            tk.Label(hotkey_frame, text=f"{name}:", **label_style).grid(row=i, column=0, padx=5, pady=2)
            entry = tk.Entry(hotkey_frame, width=15, **entry_style)
            entry.grid(row=i, column=1, padx=5, pady=2)
            entry.insert(0, key)
            hotkey_entries[name] = entry
        
        def save():
            config["openai_api_key"] = api_entry.get()
            config["voice"] = voice_var.get()
            config["hotkeys"] = {name: entry.get() for name, entry in hotkey_entries.items()}
            save_config(config)
            openai.api_key = config["openai_api_key"]
            self.set_voice(config["voice"])
            self.setup_hotkeys()
            dialog.destroy()
        
        # Button style
        button_style = {
            'bg': '#111', 
            'fg': '#00ff00', 
            'activebackground': '#222',
            'activeforeground': '#00ff00',
            'font': ("Courier New", 10),
            'relief': tk.FLAT,
            'bd': 1,
            'highlightthickness': 0,
            'padx': 10,
            'pady': 5
        }
        
        tk.Button(dialog, text="Save", command=save, **button_style).grid(row=10, column=1, pady=10, sticky=tk.E)
    
    def setup_hotkeys(self):
        # Clear any existing hotkey bindings
        for key in self.root.bind():
            if key.startswith("<<Hotkey"):
                self.root.unbind(key)
        
        # Register new hotkeys
        for name, key in config.get("hotkeys", {}).items():
            if key:
                self.root.bind(f"<{key}>", lambda e, n=name: self.handle_hotkey(n))
    
    def handle_hotkey(self, name):
        self.add_to_conversation(f"Hotkey activated: {name}")
        # Add custom hotkey functionality here
        if name == "listen_toggle":
            self.toggle_listening()
        elif name == "execute_command":
            self.execute_manual()
        # Add more hotkey actions as needed
    
    def on_close(self):
        self.root.destroy()
        sys.exit()

if __name__ == "__main__":
    root = tk.Tk()
    app = UltronAssistant(root)
    root.mainloop()