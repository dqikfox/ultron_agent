Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { messages, model = 'gpt-4', temperature = 0.7, max_tokens = 2048, conversationId } = await req.json();

        if (!messages || !Array.isArray(messages)) {
            throw new Error('Messages array is required');
        }

        // Get API key from environment
        const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
        const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!openaiApiKey) {
            throw new Error('OpenAI API key not configured');
        }

        // Get user from auth header
        const authHeader = req.headers.get('authorization');
        let userId = null;
        if (authHeader && supabaseServiceKey) {
            const token = authHeader.replace('Bearer ', '');
            const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'apikey': supabaseServiceKey
                }
            });
            if (userResponse.ok) {
                const userData = await userResponse.json();
                userId = userData.id;
            }
        }

        // Call OpenAI API
        const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${openaiApiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model,
                messages,
                temperature,
                max_tokens,
                stream: false
            })
        });

        if (!openaiResponse.ok) {
            const errorData = await openaiResponse.json();
            throw new Error(`OpenAI API error: ${errorData.error?.message || 'Unknown error'}`);
        }

        const data = await openaiResponse.json();
        const assistantMessage = data.choices[0]?.message;
        const tokensUsed = data.usage?.total_tokens || 0;

        // Calculate cost estimate (approximate GPT-4 pricing)
        const costPerToken = model.includes('gpt-4') ? 0.00003 : 0.000002;
        const costEstimate = tokensUsed * costPerToken;

        // Track usage if user is authenticated
        if (userId && supabaseServiceKey && supabaseUrl) {
            try {
                await fetch(`${supabaseUrl}/rest/v1/usage_tracking`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        provider: 'openai',
                        tokens_used: tokensUsed,
                        cost_estimate: costEstimate,
                        request_type: 'chat'
                    })
                });

                // Save assistant message to database if conversation ID provided
                if (conversationId && assistantMessage) {
                    await fetch(`${supabaseUrl}/rest/v1/messages`, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${supabaseServiceKey}`,
                            'apikey': supabaseServiceKey,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            conversation_id: conversationId,
                            role: 'assistant',
                            content: assistantMessage.content,
                            token_count: tokensUsed,
                            metadata: {
                                model,
                                provider: 'openai',
                                temperature,
                                finish_reason: data.choices[0]?.finish_reason
                            }
                        })
                    });
                }
            } catch (trackingError) {
                console.error('Usage tracking error:', trackingError);
            }
        }

        return new Response(JSON.stringify({
            data: {
                message: assistantMessage,
                usage: {
                    tokens: tokensUsed,
                    cost_estimate: costEstimate
                },
                model,
                provider: 'openai'
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('OpenAI chat error:', error);

        const errorResponse = {
            error: {
                code: 'OPENAI_CHAT_ERROR',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});