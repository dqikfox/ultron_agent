Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        const { text, voice_id = '21m00Tcm4TlvDq8ikWAM', model_id = 'eleven_monolingual_v1' } = await req.json();

        if (!text) {
            throw new Error('Text is required for TTS conversion');
        }

        // Get API key from environment
        const elevenlabsApiKey = Deno.env.get('ELEVENLABS_API_KEY');
        const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!elevenlabsApiKey) {
            throw new Error('ElevenLabs API key not configured');
        }

        // Get user from auth header for tracking
        const authHeader = req.headers.get('authorization');
        let userId = null;
        if (authHeader && supabaseServiceKey) {
            const token = authHeader.replace('Bearer ', '');
            const userResponse = await fetch(`${supabaseUrl}/auth/v1/user`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'apikey': supabaseServiceKey
                }
            });
            if (userResponse.ok) {
                const userData = await userResponse.json();
                userId = userData.id;
            }
        }

        // Call ElevenLabs TTS API
        const ttsResponse = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voice_id}`, {
            method: 'POST',
            headers: {
                'xi-api-key': elevenlabsApiKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text,
                model_id,
                voice_settings: {
                    stability: 0.5,
                    similarity_boost: 0.5
                }
            })
        });

        if (!ttsResponse.ok) {
            const errorText = await ttsResponse.text();
            throw new Error(`ElevenLabs API error: ${errorText}`);
        }

        const audioBuffer = await ttsResponse.arrayBuffer();
        const audioUint8Array = new Uint8Array(audioBuffer);

        // Convert to base64 for easier handling in frontend
        const base64Audio = btoa(String.fromCharCode(...audioUint8Array));

        // Estimate cost and character count
        const characterCount = text.length;
        const costPerCharacter = 0.00003;
        const costEstimate = characterCount * costPerCharacter;

        // Track usage if user is authenticated
        if (userId && supabaseServiceKey && supabaseUrl) {
            try {
                await fetch(`${supabaseUrl}/rest/v1/usage_tracking`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'apikey': supabaseServiceKey,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        user_id: userId,
                        provider: 'elevenlabs',
                        tokens_used: characterCount,
                        cost_estimate: costEstimate,
                        request_type: 'tts'
                    })
                });
            } catch (trackingError) {
                console.error('Usage tracking error:', trackingError);
            }
        }

        return new Response(JSON.stringify({
            data: {
                audio_base64: base64Audio,
                audio_type: 'audio/mpeg',
                usage: {
                    characters: characterCount,
                    cost_estimate: costEstimate
                },
                voice_id,
                model_id,
                provider: 'elevenlabs'
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('ElevenLabs TTS error:', error);

        const errorResponse = {
            error: {
                code: 'ELEVENLABS_TTS_ERROR',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});