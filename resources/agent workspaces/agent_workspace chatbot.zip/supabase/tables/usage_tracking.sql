CREATE TABLE usage_tracking (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    provider VARCHAR(20) NOT NULL,
    tokens_used INTEGER NOT NULL DEFAULT 0,
    cost_estimate DECIMAL(10,6) DEFAULT 0,
    request_type VARCHAR(20) NOT NULL CHECK (request_type IN ('chat',
    'tts',
    'transcription')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);