CREATE TABLE user_settings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL UNIQUE,
    preferred_provider VARCHAR(20) DEFAULT 'openai' CHECK (preferred_provider IN ('openai',
    'deepseek')),
    ui_theme VARCHAR(20) DEFAULT 'ultron' CHECK (ui_theme IN ('ultron',
    'dark',
    'light')),
    voice_enabled BOOLEAN DEFAULT false,
    auto_speech BOOLEAN DEFAULT false,
    animation_speed VARCHAR(10) DEFAULT 'normal' CHECK (animation_speed IN ('slow',
    'normal',
    'fast')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);