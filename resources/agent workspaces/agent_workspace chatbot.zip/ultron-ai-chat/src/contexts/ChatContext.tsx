import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { useAuth } from './AuthContext'
import { Conversation, Message, UserSettings, conversationApi, messageApi, userSettingsApi, aiProviderApi } from '../lib/supabase'

interface ChatContextType {
  conversations: Conversation[]
  currentConversation: Conversation | null
  messages: Message[]
  userSettings: UserSettings | null
  isLoading: boolean
  isProcessing: boolean
  createNewConversation: () => Promise<void>
  selectConversation: (conversation: Conversation) => Promise<void>
  sendMessage: (content: string) => Promise<void>
  updateSettings: (settings: Partial<UserSettings>) => Promise<void>
  deleteConversation: (id: string) => Promise<void>
  exportConversation: (conversation: Conversation) => string
}

const ChatContext = createContext<ChatContextType | undefined>(undefined)

export function useChat() {
  const context = useContext(ChatContext)
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider')
  }
  return context
}

interface ChatProviderProps {
  children: ReactNode
}

export function ChatProvider({ children }: ChatProviderProps) {
  const { user } = useAuth()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [userSettings, setUserSettings] = useState<UserSettings | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  // Load user data when user changes
  useEffect(() => {
    if (user) {
      loadUserData()
    } else {
      // Clear data when user logs out
      setConversations([])
      setCurrentConversation(null)
      setMessages([])
      setUserSettings(null)
    }
  }, [user])

  async function loadUserData() {
    if (!user) return

    try {
      setIsLoading(true)
      
      // Load conversations and user settings in parallel
      const [conversationsData, settingsData] = await Promise.all([
        conversationApi.getConversations(user.id),
        userSettingsApi.getUserSettings(user.id)
      ])

      setConversations(conversationsData)
      setUserSettings(settingsData)

      // Select the most recent conversation if available
      if (conversationsData.length > 0 && !currentConversation) {
        await selectConversation(conversationsData[0])
      }
    } catch (error) {
      console.error('Error loading user data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  async function createNewConversation() {
    if (!user) return

    try {
      const newConversation = await conversationApi.createConversation(user.id)
      setConversations(prev => [newConversation, ...prev])
      setCurrentConversation(newConversation)
      setMessages([])
    } catch (error) {
      console.error('Error creating conversation:', error)
    }
  }

  async function selectConversation(conversation: Conversation) {
    try {
      setIsLoading(true)
      setCurrentConversation(conversation)
      
      const messagesData = await messageApi.getMessages(conversation.id)
      setMessages(messagesData)
    } catch (error) {
      console.error('Error loading conversation:', error)
    } finally {
      setIsLoading(false)
    }
  }

  async function sendMessage(content: string) {
    if (!user || !currentConversation || isProcessing) return

    try {
      setIsProcessing(true)

      // Create user message
      const userMessage = await messageApi.createMessage({
        conversation_id: currentConversation.id,
        role: 'user',
        content,
        metadata: {},
        token_count: 0
      })

      setMessages(prev => [...prev, userMessage])

      // Prepare messages for AI API
      const conversationMessages = [...messages, userMessage].map(msg => ({
        role: msg.role,
        content: msg.content
      }))

      // Get provider from user settings or conversation settings
      const provider = userSettings?.preferred_provider || currentConversation.settings.provider || 'openai'
      const model = currentConversation.settings.model || 'gpt-4'
      const temperature = currentConversation.settings.temperature || 0.7
      const max_tokens = currentConversation.settings.max_tokens || 2048

      // Send to AI provider
      const response = await aiProviderApi.sendMessage(
        provider as 'openai' | 'deepseek',
        conversationMessages,
        currentConversation.id,
        { model, temperature, max_tokens }
      )

      if (response.data?.message) {
        // AI response was already saved in the edge function, so we need to refresh messages
        const updatedMessages = await messageApi.getMessages(currentConversation.id)
        setMessages(updatedMessages)

        // Update conversation title if it's the first message
        if (messages.length === 0) {
          const title = content.slice(0, 50) + (content.length > 50 ? '...' : '')
          await conversationApi.updateConversation(currentConversation.id, { title })
          setConversations(prev => 
            prev.map(conv => 
              conv.id === currentConversation.id 
                ? { ...conv, title }
                : conv
            )
          )
          setCurrentConversation(prev => prev ? { ...prev, title } : null)
        }
      }
    } catch (error) {
      console.error('Error sending message:', error)
    } finally {
      setIsProcessing(false)
    }
  }

  async function updateSettings(settings: Partial<UserSettings>) {
    if (!user) return

    try {
      const updatedSettings = await userSettingsApi.updateUserSettings(user.id, settings)
      setUserSettings(updatedSettings)
    } catch (error) {
      console.error('Error updating settings:', error)
    }
  }

  async function deleteConversation(id: string) {
    try {
      await conversationApi.deleteConversation(id)
      setConversations(prev => prev.filter(conv => conv.id !== id))
      
      if (currentConversation?.id === id) {
        setCurrentConversation(null)
        setMessages([])
      }
    } catch (error) {
      console.error('Error deleting conversation:', error)
    }
  }

  function exportConversation(conversation: Conversation): string {
    const conversationMessages = messages.filter(msg => msg.conversation_id === conversation.id)
    
    const exportData = {
      title: conversation.title,
      created_at: conversation.created_at,
      messages: conversationMessages.map(msg => ({
        role: msg.role,
        content: msg.content,
        timestamp: msg.created_at
      }))
    }

    return JSON.stringify(exportData, null, 2)
  }

  const value = {
    conversations,
    currentConversation,
    messages,
    userSettings,
    isLoading,
    isProcessing,
    createNewConversation,
    selectConversation,
    sendMessage,
    updateSettings,
    deleteConversation,
    exportConversation
  }

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  )
}