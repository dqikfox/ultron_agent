import { createClient } from '@supabase/supabase-js'

// CRITICAL: Never config supabase keys in env file
// Hardcode the actual Supabase URL and anon key
const supabaseUrl = 'https://jdkddrfloluhkytxdkkh.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Impka2RkcmZsb2x1aGt5dHhka2toIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE1ODYwNjksImV4cCI6MjA2NzE2MjA2OX0.nlMs2YRoC63AnpXTY9KuIFbebF_KjzgWXuxWcPBVX9A'

// Create Supabase client
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export interface Conversation {
  id: string
  user_id: string
  title: string
  created_at: string
  updated_at: string
  settings: {
    provider: string
    model: string
    temperature: number
    max_tokens: number
  }
}

export interface Message {
  id: string
  conversation_id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  created_at: string
  metadata: any
  token_count: number
}

export interface UserSettings {
  id: string
  user_id: string
  preferred_provider: 'openai' | 'deepseek'
  ui_theme: 'ultron' | 'dark' | 'light'
  voice_enabled: boolean
  auto_speech: boolean
  animation_speed: 'slow' | 'normal' | 'fast'
  created_at: string
  updated_at: string
}

export interface UsageTracking {
  id: string
  user_id: string
  provider: string
  tokens_used: number
  cost_estimate: number
  request_type: 'chat' | 'tts' | 'transcription'
  created_at: string
}

export interface UserProfile {
  id: string
  user_id: string
  full_name?: string
  avatar_url?: string
  created_at: string
  updated_at: string
}

// API functions for conversations
export const conversationApi = {
  async getConversations(userId: string) {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })

    if (error) throw error
    return data
  },

  async createConversation(userId: string, title?: string) {
    const { data, error } = await supabase
      .from('conversations')
      .insert({
        user_id: userId,
        title: title || 'New Conversation'
      })
      .select()
      .single()

    if (error) throw error
    return data
  },

  async updateConversation(id: string, updates: Partial<Conversation>) {
    const { data, error } = await supabase
      .from('conversations')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single()

    if (error) throw error
    return data
  },

  async deleteConversation(id: string) {
    const { error } = await supabase
      .from('conversations')
      .delete()
      .eq('id', id)

    if (error) throw error
  }
}

// API functions for messages
export const messageApi = {
  async getMessages(conversationId: string) {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })

    if (error) throw error
    return data
  },

  async createMessage(message: Omit<Message, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('messages')
      .insert(message)
      .select()
      .single()

    if (error) throw error
    return data
  }
}

// API functions for user settings
export const userSettingsApi = {
  async getUserSettings(userId: string) {
    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle()

    if (error) throw error
    return data
  },

  async updateUserSettings(userId: string, settings: Partial<UserSettings>) {
    const { data, error } = await supabase
      .from('user_settings')
      .upsert({
        user_id: userId,
        ...settings,
        updated_at: new Date().toISOString()
      })
      .select()
      .single()

    if (error) throw error
    return data
  }
}

// API functions for usage tracking
export const usageTrackingApi = {
  async getUserUsage(userId: string, days: number = 30) {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const { data, error } = await supabase
      .from('usage_tracking')
      .select('*')
      .eq('user_id', userId)
      .gte('created_at', startDate.toISOString())
      .order('created_at', { ascending: false })

    if (error) throw error
    return data
  },

  async getTotalCost(userId: string, days: number = 30) {
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const { data, error } = await supabase
      .from('usage_tracking')
      .select('cost_estimate')
      .eq('user_id', userId)
      .gte('created_at', startDate.toISOString())

    if (error) throw error
    
    const totalCost = data?.reduce((sum, record) => sum + (record.cost_estimate || 0), 0) || 0
    return totalCost
  }
}

// API functions for AI providers
export const aiProviderApi = {
  async sendMessage(
    provider: 'openai' | 'deepseek',
    messages: any[],
    conversationId?: string,
    options?: {
      model?: string
      temperature?: number
      max_tokens?: number
    }
  ) {
    const functionName = provider === 'openai' ? 'openai-chat' : 'deepseek-chat'
    
    const { data, error } = await supabase.functions.invoke(functionName, {
      body: {
        messages,
        conversationId,
        ...options
      }
    })

    if (error) throw error
    return data
  },

  async textToSpeech(text: string, options?: { voice_id?: string; model_id?: string }) {
    const { data, error } = await supabase.functions.invoke('elevenlabs-tts', {
      body: {
        text,
        ...options
      }
    })

    if (error) throw error
    return data
  }
}

// Auth helper functions
export const authApi = {
  async getCurrentUser() {
    const { data: { user }, error } = await supabase.auth.getUser()
    if (error) {
      console.error('Error getting user:', error)
      return null
    }
    return user
  },

  async signUp(email: string, password: string) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.protocol}//${window.location.host}/auth/callback`
      }
    })

    if (error) {
      console.error('Error signing up:', error.message)
      throw error
    }

    return data
  },

  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })

    if (error) {
      console.error('Error signing in:', error.message)
      throw error
    }

    return data
  },

  async signOut() {
    const { error } = await supabase.auth.signOut()
    if (error) {
      console.error('Error signing out:', error.message)
      throw error
    }
  }
}