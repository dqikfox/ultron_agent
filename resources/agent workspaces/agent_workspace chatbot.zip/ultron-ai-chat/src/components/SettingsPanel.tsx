import React, { useState, useEffect } from 'react'
import { useChat } from '../contexts/ChatContext'
import { useAuth } from '../contexts/AuthContext'
import { usageTrackingApi } from '../lib/supabase'

interface SettingsPanelProps {
  onClose: () => void
}

export function SettingsPanel({ onClose }: SettingsPanelProps) {
  const { user } = useAuth()
  const { userSettings, updateSettings, currentConversation } = useChat()
  const [localSettings, setLocalSettings] = useState(userSettings)
  const [usageData, setUsageData] = useState<any[]>([])
  const [totalCost, setTotalCost] = useState(0)
  const [activeTab, setActiveTab] = useState<'general' | 'provider' | 'usage'>('general')
  
  useEffect(() => {
    setLocalSettings(userSettings)
  }, [userSettings])
  
  useEffect(() => {
    if (user) {
      loadUsageData()
    }
  }, [user])
  
  const loadUsageData = async () => {
    if (!user) return
    
    try {
      const [usage, cost] = await Promise.all([
        usageTrackingApi.getUserUsage(user.id, 30),
        usageTrackingApi.getTotalCost(user.id, 30)
      ])
      setUsageData(usage)
      setTotalCost(cost)
    } catch (error) {
      console.error('Error loading usage data:', error)
    }
  }
  
  const handleSaveSettings = async () => {
    if (localSettings) {
      await updateSettings(localSettings)
      onClose()
    }
  }
  
  const getUsageByProvider = () => {
    const providerStats = usageData.reduce((acc, record) => {
      if (!acc[record.provider]) {
        acc[record.provider] = { tokens: 0, cost: 0, requests: 0 }
      }
      acc[record.provider].tokens += record.tokens_used
      acc[record.provider].cost += record.cost_estimate
      acc[record.provider].requests += 1
      return acc
    }, {})
    
    return Object.entries(providerStats).map(([provider, stats]: [string, any]) => ({
      provider,
      ...stats
    }))
  }
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg w-full max-w-2xl max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <h2 className="text-xl font-bold bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">
            Settings
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          {['general', 'provider', 'usage'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`flex-1 py-3 px-4 text-sm font-medium capitalize transition-colors ${
                activeTab === tab
                  ? 'text-blue-400 border-b-2 border-blue-400'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
        
        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === 'general' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  UI Theme
                </label>
                <select
                  value={localSettings?.ui_theme || 'ultron'}
                  onChange={(e) => setLocalSettings(prev => prev ? { ...prev, ui_theme: e.target.value as any } : null)}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="ultron">Ultron (Default)</option>
                  <option value="dark">Dark</option>
                  <option value="light">Light</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Animation Speed
                </label>
                <select
                  value={localSettings?.animation_speed || 'normal'}
                  onChange={(e) => setLocalSettings(prev => prev ? { ...prev, animation_speed: e.target.value as any } : null)}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="slow">Slow</option>
                  <option value="normal">Normal</option>
                  <option value="fast">Fast</option>
                </select>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="block text-sm font-medium text-gray-300">
                    Voice Enabled
                  </label>
                  <p className="text-sm text-gray-500 mt-1">
                    Enable text-to-speech for AI responses
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={localSettings?.voice_enabled || false}
                  onChange={(e) => setLocalSettings(prev => prev ? { ...prev, voice_enabled: e.target.checked } : null)}
                  className="w-5 h-5 text-blue-600 bg-gray-800 border-gray-600 rounded focus:ring-blue-500"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <label className="block text-sm font-medium text-gray-300">
                    Auto Speech
                  </label>
                  <p className="text-sm text-gray-500 mt-1">
                    Automatically play speech for responses
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={localSettings?.auto_speech || false}
                  onChange={(e) => setLocalSettings(prev => prev ? { ...prev, auto_speech: e.target.checked } : null)}
                  className="w-5 h-5 text-blue-600 bg-gray-800 border-gray-600 rounded focus:ring-blue-500"
                  disabled={!localSettings?.voice_enabled}
                />
              </div>
            </div>
          )}
          
          {activeTab === 'provider' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Preferred AI Provider
                </label>
                <select
                  value={localSettings?.preferred_provider || 'openai'}
                  onChange={(e) => setLocalSettings(prev => prev ? { ...prev, preferred_provider: e.target.value as any } : null)}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="openai">OpenAI (GPT-4)</option>
                  <option value="deepseek">DeepSeek</option>
                </select>
                <p className="text-sm text-gray-500 mt-2">
                  This will be used for new conversations. Existing conversations will continue using their selected provider.
                </p>
              </div>
              
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="font-medium text-gray-300 mb-3">Provider Comparison</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">OpenAI GPT-4:</span>
                    <span className="text-green-400">High quality, ~$0.03/1K tokens</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">DeepSeek:</span>
                    <span className="text-blue-400">Good quality, ~$0.001/1K tokens</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'usage' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-800 rounded-lg p-4">
                  <h3 className="font-medium text-gray-300 mb-2">Total Cost (30 days)</h3>
                  <p className="text-2xl font-bold text-green-400">
                    ${totalCost.toFixed(4)}
                  </p>
                </div>
                
                <div className="bg-gray-800 rounded-lg p-4">
                  <h3 className="font-medium text-gray-300 mb-2">Total Requests</h3>
                  <p className="text-2xl font-bold text-blue-400">
                    {usageData.length}
                  </p>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-300 mb-3">Usage by Provider</h3>
                <div className="space-y-3">
                  {getUsageByProvider().map((provider) => (
                    <div key={provider.provider} className="bg-gray-800 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-white capitalize">
                          {provider.provider}
                        </span>
                        <span className="text-sm text-gray-400">
                          {provider.requests} requests
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-400">Tokens:</span>
                          <span className="ml-2 text-white">{provider.tokens.toLocaleString()}</span>
                        </div>
                        <div>
                          <span className="text-gray-400">Cost:</span>
                          <span className="ml-2 text-white">${provider.cost.toFixed(4)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-gray-700">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSaveSettings}
            className="px-6 py-2 bg-gradient-to-r from-red-600 to-blue-600 hover:from-red-700 hover:to-blue-700 rounded-lg font-semibold transition-all duration-200"
          >
            Save Settings
          </button>
        </div>
      </div>
    </div>
  )
}