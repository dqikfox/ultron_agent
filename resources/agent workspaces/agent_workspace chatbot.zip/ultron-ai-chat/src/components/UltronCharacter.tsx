import React, { useEffect, useState } from 'react'
import { useChat } from '../contexts/ChatContext'

interface UltronCharacterProps {
  state: 'idle' | 'thinking' | 'speaking'
  className?: string
}

export function UltronCharacter({ state, className = '' }: UltronCharacterProps) {
  const [glowIntensity, setGlowIntensity] = useState(0.5)
  
  useEffect(() => {
    let interval: NodeJS.Timeout
    
    if (state === 'thinking') {
      // Pulsing animation for thinking
      interval = setInterval(() => {
        setGlowIntensity(prev => prev > 0.8 ? 0.3 : 0.9)
      }, 800)
    } else if (state === 'speaking') {
      // Rapid pulsing for speaking
      interval = setInterval(() => {
        setGlowIntensity(prev => prev > 0.7 ? 0.4 : 0.8)
      }, 300)
    } else {
      // Gentle breathing for idle
      interval = setInterval(() => {
        setGlowIntensity(prev => prev > 0.6 ? 0.4 : 0.7)
      }, 2000)
    }
    
    return () => clearInterval(interval)
  }, [state])
  
  const eyeGlow = state === 'thinking' ? '#ff0000' : state === 'speaking' ? '#ff4444' : '#cc0000'
  const bodyGlow = state === 'thinking' ? '#0080ff' : state === 'speaking' ? '#4499ff' : '#0066cc'
  
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* Background circuit pattern */}
      <div 
        className="absolute inset-0 opacity-20 bg-repeat"
        style={{
          backgroundImage: 'url(/images/circuit-background.jpg)',
          backgroundSize: '200px 200px',
          filter: `hue-rotate(200deg) brightness(${glowIntensity})`,
        }}
      />
      
      {/* Main Ultron figure container */}
      <div className="relative w-64 h-64 flex items-center justify-center">
        {/* Outer glow effect */}
        <div 
          className="absolute inset-0 rounded-full blur-xl"
          style={{
            background: `radial-gradient(circle, ${bodyGlow}${Math.floor(glowIntensity * 255).toString(16).padStart(2, '0')} 0%, transparent 70%)`,
            transform: `scale(${1 + glowIntensity * 0.2})`,
            transition: 'all 0.3s ease-in-out'
          }}
        />
        
        {/* Ultron body silhouette */}
        <div className="relative w-48 h-48 flex items-center justify-center">
          {/* Head */}
          <div className="relative">
            {/* Main head structure */}
            <div 
              className="w-24 h-28 rounded-t-full border-2 border-gray-400 bg-gradient-to-b from-gray-700 to-gray-900 relative"
              style={{
                boxShadow: `inset 0 0 20px ${bodyGlow}${Math.floor(glowIntensity * 128).toString(16).padStart(2, '0')}`,
              }}
            >
              {/* Eyes */}
              <div className="absolute top-8 left-1/2 transform -translate-x-1/2 flex space-x-3">
                <div 
                  className="w-3 h-3 rounded-full transition-all duration-300"
                  style={{
                    background: eyeGlow,
                    boxShadow: `0 0 ${10 + glowIntensity * 10}px ${eyeGlow}, inset 0 0 5px rgba(255,255,255,0.3)`,
                    transform: state === 'speaking' ? 'scale(1.2)' : 'scale(1)'
                  }}
                />
                <div 
                  className="w-3 h-3 rounded-full transition-all duration-300"
                  style={{
                    background: eyeGlow,
                    boxShadow: `0 0 ${10 + glowIntensity * 10}px ${eyeGlow}, inset 0 0 5px rgba(255,255,255,0.3)`,
                    transform: state === 'speaking' ? 'scale(1.2)' : 'scale(1)'
                  }}
                />
              </div>
              
              {/* Mouth/speaker grille */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
                <div className="flex space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <div 
                      key={i}
                      className="w-1 bg-gray-500 transition-all duration-200"
                      style={{
                        height: state === 'speaking' ? `${8 + Math.random() * 6}px` : '4px',
                        backgroundColor: state === 'speaking' ? eyeGlow : '#666'
                      }}
                    />
                  ))}
                </div>
              </div>
              
              {/* Head details/panels */}
              <div className="absolute top-4 left-2 w-2 h-4 bg-gray-600 border border-gray-500" />
              <div className="absolute top-4 right-2 w-2 h-4 bg-gray-600 border border-gray-500" />
            </div>
            
            {/* Neck */}
            <div className="w-12 h-8 bg-gradient-to-b from-gray-800 to-gray-900 border-x-2 border-gray-400 mx-auto" />
            
            {/* Chest */}
            <div 
              className="w-20 h-24 bg-gradient-to-b from-gray-800 to-gray-900 border-2 border-gray-400 mx-auto relative"
              style={{
                clipPath: 'polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)'
              }}
            >
              {/* Arc reactor style chest piece */}
              <div 
                className="absolute top-6 left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full border-2"
                style={{
                  borderColor: bodyGlow,
                  background: `radial-gradient(circle, ${bodyGlow}${Math.floor(glowIntensity * 200).toString(16).padStart(2, '0')} 0%, transparent 70%)`,
                  boxShadow: `0 0 ${15 + glowIntensity * 10}px ${bodyGlow}`,
                  transform: `scale(${0.8 + glowIntensity * 0.3})`
                }}
              >
                <div className="absolute inset-1 rounded-full border border-gray-300 opacity-50" />
              </div>
            </div>
          </div>
          
          {/* Arms */}
          <div className="absolute top-20 -left-8 w-6 h-16 bg-gradient-to-b from-gray-700 to-gray-900 border border-gray-400 transform rotate-12" />
          <div className="absolute top-20 -right-8 w-6 h-16 bg-gradient-to-b from-gray-700 to-gray-900 border border-gray-400 transform -rotate-12" />
        </div>
        
        {/* Energy particles effect */}
        {state === 'thinking' && (
          <div className="absolute inset-0">
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 rounded-full"
                style={{
                  background: bodyGlow,
                  boxShadow: `0 0 4px ${bodyGlow}`,
                  top: `${20 + Math.random() * 60}%`,
                  left: `${20 + Math.random() * 60}%`,
                  animation: `ultronParticle ${2 + Math.random() * 2}s ease-in-out infinite`,
                  animationDelay: `${Math.random() * 2}s`
                }}
              />
            ))}
          </div>
        )}
      </div>
      
      {/* Status indicator */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-2 bg-black bg-opacity-50 px-3 py-1 rounded-full">
        <div 
          className="w-2 h-2 rounded-full"
          style={{
            background: state === 'idle' ? '#00ff00' : state === 'thinking' ? '#ffff00' : '#ff6600',
            boxShadow: `0 0 8px ${state === 'idle' ? '#00ff00' : state === 'thinking' ? '#ffff00' : '#ff6600'}`
          }}
        />
        <span className="text-xs text-gray-300 font-mono uppercase tracking-wider">
          {state === 'idle' ? 'READY' : state === 'thinking' ? 'PROCESSING' : 'RESPONDING'}
        </span>
      </div>
      

    </div>
  )
}