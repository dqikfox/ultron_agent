import React, { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'

export function AuthForm() {
  const { signIn, signUp } = useAuth()
  const [isSignUp, setIsSignUp] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    
    try {
      if (isSignUp) {
        await signUp(email, password)
        setError('Please check your email for a confirmation link!')
      } else {
        await signIn(email, password)
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-black to-blue-900" />
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'url(/images/circuit-background.jpg)',
            backgroundSize: '400px 400px',
            animation: 'circuitFlow 20s linear infinite'
          }}
        />
      </div>
      
      {/* Ultron head in background */}
      <div className="absolute inset-0 flex items-center justify-center opacity-5">
        <img 
          src="/images/ultron-head.jpeg" 
          alt="Ultron" 
          className="w-96 h-96 object-contain filter grayscale"
        />
      </div>
      
      <div className="relative z-10 w-full max-w-md">
        <form onSubmit={handleSubmit} className="bg-gray-900 bg-opacity-95 backdrop-blur-sm rounded-lg p-8 shadow-2xl border border-gray-700">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent mb-2">
              ULTRON AI
            </h1>
            <p className="text-gray-400">
              {isSignUp ? 'Create your account' : 'Access the evolution'}
            </p>
          </div>
          
          {/* Error message */}
          {error && (
            <div className={`mb-4 p-3 rounded-lg text-sm ${
              error.includes('check your email') 
                ? 'bg-green-900 border border-green-700 text-green-200'
                : 'bg-red-900 border border-red-700 text-red-200'
            }`}>
              {error}
            </div>
          )}
          
          {/* Email field */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter your email"
            />
          </div>
          
          {/* Password field */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              placeholder="Enter your password"
            />
          </div>
          
          {/* Submit button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full p-3 bg-gradient-to-r from-red-600 to-blue-600 hover:from-red-700 hover:to-blue-700 disabled:from-gray-600 disabled:to-gray-700 rounded-lg font-semibold transition-all duration-200 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
          >
            {loading ? (
              <div className="w-5 h-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
            ) : (
              <span>{isSignUp ? 'Sign Up' : 'Sign In'}</span>
            )}
          </button>
          
          {/* Toggle sign up/in */}
          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp)
                setError('')
              }}
              className="text-blue-400 hover:text-blue-300 transition-colors"
            >
              {isSignUp 
                ? 'Already have an account? Sign in'
                : 'Need an account? Sign up'
              }
            </button>
          </div>
          
          {/* Demo info */}
          <div className="mt-6 p-3 bg-gray-800 border border-gray-700 rounded-lg">
            <p className="text-xs text-gray-400 text-center">
              Demo users can create accounts to test all features including conversation history and settings.
            </p>
          </div>
        </form>
      </div>
      

    </div>
  )
}