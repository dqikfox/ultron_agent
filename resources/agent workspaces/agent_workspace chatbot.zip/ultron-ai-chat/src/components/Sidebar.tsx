import React, { useState } from 'react'
import { useChat } from '../contexts/ChatContext'
import { useAuth } from '../contexts/AuthContext'
import { Conversation } from '../lib/supabase'

interface SidebarProps {
  onToggle: () => void
}

export function Sidebar({ onToggle }: SidebarProps) {
  const { signOut } = useAuth()
  const { 
    conversations, 
    currentConversation, 
    createNewConversation, 
    selectConversation, 
    deleteConversation,
    exportConversation 
  } = useChat()
  const [deletingId, setDeletingId] = useState<string | null>(null)
  
  const handleDeleteConversation = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (deletingId === id) {
      // Confirm delete
      await deleteConversation(id)
      setDeletingId(null)
    } else {
      // First click - show confirm state
      setDeletingId(id)
      setTimeout(() => setDeletingId(null), 3000) // Auto cancel after 3s
    }
  }
  
  const handleExportConversation = (conversation: Conversation, e: React.MouseEvent) => {
    e.stopPropagation()
    const exportData = exportConversation(conversation)
    const blob = new Blob([exportData], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${conversation.title.replace(/[^a-z0-9]/gi, '_')}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - date.getTime())
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    
    if (diffDays === 1) return 'Today'
    if (diffDays === 2) return 'Yesterday'
    if (diffDays <= 7) return `${diffDays - 1} days ago`
    return date.toLocaleDateString()
  }
  
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">
            Conversations
          </h2>
          <button
            onClick={onToggle}
            className="p-1 hover:bg-gray-800 rounded transition-colors lg:hidden"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <button
          onClick={createNewConversation}
          className="w-full p-3 bg-gradient-to-r from-red-600 to-blue-600 hover:from-red-700 hover:to-blue-700 rounded-lg font-semibold transition-all duration-200 flex items-center justify-center space-x-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          <span>New Conversation</span>
        </button>
      </div>
      
      {/* Conversations list */}
      <div className="flex-1 overflow-y-auto p-2">
        {conversations.length === 0 ? (
          <div className="text-center text-gray-500 mt-8">
            <p>No conversations yet.</p>
            <p className="text-sm mt-2">Start a new one to begin!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {conversations.map((conversation) => (
              <div
                key={conversation.id}
                onClick={() => selectConversation(conversation)}
                className={`p-3 rounded-lg cursor-pointer transition-all duration-200 group ${
                  currentConversation?.id === conversation.id
                    ? 'bg-gradient-to-r from-red-600/20 to-blue-600/20 border border-blue-500/30'
                    : 'hover:bg-gray-800 border border-transparent'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-white truncate">
                      {conversation.title}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">
                      {formatDate(conversation.updated_at)}
                    </p>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="text-xs bg-gray-700 px-2 py-1 rounded font-mono">
                        {conversation.settings.provider.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-500">
                        {conversation.settings.model}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {/* Export button */}
                    <button
                      onClick={(e) => handleExportConversation(conversation, e)}
                      className="p-1 hover:bg-gray-700 rounded transition-colors"
                      title="Export conversation"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                    </button>
                    
                    {/* Delete button */}
                    <button
                      onClick={(e) => handleDeleteConversation(conversation.id, e)}
                      className={`p-1 rounded transition-colors ${
                        deletingId === conversation.id
                          ? 'bg-red-600 hover:bg-red-700'
                          : 'hover:bg-gray-700'
                      }`}
                      title={deletingId === conversation.id ? 'Click again to confirm' : 'Delete conversation'}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Footer */}
      <div className="p-4 border-t border-gray-700">
        <button
          onClick={signOut}
          className="w-full p-2 text-left hover:bg-gray-800 rounded-lg transition-colors flex items-center space-x-2 text-gray-300"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
          </svg>
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  )
}