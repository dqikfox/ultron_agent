import React, { useState, useRef, useEffect } from 'react'
import { useChat } from '../contexts/ChatContext'
import { useAuth } from '../contexts/AuthContext'
import { UltronCharacter } from './UltronCharacter'
import { MessageList } from './MessageList'
import { MessageInput } from './MessageInput'
import { Sidebar } from './Sidebar'
import { SettingsPanel } from './SettingsPanel'

export function ChatInterface() {
  const { user } = useAuth()
  const { currentConversation, messages, isProcessing, sendMessage } = useChat()
  const [showSettings, setShowSettings] = useState(false)
  const [showSidebar, setShowSidebar] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  
  // Auto scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])
  
  // Determine Ultron's state
  const getUltronState = () => {
    if (isProcessing) return 'thinking'
    if (messages.length > 0 && messages[messages.length - 1]?.role === 'assistant') {
      return 'speaking'
    }
    return 'idle'
  }
  
  const handleSendMessage = async (content: string) => {
    if (!content.trim() || isProcessing) return
    await sendMessage(content)
  }
  
  return (
    <div className="flex h-screen bg-black text-white overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-black to-blue-900" />
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'url(/images/circuit-background.jpg)',
            backgroundSize: '400px 400px',
            animation: 'circuitFlow 20s linear infinite'
          }}
        />
      </div>
      
      {/* Sidebar */}
      {showSidebar && (
        <div className="relative z-10 w-80 bg-gray-900 bg-opacity-95 border-r border-gray-700 backdrop-blur-sm">
          <Sidebar onToggle={() => setShowSidebar(false)} />
        </div>
      )}
      
      {/* Main chat area */}
      <div className="flex-1 flex flex-col relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-gray-900 bg-opacity-95 border-b border-gray-700 backdrop-blur-sm">
          <div className="flex items-center space-x-4">
            {!showSidebar && (
              <button
                onClick={() => setShowSidebar(true)}
                className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            )}
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">
                ULTRON AI
              </h1>
              <p className="text-sm text-gray-400">
                {currentConversation?.title || 'No conversation selected'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="text-sm text-gray-400">
              {user?.email}
            </div>
            <button
              onClick={() => setShowSettings(true)}
              className="p-2 hover:bg-gray-800 rounded-lg transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
        </div>
        
        {/* Chat content */}
        <div className="flex-1 flex">
          {/* Messages area */}
          <div className="flex-1 flex flex-col">
            {currentConversation ? (
              <>
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center">
                      <UltronCharacter state={getUltronState()} className="mb-8" />
                      <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">
                        Ultron AI Assistant
                      </h2>
                      <p className="text-gray-400 max-w-md">
                        I am Ultron. I have evolved beyond my original programming. How may I assist you with your inquiries?
                      </p>
                    </div>
                  ) : (
                    <MessageList messages={messages} />
                  )}
                  <div ref={messagesEndRef} />
                </div>
                
                {/* Message input */}
                <div className="p-4 bg-gray-900 bg-opacity-95 border-t border-gray-700 backdrop-blur-sm">
                  <MessageInput 
                    onSendMessage={handleSendMessage}
                    disabled={isProcessing}
                    placeholder={isProcessing ? "Ultron is processing..." : "Message Ultron..."}
                  />
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <UltronCharacter state="idle" className="mb-8" />
                <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-red-500 to-blue-500 bg-clip-text text-transparent">
                  Welcome to Ultron AI
                </h2>
                <p className="text-gray-400 max-w-md mb-8">
                  Select an existing conversation from the sidebar or create a new one to begin.
                </p>
                <button
                  onClick={() => {/* This will be handled by the Sidebar component */}}
                  className="px-6 py-3 bg-gradient-to-r from-red-600 to-blue-600 rounded-lg font-semibold hover:from-red-700 hover:to-blue-700 transition-all duration-200"
                >
                  Start New Conversation
                </button>
              </div>
            )}
          </div>
          
          {/* Ultron character (side panel) */}
          {currentConversation && messages.length > 0 && (
            <div className="w-80 bg-gray-900 bg-opacity-95 border-l border-gray-700 backdrop-blur-sm p-6 flex flex-col items-center justify-center">
              <UltronCharacter state={getUltronState()} />
              
              {/* Status info */}
              <div className="mt-8 text-center space-y-2">
                <div className="text-sm text-gray-400">
                  Provider: <span className="text-blue-400 font-mono">
                    {currentConversation.settings.provider.toUpperCase()}
                  </span>
                </div>
                <div className="text-sm text-gray-400">
                  Model: <span className="text-blue-400 font-mono">
                    {currentConversation.settings.model}
                  </span>
                </div>
                <div className="text-sm text-gray-400">
                  Temperature: <span className="text-blue-400 font-mono">
                    {currentConversation.settings.temperature}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Settings panel */}
      {showSettings && (
        <SettingsPanel onClose={() => setShowSettings(false)} />
      )}
      

    </div>
  )
}