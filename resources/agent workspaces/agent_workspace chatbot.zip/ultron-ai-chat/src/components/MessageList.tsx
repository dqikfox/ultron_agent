import React from 'react'
import { Message } from '../lib/supabase'

interface MessageListProps {
  messages: Message[]
}

export function MessageList({ messages }: MessageListProps) {
  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
  
  const formatContent = (content: string) => {
    // Simple markdown-like formatting
    return content
      .split('\n')
      .map((line, index) => (
        <div key={index} className={line.trim() === '' ? 'h-4' : ''}>
          {line.trim() === '' ? '' : formatLine(line)}
        </div>
      ))
  }
  
  const formatLine = (line: string) => {
    // Bold text
    line = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic text
    line = line.replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Code blocks
    line = line.replace(/`(.*?)`/g, '<code class="bg-gray-800 px-1 py-0.5 rounded text-sm font-mono">$1</code>')
    
    return <span dangerouslySetInnerHTML={{ __html: line }} />
  }
  
  return (
    <div className="space-y-6">
      {messages.map((message) => (
        <div
          key={message.id}
          className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div
            className={`max-w-3xl rounded-lg p-4 ${
              message.role === 'user'
                ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white'
                : 'bg-gray-800 border border-gray-700 text-gray-100'
            }`}
          >
            {/* Message header */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {message.role === 'assistant' && (
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-red-500 to-blue-500 flex items-center justify-center">
                    <span className="text-xs font-bold text-white">U</span>
                  </div>
                )}
                <span className="font-semibold text-sm">
                  {message.role === 'user' ? 'You' : 'Ultron'}
                </span>
                {message.metadata?.provider && (
                  <span className="text-xs bg-gray-700 px-2 py-1 rounded font-mono">
                    {message.metadata.provider.toUpperCase()}
                  </span>
                )}
              </div>
              <span className="text-xs opacity-75">
                {formatTimestamp(message.created_at)}
              </span>
            </div>
            
            {/* Message content */}
            <div className="prose prose-invert max-w-none">
              {formatContent(message.content)}
            </div>
            
            {/* Message metadata */}
            {message.role === 'assistant' && message.token_count > 0 && (
              <div className="mt-2 pt-2 border-t border-gray-600 flex items-center justify-between text-xs opacity-75">
                <span>Tokens: {message.token_count}</span>
                {message.metadata?.model && (
                  <span>Model: {message.metadata.model}</span>
                )}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}