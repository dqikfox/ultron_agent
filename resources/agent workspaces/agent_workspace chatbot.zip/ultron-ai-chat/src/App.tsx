import React from 'react'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import { ChatProvider } from './contexts/ChatContext'
import { AuthForm } from './components/AuthForm'
import { ChatInterface } from './components/ChatInterface'
import './App.css'

function AppContent() {
  const { user, loading } = useAuth()
  
  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 animate-spin rounded-full border-4 border-blue-500 border-t-transparent mx-auto mb-4" />
          <p className="text-white text-lg">Initializing Ultron...</p>
        </div>
      </div>
    )
  }
  
  if (!user) {
    return <AuthForm />
  }
  
  return (
    <ChatProvider>
      <ChatInterface />
    </ChatProvider>
  )
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}

export default App