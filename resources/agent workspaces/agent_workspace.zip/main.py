def main():
    print("Hello from workspace!")


if __name__ == "__main__":
    main()
