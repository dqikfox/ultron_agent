export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  mode?: AssistantMode;
  attachments?: FileAttachment[];
}

export interface FileAttachment {
  id: string;
  name: string;
  type: string;
  size: number;
  url: string;
  uploadedAt: Date;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  mode: AssistantMode;
  createdAt: Date;
  updatedAt: Date;
}

export type AssistantMode = 
  | 'general'
  | 'creative'
  | 'technical'
  | 'productivity'
  | 'research';

export interface AssistantPersonality {
  id: AssistantMode;
  name: string;
  description: string;
  icon: string;
  color: string;
  systemPrompt: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  dueDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface Reminder {
  id: string;
  title: string;
  description?: string;
  datetime: Date;
  completed: boolean;
  createdAt: Date;
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'system';
  fontSize: 'small' | 'medium' | 'large';
  language: string;
  notifications: boolean;
  autoSave: boolean;
  defaultMode: AssistantMode;
}

export interface SearchResult {
  id: string;
  title: string;
  url: string;
  snippet: string;
  source: string;
}
