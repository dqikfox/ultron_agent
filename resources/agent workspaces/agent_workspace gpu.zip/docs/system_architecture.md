# System Architecture: GPU-Accelerated Vision Engine

## High-Level Data Flow

```
[Camera] -> [Web Browser (WebRTC)] -> [Real-time Video Stream]
         |
         V
[GPU-Accelerated OCR (PaddleOCR)] -> [Extracted Text]
         |
         V
[Ollama Server] -> [AI Model Inference] -> [Processed Text]
         |
         V
[Web Browser (Web Speech API)] -> [Voice Output]
```

## Components

*   **Web-based Interface:** A web application that captures video from the user's camera, displays the processed output, and handles voice interaction.
*   **Real-time Video Streaming:** WebRTC will be used to stream video from the client's web browser to the server.
*   **GPU-Accelerated OCR:** A Python-based service that receives the video stream, performs OCR using PaddleOCR with CUDA acceleration, and sends the extracted text to the Ollama server.
*   **Ollama Server:** An instance of the Ollama server running a suitable AI model for the desired task.
*   **Voice Interaction:** The Web Speech API will be used for both speech-to-text (STT) and text-to-speech (TTS) in the web browser.

## Communication

*   **WebRTC:** For real-time video streaming from the client to the server.
*   **WebSockets:** For real-time communication between the web browser and the server (e.g., sending OCR results, AI model output, and STT results).
*   **REST API:** For communication with the Ollama server.
