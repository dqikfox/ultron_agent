#!/usr/bin/env python3
"""
Dependency Installation Script for GPU-Accelerated Vision Engine

This script installs all required dependencies with proper version management.
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"\n📦 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        return False
    print(f"✅ Python {sys.version.split()[0]} is compatible")
    return True

def install_pytorch_cuda():
    """Install PyTorch with CUDA support"""
    print("\n🔧 Installing PyTorch with CUDA support for RTX 3050...")
    
    # PyTorch with CUDA 11.8 (compatible with RTX 3050)
    torch_command = (
        "pip install torch torchvision torchaudio "
        "--index-url https://download.pytorch.org/whl/cu118"
    )
    
    return run_command(torch_command, "PyTorch CUDA installation")

def install_paddleocr():
    """Install PaddleOCR with GPU support"""
    print("\n👁️  Installing PaddleOCR with GPU acceleration...")
    
    commands = [
        "pip install paddlepaddle-gpu",
        "pip install paddleocr"
    ]
    
    for cmd in commands:
        if not run_command(cmd, f"Running: {cmd}"):
            return False
    return True

def install_opencv_cuda():
    """Install OpenCV with CUDA support"""
    print("\n📹 Installing OpenCV with CUDA support...")
    
    # Note: This installs the pre-built OpenCV without CUDA
    # For full CUDA support, users need to build from source
    commands = [
        "pip install opencv-python",
        "pip install opencv-contrib-python"
    ]
    
    for cmd in commands:
        if not run_command(cmd, f"Running: {cmd}"):
            return False
    
    print("\n⚠️  Note: For full CUDA support in OpenCV, you may need to build from source.")
    print("   This installation provides basic OpenCV functionality.")
    return True

def install_core_dependencies():
    """Install core dependencies from requirements.txt"""
    print("\n⚙️  Installing core dependencies...")
    
    requirements_file = Path("requirements.txt")
    if not requirements_file.exists():
        print(f"❌ Requirements file not found: {requirements_file}")
        return False
    
    return run_command("pip install -r requirements.txt", "Core dependencies installation")

def verify_installations():
    """Verify that key packages are installed correctly"""
    print("\n🔍 Verifying installations...")
    
    packages_to_check = [
        ("fastapi", "FastAPI web framework"),
        ("uvicorn", "ASGI server"),
        ("opencv-python", "OpenCV computer vision"),
        ("paddleocr", "PaddleOCR text recognition"),
        ("elevenlabs", "ElevenLabs TTS"),
        ("aiohttp", "Async HTTP client"),
        ("websockets", "WebSocket support")
    ]
    
    all_good = True
    for package, description in packages_to_check:
        try:
            __import__(package.replace("-", "_"))
            print(f"✅ {description}: OK")
        except ImportError:
            print(f"❌ {description}: NOT FOUND")
            all_good = False
    
    return all_good

def check_gpu_support():
    """Check GPU and CUDA support"""
    print("\n🎮 Checking GPU support...")
    
    try:
        import cv2
        cuda_devices = cv2.cuda.getCudaEnabledDeviceCount()
        if cuda_devices > 0:
            print(f"✅ OpenCV CUDA devices: {cuda_devices}")
        else:
            print("⚠️  OpenCV: No CUDA devices found")
    except Exception as e:
        print(f"⚠️  OpenCV CUDA check failed: {e}")
    
    try:
        import torch
        if torch.cuda.is_available():
            device_count = torch.cuda.device_count()
            device_name = torch.cuda.get_device_name(0) if device_count > 0 else "Unknown"
            print(f"✅ PyTorch CUDA: {device_count} device(s) - {device_name}")
        else:
            print("⚠️  PyTorch: CUDA not available")
    except Exception as e:
        print(f"⚠️  PyTorch CUDA check failed: {e}")

def main():
    """Main installation process"""
    print("="*60)
    print("🚀 GPU-Accelerated Vision Engine - Dependency Installation")
    print("="*60)
    print("This script will install all required dependencies for:")
    print("• FastAPI backend with WebSocket support")
    print("• GPU-accelerated OCR (PaddleOCR + OpenCV)")
    print("• AI integration (Ollama client)")
    print("• Voice synthesis (ElevenLabs)")
    print("• All Python dependencies")
    print("="*60)
    
    # Check Python version
    if not check_python_version():
        return 1
    
    # Upgrade pip first
    if not run_command("python -m pip install --upgrade pip", "Upgrading pip"):
        print("⚠️  Failed to upgrade pip, continuing anyway...")
    
    # Install dependencies in order
    installation_steps = [
        (install_core_dependencies, "Installing core dependencies"),
        (install_pytorch_cuda, "Installing PyTorch with CUDA"),
        (install_opencv_cuda, "Installing OpenCV"),
        (install_paddleocr, "Installing PaddleOCR")
    ]
    
    failed_steps = []
    for step_func, step_name in installation_steps:
        print(f"\n🔧 {step_name}...")
        if not step_func():
            failed_steps.append(step_name)
            print(f"⚠️  {step_name} encountered issues")
    
    # Verify installations
    print("\n" + "="*60)
    if verify_installations():
        print("✅ All core packages installed successfully!")
    else:
        print("⚠️  Some packages may not be installed correctly")
    
    # Check GPU support
    check_gpu_support()
    
    # Final summary
    print("\n" + "="*60)
    if failed_steps:
        print("⚠️  Installation completed with some issues:")
        for step in failed_steps:
            print(f"   • {step}")
        print("\n💡 You may need to install these manually or check for conflicts.")
    else:
        print("🎉 Installation completed successfully!")
    
    print("\n📋 Next steps:")
    print("1. Set your ElevenLabs API key:")
    print("   export ELEVENLABS_API_KEY='your_api_key_here'")
    print("2. Ensure Ollama server is running on localhost:11434")
    print("3. Run the application: python run_server.py")
    print("="*60)
    
    return 0 if not failed_steps else 1

if __name__ == "__main__":
    sys.exit(main())