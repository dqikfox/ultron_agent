/**
 * GPU-Accelerated Vision Engine - Main Application
 */

class VisionEngineApp {
    constructor() {
        this.components = {
            websocket: null,
            camera: null,
            voice: null,
            ui: null,
            settings: null
        };
        
        this.state = {
            connected: false,
            ocrActive: false,
            voiceActive: false,
            currentModel: 'hermes3',
            theme: 'dark'
        };
        
        this.stats = {
            framesProcessed: 0,
            avgProcessingTime: 0,
            errorCount: 0,
            totalLatency: 0
        };
        
        this.init();
    }
    
    async init() {
        try {
            console.log('Initializing GPU Vision Engine...');
            
            // Initialize UI first
            this.components.ui = new UIManager(this);
            
            // Initialize WebSocket connection
            this.components.websocket = new WebSocketManager(this);
            await this.components.websocket.connect();
            
            // Initialize camera system
            this.components.camera = new CameraManager(this);
            
            // Initialize voice system
            this.components.voice = new VoiceManager(this);
            await this.components.voice.init();
            
            // Initialize settings
            this.components.settings = new SettingsManager(this);
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Start status updates
            this.startStatusUpdates();
            
            console.log('GPU Vision Engine initialized successfully!');
            this.showNotification('System initialized successfully', 'success');
            
        } catch (error) {
            console.error('Failed to initialize application:', error);
            this.showNotification('Failed to initialize system', 'error');
        }
    }
    
    setupEventListeners() {
        // Camera controls
        document.getElementById('start-camera-btn').addEventListener('click', () => {
            this.startCamera();
        });
        
        document.getElementById('stop-camera-btn').addEventListener('click', () => {
            this.stopCamera();
        });
        
        document.getElementById('screen-capture-btn').addEventListener('click', () => {
            this.captureScreen();
        });
        
        // Chat input
        document.getElementById('chat-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });
        
        document.getElementById('send-btn').addEventListener('click', () => {
            this.sendMessage();
        });
        
        // Voice controls
        document.getElementById('voice-toggle').addEventListener('mousedown', () => {
            this.components.voice.startListening();
        });
        
        document.getElementById('voice-toggle').addEventListener('mouseup', () => {
            this.components.voice.stopListening();
        });
        
        document.getElementById('voice-mode-toggle').addEventListener('click', () => {
            this.components.voice.toggleMode();
        });
        
        // Quick commands
        document.querySelectorAll('.quick-cmd').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const command = e.target.dataset.command;
                this.executeCommand(command);
            });
        });
        
        // Model selection
        document.getElementById('model-select').addEventListener('change', (e) => {
            this.changeModel(e.target.value);
        });
        
        document.getElementById('refresh-models-btn').addEventListener('click', () => {
            this.refreshModels();
        });
        
        // Settings and controls
        document.getElementById('confidence-slider').addEventListener('input', (e) => {
            this.updateOCRSettings({ confidence: parseFloat(e.target.value) });
        });
        
        document.getElementById('frame-skip-slider').addEventListener('input', (e) => {
            this.updateOCRSettings({ frameSkip: parseInt(e.target.value) });
        });
        
        document.getElementById('overlay-toggle').addEventListener('click', () => {
            this.components.camera.toggleOverlay();
        });
        
        // Action buttons
        document.getElementById('capture-frame-btn').addEventListener('click', () => {
            this.captureFrame();
        });
        
        document.getElementById('clear-chat-btn').addEventListener('click', () => {
            this.clearChat();
        });
        
        document.getElementById('export-results-btn').addEventListener('click', () => {
            this.exportResults();
        });
        
        // Theme toggle
        document.getElementById('theme-toggle').addEventListener('click', () => {
            this.toggleTheme();
        });
    }
    
    async startCamera() {
        try {
            await this.components.camera.start();
            this.state.ocrActive = true;
            this.updateUI();
            
            // Start OCR processing
            this.components.websocket.send({
                type: 'start_ocr',
                config: {
                    fps: 30,
                    frame_skip: parseInt(document.getElementById('frame-skip-slider').value),
                    camera_index: 0
                }
            });
            
            this.showNotification('Camera started successfully', 'success');
        } catch (error) {
            console.error('Failed to start camera:', error);
            this.showNotification('Failed to start camera', 'error');
        }
    }
    
    async stopCamera() {
        try {
            this.components.camera.stop();
            this.state.ocrActive = false;
            this.updateUI();
            
            // Stop OCR processing
            this.components.websocket.send({
                type: 'stop_ocr'
            });
            
            this.showNotification('Camera stopped', 'info');
        } catch (error) {
            console.error('Failed to stop camera:', error);
            this.showNotification('Failed to stop camera', 'error');
        }
    }
    
    async captureScreen() {
        try {
            await this.components.camera.captureScreen();
            this.showNotification('Screen capture started', 'info');
        } catch (error) {
            console.error('Screen capture failed:', error);
            this.showNotification('Screen capture failed', 'error');
        }
    }
    
    sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (message) {
            this.addMessage('user', message);
            
            this.components.websocket.send({
                type: 'process_text',
                text: message
            });
            
            input.value = '';
        }
    }
    
    executeCommand(command) {
        this.addMessage('user', command);
        
        this.components.websocket.send({
            type: 'voice_command',
            command: command
        });
    }
    
    changeModel(modelName) {
        this.state.currentModel = modelName;
        
        this.components.websocket.send({
            type: 'change_model',
            model: modelName
        });
        
        this.showNotification(`Switched to model: ${modelName}`, 'info');
    }
    
    refreshModels() {
        this.components.websocket.send({
            type: 'get_models'
        });
    }
    
    updateOCRSettings(settings) {
        if (settings.confidence) {
            document.getElementById('confidence-value').textContent = settings.confidence.toFixed(1);
        }
        
        if (settings.frameSkip) {
            document.getElementById('frame-skip-value').textContent = settings.frameSkip;
        }
        
        // Send settings to backend if OCR is active
        if (this.state.ocrActive) {
            this.components.websocket.send({
                type: 'update_ocr_settings',
                settings: settings
            });
        }
    }
    
    captureFrame() {
        this.components.websocket.send({
            type: 'capture_frame'
        });
    }
    
    clearChat() {
        const chatMessages = document.getElementById('chat-messages');
        chatMessages.innerHTML = `
            <div class="welcome-message">
                <div class="message-content">
                    <h3>Chat Cleared</h3>
                    <p>Start a new conversation with the AI.</p>
                </div>
            </div>
        `;
    }
    
    exportResults() {
        // Collect current session data
        const data = {
            timestamp: new Date().toISOString(),
            stats: this.stats,
            settings: this.components.settings.getSettings(),
            messages: this.getChatHistory()
        };
        
        // Download as JSON
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `vision_engine_export_${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.showNotification('Results exported successfully', 'success');
    }
    
    toggleTheme() {
        const body = document.body;
        const currentTheme = body.classList.contains('theme-dark') ? 'dark' : 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        body.classList.remove(`theme-${currentTheme}`);
        body.classList.add(`theme-${newTheme}`);
        
        this.state.theme = newTheme;
        localStorage.setItem('theme', newTheme);
        
        // Update theme toggle icon
        const themeIcon = document.querySelector('#theme-toggle i');
        themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
    
    addMessage(sender, content, type = 'text') {
        const chatMessages = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        if (type === 'ocr') {
            contentDiv.innerHTML = `
                <strong>OCR Detected:</strong><br>
                ${content}
            `;
            messageDiv.className = 'message ocr';
        } else {
            contentDiv.textContent = content;
        }
        
        messageDiv.appendChild(contentDiv);
        chatMessages.appendChild(messageDiv);
        
        // Auto-scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    addStreamingMessage(content) {
        const chatMessages = document.getElementById('chat-messages');
        let lastMessage = chatMessages.lastElementChild;
        
        // Check if last message is from assistant and still being streamed
        if (!lastMessage || !lastMessage.classList.contains('assistant') || 
            !lastMessage.querySelector('.streaming')) {
            // Create new streaming message
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message assistant';
            
            const contentDiv = document.createElement('div');
            contentDiv.className = 'message-content streaming';
            contentDiv.textContent = content;
            
            messageDiv.appendChild(contentDiv);
            chatMessages.appendChild(messageDiv);
        } else {
            // Append to existing streaming message
            const contentDiv = lastMessage.querySelector('.message-content');
            contentDiv.textContent += content;
        }
        
        // Auto-scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    finishStreamingMessage() {
        const chatMessages = document.getElementById('chat-messages');
        const lastMessage = chatMessages.lastElementChild;
        
        if (lastMessage && lastMessage.classList.contains('assistant')) {
            const contentDiv = lastMessage.querySelector('.message-content');
            if (contentDiv) {
                contentDiv.classList.remove('streaming');
            }
        }
    }
    
    getChatHistory() {
        const messages = [];
        const messageElements = document.querySelectorAll('.message');
        
        messageElements.forEach(msg => {
            if (!msg.classList.contains('welcome-message')) {
                const sender = msg.classList.contains('user') ? 'user' : 
                              msg.classList.contains('assistant') ? 'assistant' : 'system';
                const content = msg.querySelector('.message-content').textContent;
                messages.push({ sender, content, timestamp: Date.now() });
            }
        });
        
        return messages;
    }
    
    updateStats(newStats) {
        Object.assign(this.stats, newStats);
        this.updateUI();
    }
    
    updateUI() {
        // Update connection status indicators
        this.updateConnectionStatus();
        
        // Update button states
        const startBtn = document.getElementById('start-camera-btn');
        const stopBtn = document.getElementById('stop-camera-btn');
        
        startBtn.disabled = this.state.ocrActive;
        stopBtn.disabled = !this.state.ocrActive;
        
        // Update status displays
        this.updateStatusDisplays();
    }
    
    updateConnectionStatus() {
        const wsStatus = document.getElementById('websocket-status');
        const ollamaStatus = document.getElementById('ollama-status');
        const gpuStatus = document.getElementById('gpu-status');
        
        wsStatus.className = `status-indicator ${this.state.connected ? 'connected' : 'disconnected'}`;
        
        // These will be updated via WebSocket messages
    }
    
    updateStatusDisplays() {
        // Update performance metrics
        document.getElementById('fps-display').textContent = 
            this.stats.avgProcessingTime > 0 ? (1000 / this.stats.avgProcessingTime).toFixed(1) : '0';
        
        document.getElementById('processing-time').textContent = 
            `${this.stats.avgProcessingTime.toFixed(0)}ms`;
        
        document.getElementById('total-latency').textContent = 
            `${this.stats.totalLatency.toFixed(0)}ms`;
        
        document.getElementById('throughput').textContent = 
            `${(this.stats.framesProcessed / 60).toFixed(1)}fps`;
        
        document.getElementById('error-count').textContent = this.stats.errorCount;
    }
    
    startStatusUpdates() {
        setInterval(() => {
            if (this.state.connected) {
                this.components.websocket.send({
                    type: 'get_status'
                });
            }
        }, 2000);
    }
    
    showNotification(message, type = 'info') {
        // Remove existing notifications
        const existing = document.querySelector('.notification');
        if (existing) {
            existing.remove();
        }
        
        // Create new notification
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Show with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Auto-remove after 3 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // WebSocket message handlers
    onWebSocketMessage(data) {
        switch (data.type) {
            case 'ocr_result':
                this.handleOCRResult(data.data);
                break;
            case 'ai_response_chunk':
                this.addStreamingMessage(data.chunk);
                break;
            case 'ai_processing_started':
                this.addMessage('system', 'AI is processing...');
                break;
            case 'tts_ready':
                this.handleTTSReady(data.audio_url, data.text);
                break;
            case 'models_list':
                this.updateModelsList(data.models);
                break;
            case 'system_status':
                this.handleSystemStatus(data.status);
                break;
            case 'voice_command_executed':
                this.handleVoiceCommand(data);
                break;
            case 'error':
                this.showNotification(data.message, 'error');
                this.stats.errorCount++;
                break;
        }
    }
    
    handleOCRResult(result) {
        if (result.ocr_results && result.ocr_results.length > 0) {
            const extractedText = result.ocr_results.map(r => r.text).join(' ');
            this.addMessage('system', extractedText, 'ocr');
            
            // Update camera overlay
            this.components.camera.updateOverlay(result.ocr_results);
        }
        
        // Update stats
        this.stats.framesProcessed++;
        this.stats.avgProcessingTime = result.processing_time || 0;
        this.updateUI();
    }
    
    handleTTSReady(audioUrl, text) {
        // Play TTS audio
        const audio = document.getElementById('tts-audio');
        audio.src = audioUrl;
        audio.play().catch(console.error);
        
        this.finishStreamingMessage();
    }
    
    updateModelsList(models) {
        const select = document.getElementById('model-select');
        select.innerHTML = '';
        
        models.forEach(model => {
            const option = document.createElement('option');
            option.value = model;
            option.textContent = model;
            option.selected = model === this.state.currentModel;
            select.appendChild(option);
        });
    }
    
    handleSystemStatus(status) {
        // Update status indicators
        const ollamaStatus = document.getElementById('ollama-status');
        const gpuStatus = document.getElementById('gpu-status');
        
        ollamaStatus.className = `status-indicator ${
            status.ollama?.connected ? 'connected' : 'disconnected'
        }`;
        
        gpuStatus.className = `status-indicator ${
            status.gpu?.available ? 'connected' : 'warning'
        }`;
        
        // Update status cards
        if (status.gpu?.memory_usage) {
            document.getElementById('gpu-usage').textContent = 
                `${status.gpu.memory_usage.usage_percent.toFixed(0)}%`;
        }
        
        if (status.ocr?.stats) {
            document.getElementById('ocr-stats').textContent = 
                status.ocr.stats.total_processed;
        }
        
        if (status.ollama) {
            document.getElementById('ai-status').textContent = 
                status.ollama.connected ? 'Online' : 'Offline';
        }
        
        if (status.voice) {
            document.getElementById('voice-stats').textContent = 
                status.voice.initialized ? 'Ready' : 'Error';
        }
    }
    
    handleVoiceCommand(data) {
        this.addMessage('system', `Voice command executed: ${data.command}`);
        
        if (data.action === 'ocr_and_analyze') {
            // Trigger OCR processing if not already active
            if (!this.state.ocrActive) {
                this.startCamera();
            }
        }
    }
    
    onConnectionStateChange(connected) {
        this.state.connected = connected;
        this.updateUI();
        
        if (connected) {
            this.showNotification('Connected to server', 'success');
            // Request initial status and models
            this.refreshModels();
        } else {
            this.showNotification('Disconnected from server', 'error');
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.visionEngine = new VisionEngineApp();
});

// Load saved theme
const savedTheme = localStorage.getItem('theme') || 'dark';
document.body.classList.add(`theme-${savedTheme}`);

// Update theme toggle icon
const themeIcon = document.querySelector('#theme-toggle i');
if (themeIcon) {
    themeIcon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}