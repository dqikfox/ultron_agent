/**
 * Settings Manager for Application Configuration
 */

class SettingsManager {
    constructor(app) {
        this.app = app;
        this.settings = {
            ollama: {
                base_url: 'http://localhost:11434',
                timeout: 30,
                default_model: 'hermes3',
                stream: true
            },
            ocr: {
                confidence_threshold: 0.7,
                languages: ['en'],
                detection_threshold: 0.3,
                gpu_enabled: true,
                use_cuda: true
            },
            voice: {
                voice_id: 'EXAVITQu4vr4xnSDxMaL',
                stability: 0.5,
                similarity_boost: 0.75,
                speech_rate: 1.0
            },
            gpu: {
                device_id: 0,
                memory_limit: 0.8,
                enable_optimization: true
            },
            video: {
                fps: 30,
                resolution: [1280, 720],
                format: 'MJPG'
            },
            ui: {
                theme: 'dark',
                auto_scroll: true,
                show_confidence: true,
                highlight_text: true
            }
        };
        
        this.defaultSettings = JSON.parse(JSON.stringify(this.settings));
        this.init();
    }
    
    init() {
        this.loadSettings();
        this.setupEventHandlers();
        this.populateUI();
        console.log('Settings Manager initialized');
    }
    
    setupEventHandlers() {
        // Save settings button
        const saveBtn = document.getElementById('save-settings');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                this.saveSettings();
            });
        }
        
        // Reset settings button
        const resetBtn = document.getElementById('reset-settings');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetToDefaults();
            });
        }
        
        // Real-time setting changes
        this.setupRealtimeUpdates();
    }
    
    setupRealtimeUpdates() {
        // Ollama settings
        const ollamaUrl = document.getElementById('ollama-url');
        if (ollamaUrl) {
            ollamaUrl.addEventListener('change', (e) => {
                this.updateSetting('ollama', 'base_url', e.target.value);
            });
        }
        
        const ollamaTimeout = document.getElementById('ollama-timeout');
        if (ollamaTimeout) {
            ollamaTimeout.addEventListener('change', (e) => {
                this.updateSetting('ollama', 'timeout', parseInt(e.target.value));
            });
        }
        
        const defaultModel = document.getElementById('default-model');
        if (defaultModel) {
            defaultModel.addEventListener('change', (e) => {
                this.updateSetting('ollama', 'default_model', e.target.value);
            });
        }
        
        // OCR settings
        const ocrConfidence = document.getElementById('ocr-confidence');
        if (ocrConfidence) {
            ocrConfidence.addEventListener('input', (e) => {
                this.updateSetting('ocr', 'confidence_threshold', parseFloat(e.target.value));
                this.updateConfidenceDisplay(e.target.value);
            });
        }
        
        const ocrLanguages = document.getElementById('ocr-languages');
        if (ocrLanguages) {
            ocrLanguages.addEventListener('change', (e) => {
                const selected = Array.from(e.target.selectedOptions).map(opt => opt.value);
                this.updateSetting('ocr', 'languages', selected);
            });
        }
        
        const gpuAcceleration = document.getElementById('gpu-acceleration');
        if (gpuAcceleration) {
            gpuAcceleration.addEventListener('change', (e) => {
                this.updateSetting('ocr', 'gpu_enabled', e.target.checked);
            });
        }
        
        // Voice settings
        const voiceSelectSettings = document.getElementById('voice-select-settings');
        if (voiceSelectSettings) {
            voiceSelectSettings.addEventListener('change', (e) => {
                this.updateSetting('voice', 'voice_id', e.target.value);
                this.syncVoiceSelect(e.target.value);
            });
        }
        
        const voiceStability = document.getElementById('voice-stability');
        if (voiceStability) {
            voiceStability.addEventListener('input', (e) => {
                this.updateSetting('voice', 'stability', parseFloat(e.target.value));
                this.updateStabilityDisplay(e.target.value);
            });
        }
        
        const voiceSimilarity = document.getElementById('voice-similarity');
        if (voiceSimilarity) {
            voiceSimilarity.addEventListener('input', (e) => {
                this.updateSetting('voice', 'similarity_boost', parseFloat(e.target.value));
                this.updateSimilarityDisplay(e.target.value);
            });
        }
        
        // GPU settings
        const gpuMemoryLimit = document.getElementById('gpu-memory-limit');
        if (gpuMemoryLimit) {
            gpuMemoryLimit.addEventListener('input', (e) => {
                this.updateSetting('gpu', 'memory_limit', parseInt(e.target.value) / 100);
                this.updateMemoryLimitDisplay(e.target.value);
            });
        }
        
        const gpuOptimization = document.getElementById('gpu-optimization');
        if (gpuOptimization) {
            gpuOptimization.addEventListener('change', (e) => {
                this.updateSetting('gpu', 'enable_optimization', e.target.checked);
            });
        }
    }
    
    populateUI() {
        // Populate Ollama settings
        this.setElementValue('ollama-url', this.settings.ollama.base_url);
        this.setElementValue('ollama-timeout', this.settings.ollama.timeout);
        this.setElementValue('default-model', this.settings.ollama.default_model);
        
        // Populate OCR settings
        this.setElementValue('ocr-confidence', this.settings.ocr.confidence_threshold);
        this.updateConfidenceDisplay(this.settings.ocr.confidence_threshold);
        
        const ocrLanguages = document.getElementById('ocr-languages');
        if (ocrLanguages) {
            Array.from(ocrLanguages.options).forEach(option => {
                option.selected = this.settings.ocr.languages.includes(option.value);
            });
        }
        
        this.setElementValue('gpu-acceleration', this.settings.ocr.gpu_enabled, 'checked');
        
        // Populate Voice settings
        this.setElementValue('voice-select-settings', this.settings.voice.voice_id);
        this.setElementValue('voice-stability', this.settings.voice.stability);
        this.setElementValue('voice-similarity', this.settings.voice.similarity_boost);
        
        this.updateStabilityDisplay(this.settings.voice.stability);
        this.updateSimilarityDisplay(this.settings.voice.similarity_boost);
        
        // Populate GPU settings
        this.setElementValue('gpu-memory-limit', this.settings.gpu.memory_limit * 100);
        this.setElementValue('gpu-optimization', this.settings.gpu.enable_optimization, 'checked');
        
        this.updateMemoryLimitDisplay(this.settings.gpu.memory_limit * 100);
        
        // Sync with main UI controls
        this.syncMainUIControls();
    }
    
    syncMainUIControls() {
        // Sync confidence slider
        this.setElementValue('confidence-slider', this.settings.ocr.confidence_threshold);
        this.setElementValue('confidence-value', this.settings.ocr.confidence_threshold.toFixed(1), 'textContent');
        
        // Sync voice select in main UI
        this.setElementValue('voice-select', this.settings.voice.voice_id);
    }
    
    syncVoiceSelect(voiceId) {
        // Sync main UI voice select
        this.setElementValue('voice-select', voiceId);
        
        // Notify voice manager
        if (this.app.components.voice) {
            this.app.components.voice.setVoice(voiceId);
        }
    }
    
    updateConfidenceDisplay(value) {
        const display = document.querySelector('#ocr-confidence + span');
        if (display) {
            display.textContent = parseFloat(value).toFixed(1);
        }
    }
    
    updateStabilityDisplay(value) {
        const display = document.querySelector('#voice-stability + span');
        if (display) {
            display.textContent = parseFloat(value).toFixed(1);
        }
    }
    
    updateSimilarityDisplay(value) {
        const display = document.querySelector('#voice-similarity + span');
        if (display) {
            display.textContent = parseFloat(value).toFixed(1);
        }
    }
    
    updateMemoryLimitDisplay(value) {
        const display = document.querySelector('#gpu-memory-limit + span');
        if (display) {
            display.textContent = `${value}%`;
        }
    }
    
    setElementValue(elementId, value, property = 'value') {
        const element = document.getElementById(elementId);
        if (element) {
            if (property === 'checked') {
                element.checked = value;
            } else if (property === 'textContent') {
                element.textContent = value;
            } else {
                element.value = value;
            }
        }
    }
    
    updateSetting(section, key, value) {
        if (this.settings[section]) {
            this.settings[section][key] = value;
            
            // Auto-save certain settings
            if (section === 'ui') {
                this.saveSettings();
            }
            
            // Apply immediate changes
            this.applySettingChange(section, key, value);
        }
    }
    
    applySettingChange(section, key, value) {
        switch (section) {
            case 'ocr':
                if (key === 'confidence_threshold') {
                    // Update main UI confidence slider
                    this.setElementValue('confidence-slider', value);
                    this.setElementValue('confidence-value', value.toFixed(1), 'textContent');
                    
                    // Update OCR engine if available
                    if (this.app.components.ocr) {
                        this.app.updateOCRSettings({ confidence: value });
                    }
                }
                break;
                
            case 'voice':
                if (key === 'voice_id') {
                    this.syncVoiceSelect(value);
                }
                break;
                
            case 'gpu':
                if (key === 'memory_limit') {
                    // Send to backend if connected
                    if (this.app.components.websocket && this.app.components.websocket.isConnected()) {
                        this.app.components.websocket.updateSettings('gpu', { memory_limit: value });
                    }
                }
                break;
        }
    }
    
    saveSettings() {
        try {
            // Save to localStorage
            localStorage.setItem('visionEngineSettings', JSON.stringify(this.settings));
            
            // Send to backend
            if (this.app.components.websocket && this.app.components.websocket.isConnected()) {
                Object.keys(this.settings).forEach(section => {
                    this.app.components.websocket.updateSettings(section, this.settings[section]);
                });
            }
            
            // Show success notification
            this.app.showNotification('Settings saved successfully', 'success');
            
            // Close modal
            this.app.components.ui.hideModal('settings');
            
        } catch (error) {
            console.error('Error saving settings:', error);
            this.app.showNotification('Failed to save settings', 'error');
        }
    }
    
    loadSettings() {
        try {
            const saved = localStorage.getItem('visionEngineSettings');
            if (saved) {
                const parsedSettings = JSON.parse(saved);
                
                // Merge with defaults (in case new settings were added)
                this.settings = this.mergeSettings(this.defaultSettings, parsedSettings);
            }
        } catch (error) {
            console.error('Error loading settings:', error);
            // Use defaults if loading fails
            this.settings = JSON.parse(JSON.stringify(this.defaultSettings));
        }
    }
    
    mergeSettings(defaults, saved) {
        const result = JSON.parse(JSON.stringify(defaults));
        
        Object.keys(saved).forEach(section => {
            if (result[section]) {
                Object.keys(saved[section]).forEach(key => {
                    if (key in result[section]) {
                        result[section][key] = saved[section][key];
                    }
                });
            }
        });
        
        return result;
    }
    
    resetToDefaults() {
        if (confirm('Are you sure you want to reset all settings to defaults?')) {
            this.settings = JSON.parse(JSON.stringify(this.defaultSettings));
            this.populateUI();
            this.saveSettings();
            this.app.showNotification('Settings reset to defaults', 'info');
        }
    }
    
    exportSettings() {
        try {
            const data = {
                timestamp: new Date().toISOString(),
                version: '1.0.0',
                settings: this.settings
            };
            
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `vision_engine_settings_${Date.now()}.json`;
            a.click();
            URL.revokeObjectURL(url);
            
            this.app.showNotification('Settings exported successfully', 'success');
            
        } catch (error) {
            console.error('Error exporting settings:', error);
            this.app.showNotification('Failed to export settings', 'error');
        }
    }
    
    async importSettings(file) {
        try {
            const text = await file.text();
            const data = JSON.parse(text);
            
            if (data.settings) {
                this.settings = this.mergeSettings(this.defaultSettings, data.settings);
                this.populateUI();
                this.saveSettings();
                this.app.showNotification('Settings imported successfully', 'success');
            } else {
                throw new Error('Invalid settings file format');
            }
            
        } catch (error) {
            console.error('Error importing settings:', error);
            this.app.showNotification('Failed to import settings', 'error');
        }
    }
    
    getSettings(section = null) {
        if (section) {
            return this.settings[section] || {};
        }
        return this.settings;
    }
    
    getSetting(section, key, defaultValue = null) {
        return this.settings[section]?.[key] ?? defaultValue;
    }
    
    // Utility methods for specific settings
    getOllamaConfig() {
        return this.settings.ollama;
    }
    
    getOCRConfig() {
        return this.settings.ocr;
    }
    
    getVoiceConfig() {
        return this.settings.voice;
    }
    
    getGPUConfig() {
        return this.settings.gpu;
    }
    
    getVideoConfig() {
        return this.settings.video;
    }
    
    getUIConfig() {
        return this.settings.ui;
    }
    
    // Theme management
    applyTheme(theme = null) {
        const targetTheme = theme || this.settings.ui.theme;
        const body = document.body;
        
        // Remove existing theme classes
        body.classList.remove('theme-light', 'theme-dark');
        
        // Apply new theme
        body.classList.add(`theme-${targetTheme}`);
        
        // Update theme toggle icon
        const themeIcon = document.querySelector('#theme-toggle i');
        if (themeIcon) {
            themeIcon.className = targetTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
        
        // Save theme setting
        if (theme) {
            this.updateSetting('ui', 'theme', theme);
        }
    }
    
    toggleTheme() {
        const currentTheme = this.settings.ui.theme;
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        this.applyTheme(newTheme);
    }
    
    // Performance optimization settings
    getPerformanceSettings() {
        return {
            enableGPU: this.settings.ocr.gpu_enabled,
            memoryLimit: this.settings.gpu.memory_limit,
            frameSkip: this.settings.video.frame_skip || 2,
            maxFPS: this.settings.video.fps
        };
    }
    
    // Validation methods
    validateSettings() {
        const errors = [];
        
        // Validate Ollama URL
        try {
            new URL(this.settings.ollama.base_url);
        } catch {
            errors.push('Invalid Ollama server URL');
        }
        
        // Validate numeric ranges
        if (this.settings.ocr.confidence_threshold < 0 || this.settings.ocr.confidence_threshold > 1) {
            errors.push('OCR confidence threshold must be between 0 and 1');
        }
        
        if (this.settings.gpu.memory_limit < 0 || this.settings.gpu.memory_limit > 1) {
            errors.push('GPU memory limit must be between 0 and 100%');
        }
        
        return errors;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SettingsManager;
}