/**
 * WebSocket Manager for Real-time Communication
 */

class WebSocketManager {
    constructor(app) {
        this.app = app;
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.isConnecting = false;
        this.messageQueue = [];
        this.heartbeatInterval = null;
    }
    
    async connect() {
        if (this.isConnecting || (this.socket && this.socket.readyState === WebSocket.OPEN)) {
            return;
        }
        
        this.isConnecting = true;
        
        try {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const wsUrl = `${protocol}//${window.location.host}/ws`;
            
            console.log('Connecting to WebSocket:', wsUrl);
            
            this.socket = new WebSocket(wsUrl);
            
            this.socket.onopen = () => {
                console.log('WebSocket connected');
                this.isConnecting = false;
                this.reconnectAttempts = 0;
                
                // Notify app of connection
                this.app.onConnectionStateChange(true);
                
                // Send queued messages
                this.flushMessageQueue();
                
                // Start heartbeat
                this.startHeartbeat();
            };
            
            this.socket.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleMessage(data);
                } catch (error) {
                    console.error('Error parsing WebSocket message:', error);
                }
            };
            
            this.socket.onclose = (event) => {
                console.log('WebSocket closed:', event.code, event.reason);
                this.isConnecting = false;
                
                // Stop heartbeat
                this.stopHeartbeat();
                
                // Notify app of disconnection
                this.app.onConnectionStateChange(false);
                
                // Attempt reconnection if not a clean close
                if (event.code !== 1000 && this.reconnectAttempts < this.maxReconnectAttempts) {
                    this.scheduleReconnect();
                }
            };
            
            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.isConnecting = false;
            };
            
        } catch (error) {
            console.error('Failed to create WebSocket connection:', error);
            this.isConnecting = false;
            throw error;
        }
    }
    
    disconnect() {
        if (this.socket) {
            this.socket.close(1000, 'Client disconnect');
            this.socket = null;
        }
        
        this.stopHeartbeat();
        this.app.onConnectionStateChange(false);
    }
    
    send(data) {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
            try {
                this.socket.send(JSON.stringify(data));
                return true;
            } catch (error) {
                console.error('Error sending WebSocket message:', error);
                return false;
            }
        } else {
            // Queue message for later
            this.messageQueue.push(data);
            
            // Attempt to reconnect if not connected
            if (!this.isConnecting && this.reconnectAttempts < this.maxReconnectAttempts) {
                this.connect();
            }
            
            return false;
        }
    }
    
    handleMessage(data) {
        // Handle heartbeat responses
        if (data.type === 'pong') {
            return;
        }
        
        // Forward message to app
        this.app.onWebSocketMessage(data);
    }
    
    flushMessageQueue() {
        while (this.messageQueue.length > 0) {
            const message = this.messageQueue.shift();
            this.send(message);
        }
    }
    
    scheduleReconnect() {
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
        
        console.log(`Scheduling reconnect attempt ${this.reconnectAttempts} in ${delay}ms`);
        
        setTimeout(() => {
            if (this.reconnectAttempts <= this.maxReconnectAttempts) {
                this.connect();
            }
        }, delay);
    }
    
    startHeartbeat() {
        this.stopHeartbeat();
        
        this.heartbeatInterval = setInterval(() => {
            if (this.socket && this.socket.readyState === WebSocket.OPEN) {
                this.send({ type: 'ping' });
            }
        }, 30000); // Send ping every 30 seconds
    }
    
    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }
    
    getConnectionState() {
        if (!this.socket) return 'disconnected';
        
        switch (this.socket.readyState) {
            case WebSocket.CONNECTING:
                return 'connecting';
            case WebSocket.OPEN:
                return 'connected';
            case WebSocket.CLOSING:
                return 'closing';
            case WebSocket.CLOSED:
                return 'disconnected';
            default:
                return 'unknown';
        }
    }
    
    isConnected() {
        return this.socket && this.socket.readyState === WebSocket.OPEN;
    }
    
    // Utility methods for specific message types
    sendOCRCommand(command, config = {}) {
        return this.send({
            type: command,
            config: config,
            timestamp: Date.now()
        });
    }
    
    sendVoiceCommand(command) {
        return this.send({
            type: 'voice_command',
            command: command,
            timestamp: Date.now()
        });
    }
    
    sendTextToAI(text, context = '') {
        return this.send({
            type: 'process_text',
            text: text,
            context: context,
            timestamp: Date.now()
        });
    }
    
    requestSystemStatus() {
        return this.send({
            type: 'get_status',
            timestamp: Date.now()
        });
    }
    
    requestModels() {
        return this.send({
            type: 'get_models',
            timestamp: Date.now()
        });
    }
    
    changeModel(modelName) {
        return this.send({
            type: 'change_model',
            model: modelName,
            timestamp: Date.now()
        });
    }
    
    updateSettings(section, settings) {
        return this.send({
            type: 'update_settings',
            section: section,
            settings: settings,
            timestamp: Date.now()
        });
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebSocketManager;
}