/**
 * UI Manager for Interface Controls and Interactions
 */

class UIManager {
    constructor(app) {
        this.app = app;
        this.modals = new Map();
        this.notifications = [];
        this.init();
    }
    
    init() {
        this.setupModals();
        this.setupUIControls();
        this.setupKeyboardShortcuts();
        this.setupResponsiveHandlers();
        console.log('UI Manager initialized');
    }
    
    setupModals() {
        // Settings modal
        const settingsModal = document.getElementById('settings-modal');
        const settingsBtn = document.getElementById('settings-btn');
        const closeSettings = document.getElementById('close-settings');
        
        if (settingsModal && settingsBtn && closeSettings) {
            this.modals.set('settings', settingsModal);
            
            settingsBtn.addEventListener('click', () => {
                this.showModal('settings');
            });
            
            closeSettings.addEventListener('click', () => {
                this.hideModal('settings');
            });
            
            // Close modal when clicking outside
            settingsModal.addEventListener('click', (e) => {
                if (e.target === settingsModal) {
                    this.hideModal('settings');
                }
            });
        }
        
        // Setup settings tabs
        this.setupSettingsTabs();
    }
    
    setupSettingsTabs() {
        const tabButtons = document.querySelectorAll('.tab-btn');
        const tabPanes = document.querySelectorAll('.tab-pane');
        
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                const targetTab = button.dataset.tab;
                
                // Update active tab button
                tabButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                
                // Update active tab pane
                tabPanes.forEach(pane => {
                    pane.classList.remove('active');
                    if (pane.id === `${targetTab}-tab`) {
                        pane.classList.add('active');
                    }
                });
            });
        });
    }
    
    setupUIControls() {
        // Setup range slider value displays
        this.setupRangeSliders();
        
        // Setup toggle buttons
        this.setupToggleButtons();
        
        // Setup dropdown menus
        this.setupDropdowns();
        
        // Setup tooltip system
        this.setupTooltips();
    }
    
    setupRangeSliders() {
        const sliders = document.querySelectorAll('input[type="range"]');
        
        sliders.forEach(slider => {
            const updateValue = () => {
                const valueElement = document.getElementById(slider.id.replace('-slider', '-value'));
                if (valueElement) {
                    valueElement.textContent = slider.value;
                }
            };
            
            // Update on input
            slider.addEventListener('input', updateValue);
            
            // Initialize value display
            updateValue();
        });
    }
    
    setupToggleButtons() {
        const toggleButtons = document.querySelectorAll('.toggle-btn');
        
        toggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                button.classList.toggle('active');
                
                // Emit toggle event
                const event = new CustomEvent('toggleChange', {
                    detail: {
                        id: button.id,
                        active: button.classList.contains('active')
                    }
                });
                button.dispatchEvent(event);
            });
        });
    }
    
    setupDropdowns() {
        const dropdowns = document.querySelectorAll('select');
        
        dropdowns.forEach(dropdown => {
            dropdown.addEventListener('change', () => {
                // Emit change event with additional data
                const event = new CustomEvent('dropdownChange', {
                    detail: {
                        id: dropdown.id,
                        value: dropdown.value,
                        text: dropdown.options[dropdown.selectedIndex]?.text
                    }
                });
                dropdown.dispatchEvent(event);
            });
        });
    }
    
    setupTooltips() {
        // Simple tooltip system
        const elementsWithTooltips = document.querySelectorAll('[data-tooltip]');
        
        elementsWithTooltips.forEach(element => {
            element.addEventListener('mouseenter', (e) => {
                this.showTooltip(e.target, e.target.dataset.tooltip);
            });
            
            element.addEventListener('mouseleave', () => {
                this.hideTooltip();
            });
        });
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + key combinations
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 's':
                        e.preventDefault();
                        this.showModal('settings');
                        break;
                    case 'r':
                        e.preventDefault();
                        this.app.refreshModels();
                        break;
                    case 'c':
                        e.preventDefault();
                        this.app.clearChat();
                        break;
                    case 'e':
                        e.preventDefault();
                        this.app.exportResults();
                        break;
                }
            }
            
            // Single key shortcuts
            if (!e.ctrlKey && !e.metaKey && !e.altKey) {
                // Only if not in input field
                if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) {
                    switch (e.key) {
                        case ' ': // Spacebar for voice
                            e.preventDefault();
                            if (!this.app.components.voice.isListening) {
                                this.app.components.voice.startListening();
                            }
                            break;
                        case 'Escape':
                            this.hideAllModals();
                            break;
                        case 'F11':
                            e.preventDefault();
                            this.toggleFullscreen();
                            break;
                    }
                }
            }
            
            // Escape key always closes modals
            if (e.key === 'Escape') {
                this.hideAllModals();
            }
        });
        
        // Handle spacebar release for voice
        document.addEventListener('keyup', (e) => {
            if (e.key === ' ' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(e.target.tagName)) {
                if (this.app.components.voice.isListening && !this.app.components.voice.continuousMode) {
                    this.app.components.voice.stopListening();
                }
            }
        });
    }
    
    setupResponsiveHandlers() {
        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
        
        // Handle orientation change on mobile
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                this.handleResize();
            }, 500);
        });
    }
    
    handleResize() {
        // Update video canvas size
        if (this.app.components.camera) {
            this.app.components.camera.resizeCanvas();
        }
        
        // Update any responsive UI elements
        this.updateResponsiveElements();
    }
    
    updateResponsiveElements() {
        const width = window.innerWidth;
        
        // Adjust layout for mobile
        if (width < 768) {
            document.body.classList.add('mobile-layout');
        } else {
            document.body.classList.remove('mobile-layout');
        }
        
        // Adjust control panel for tablet
        if (width < 1200 && width >= 768) {
            document.body.classList.add('tablet-layout');
        } else {
            document.body.classList.remove('tablet-layout');
        }
    }
    
    showModal(modalId) {
        const modal = this.modals.get(modalId);
        if (modal) {
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
            
            // Focus first input if available
            const firstInput = modal.querySelector('input, select, textarea');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 100);
            }
        }
    }
    
    hideModal(modalId) {
        const modal = this.modals.get(modalId);
        if (modal) {
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }
    
    hideAllModals() {
        this.modals.forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
    
    showTooltip(element, text) {
        // Remove existing tooltip
        this.hideTooltip();
        
        const tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.textContent = text;
        tooltip.id = 'ui-tooltip';
        
        document.body.appendChild(tooltip);
        
        // Position tooltip
        const rect = element.getBoundingClientRect();
        tooltip.style.position = 'fixed';
        tooltip.style.top = `${rect.top - tooltip.offsetHeight - 8}px`;
        tooltip.style.left = `${rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2)}px`;
        tooltip.style.zIndex = '10000';
        tooltip.style.background = 'var(--bg-tertiary)';
        tooltip.style.color = 'var(--text-primary)';
        tooltip.style.padding = '0.5rem';
        tooltip.style.borderRadius = '0.25rem';
        tooltip.style.fontSize = '0.75rem';
        tooltip.style.border = '1px solid var(--border-color)';
        tooltip.style.boxShadow = 'var(--shadow)';
        tooltip.style.opacity = '0';
        tooltip.style.transition = 'opacity 0.2s';
        
        // Show with animation
        setTimeout(() => {
            tooltip.style.opacity = '1';
        }, 10);
    }
    
    hideTooltip() {
        const tooltip = document.getElementById('ui-tooltip');
        if (tooltip) {
            tooltip.remove();
        }
    }
    
    showNotification(message, type = 'info', duration = 3000) {
        const notification = {
            id: Date.now(),
            message,
            type,
            element: null
        };
        
        // Create notification element
        const element = document.createElement('div');
        element.className = `notification ${type}`;
        element.innerHTML = `
            <div class="notification-content">
                <span class="notification-message">${message}</span>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        notification.element = element;
        this.notifications.push(notification);
        
        // Add to DOM
        document.body.appendChild(element);
        
        // Show with animation
        setTimeout(() => {
            element.classList.add('show');
        }, 10);
        
        // Auto-remove
        setTimeout(() => {
            this.removeNotification(notification.id);
        }, duration);
    }
    
    removeNotification(notificationId) {
        const index = this.notifications.findIndex(n => n.id === notificationId);
        if (index > -1) {
            const notification = this.notifications[index];
            if (notification.element) {
                notification.element.classList.remove('show');
                setTimeout(() => {
                    if (notification.element.parentNode) {
                        notification.element.remove();
                    }
                }, 300);
            }
            this.notifications.splice(index, 1);
        }
    }
    
    updateProgress(elementId, progress, text = '') {
        const element = document.getElementById(elementId);
        if (element) {
            const progressBar = element.querySelector('.progress-bar');
            const progressText = element.querySelector('.progress-text');
            
            if (progressBar) {
                progressBar.style.width = `${Math.min(100, Math.max(0, progress))}%`;
            }
            
            if (progressText && text) {
                progressText.textContent = text;
            }
        }
    }
    
    setLoading(elementId, loading = true) {
        const element = document.getElementById(elementId);
        if (element) {
            if (loading) {
                element.classList.add('loading');
                element.disabled = true;
            } else {
                element.classList.remove('loading');
                element.disabled = false;
            }
        }
    }
    
    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(console.error);
        } else {
            document.exitFullscreen().catch(console.error);
        }
    }
    
    // Utility methods for common UI tasks
    updateElementText(elementId, text) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = text;
        }
    }
    
    updateElementHTML(elementId, html) {
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = html;
        }
    }
    
    toggleElementVisibility(elementId, visible = null) {
        const element = document.getElementById(elementId);
        if (element) {
            if (visible === null) {
                element.classList.toggle('hidden');
            } else {
                element.classList.toggle('hidden', !visible);
            }
        }
    }
    
    updateElementClass(elementId, className, add = true) {
        const element = document.getElementById(elementId);
        if (element) {
            if (add) {
                element.classList.add(className);
            } else {
                element.classList.remove(className);
            }
        }
    }
    
    animateNumber(elementId, from, to, duration = 1000) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        const startTime = performance.now();
        const difference = to - from;
        
        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function (ease out)
            const eased = 1 - Math.pow(1 - progress, 3);
            const current = from + (difference * eased);
            
            element.textContent = Math.round(current);
            
            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };
        
        requestAnimationFrame(animate);
    }
    
    getFormData(formId) {
        const form = document.getElementById(formId);
        if (!form) return null;
        
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        return data;
    }
    
    setFormData(formId, data) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        Object.keys(data).forEach(key => {
            const element = form.querySelector(`[name="${key}"]`);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = data[key];
                } else {
                    element.value = data[key];
                }
            }
        });
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIManager;
}