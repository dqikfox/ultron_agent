/**
 * Camera Manager for Video Streaming and OCR Overlay
 */

class CameraManager {
    constructor(app) {
        this.app = app;
        this.stream = null;
        this.video = document.getElementById('video-stream');
        this.canvas = document.getElementById('ocr-overlay');
        this.ctx = this.canvas.getContext('2d');
        this.isActive = false;
        this.overlayEnabled = true;
        this.currentOCRResults = [];
        this.animationFrame = null;
    }
    
    async start() {
        try {
            // Request camera access
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            });
            
            // Set video source
            this.video.srcObject = this.stream;
            this.video.play();
            
            // Wait for video to load
            await new Promise((resolve) => {
                this.video.onloadedmetadata = () => {
                    // Setup canvas to match video dimensions
                    this.resizeCanvas();
                    resolve();
                };
            });
            
            this.isActive = true;
            
            // Start overlay rendering
            this.startOverlayRendering();
            
            console.log('Camera started successfully');
            
        } catch (error) {
            console.error('Error starting camera:', error);
            throw new Error('Failed to start camera: ' + error.message);
        }
    }
    
    stop() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        if (this.video) {
            this.video.srcObject = null;
        }
        
        this.isActive = false;
        this.stopOverlayRendering();
        
        // Clear canvas
        this.clearOverlay();
        
        console.log('Camera stopped');
    }
    
    async captureScreen() {
        try {
            // Request screen capture
            this.stream = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    width: { ideal: 1920 },
                    height: { ideal: 1080 }
                },
                audio: false
            });
            
            // Set video source
            this.video.srcObject = this.stream;
            this.video.play();
            
            // Wait for video to load
            await new Promise((resolve) => {
                this.video.onloadedmetadata = () => {
                    this.resizeCanvas();
                    resolve();
                };
            });
            
            this.isActive = true;
            this.startOverlayRendering();
            
            console.log('Screen capture started');
            
        } catch (error) {
            console.error('Error starting screen capture:', error);
            throw new Error('Failed to start screen capture: ' + error.message);
        }
    }
    
    resizeCanvas() {
        if (this.video && this.canvas) {
            this.canvas.width = this.video.videoWidth;
            this.canvas.height = this.video.videoHeight;
            
            // Update canvas display size to match video
            const rect = this.video.getBoundingClientRect();
            this.canvas.style.width = rect.width + 'px';
            this.canvas.style.height = rect.height + 'px';
        }
    }
    
    startOverlayRendering() {
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
        }
        
        const render = () => {
            if (this.isActive && this.overlayEnabled) {
                this.renderOverlay();
                this.animationFrame = requestAnimationFrame(render);
            }
        };
        
        render();
    }
    
    stopOverlayRendering() {
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }
    }
    
    renderOverlay() {
        if (!this.ctx || !this.overlayEnabled) return;
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw OCR results
        this.drawOCRResults();
    }
    
    drawOCRResults() {
        if (!this.currentOCRResults || this.currentOCRResults.length === 0) return;
        
        this.currentOCRResults.forEach(result => {
            this.drawTextBoundingBox(result);
        });
    }
    
    drawTextBoundingBox(result) {
        const { bbox, text, confidence } = result;
        
        if (!bbox || bbox.length < 4) return;
        
        // Set drawing style based on confidence
        const alpha = Math.max(0.6, confidence);
        const color = confidence > 0.8 ? '#00ff00' : confidence > 0.6 ? '#ffff00' : '#ff6600';
        
        this.ctx.strokeStyle = color;
        this.ctx.lineWidth = 2;
        this.ctx.globalAlpha = alpha;
        
        // Draw bounding box
        this.ctx.beginPath();
        this.ctx.moveTo(bbox[0][0], bbox[0][1]);
        for (let i = 1; i < bbox.length; i++) {
            this.ctx.lineTo(bbox[i][0], bbox[i][1]);
        }
        this.ctx.closePath();
        this.ctx.stroke();
        
        // Draw text label with background
        if (text && confidence > 0.5) {
            const x = bbox[0][0];
            const y = bbox[0][1] - 5;
            
            this.ctx.font = '14px Inter, sans-serif';
            this.ctx.fillStyle = color;
            
            // Text background
            const textMetrics = this.ctx.measureText(text);
            this.ctx.fillRect(x, y - 16, textMetrics.width + 8, 20);
            
            // Text
            this.ctx.fillStyle = '#000000';
            this.ctx.fillText(text, x + 4, y - 2);
        }
        
        // Reset alpha
        this.ctx.globalAlpha = 1.0;
    }
    
    updateOverlay(ocrResults) {
        this.currentOCRResults = ocrResults || [];
        
        // Force immediate render if not animating
        if (!this.animationFrame && this.overlayEnabled) {
            this.renderOverlay();
        }
    }
    
    toggleOverlay() {
        this.overlayEnabled = !this.overlayEnabled;
        
        const toggleBtn = document.getElementById('overlay-toggle');
        if (toggleBtn) {
            toggleBtn.classList.toggle('active', this.overlayEnabled);
            
            const icon = toggleBtn.querySelector('i');
            const text = toggleBtn.querySelector('span');
            if (this.overlayEnabled) {
                if (icon) icon.className = 'fas fa-layer-group';
                if (text) text.textContent = 'Hide Overlay';
            } else {
                if (icon) icon.className = 'fas fa-eye-slash';
                if (text) text.textContent = 'Show Overlay';
            }
        }
        
        if (!this.overlayEnabled) {
            this.clearOverlay();
            this.stopOverlayRendering();
        } else if (this.isActive) {
            this.startOverlayRendering();
        }
    }
    
    clearOverlay() {
        if (this.ctx) {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        }
        this.currentOCRResults = [];
    }
    
    captureFrame() {
        if (!this.video || !this.isActive) {
            throw new Error('Camera not active');
        }
        
        // Create temporary canvas to capture frame
        const tempCanvas = document.createElement('canvas');
        const tempCtx = tempCanvas.getContext('2d');
        
        tempCanvas.width = this.video.videoWidth;
        tempCanvas.height = this.video.videoHeight;
        
        // Draw current video frame
        tempCtx.drawImage(this.video, 0, 0);
        
        // Convert to blob
        return new Promise((resolve) => {
            tempCanvas.toBlob(resolve, 'image/jpeg', 0.9);
        });
    }
    
    async uploadFrame() {
        try {
            const blob = await this.captureFrame();
            
            // Create FormData for upload
            const formData = new FormData();
            formData.append('file', blob, 'frame.jpg');
            
            // Upload to backend
            const response = await fetch('/api/upload/frame', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`Upload failed: ${response.statusText}`);
            }
            
            return await response.json();
            
        } catch (error) {
            console.error('Error uploading frame:', error);
            throw error;
        }
    }
    
    getVideoInfo() {
        if (!this.video || !this.isActive) {
            return null;
        }
        
        return {
            width: this.video.videoWidth,
            height: this.video.videoHeight,
            duration: this.video.duration,
            currentTime: this.video.currentTime,
            paused: this.video.paused,
            stream: {
                active: this.stream ? this.stream.active : false,
                tracks: this.stream ? this.stream.getTracks().length : 0
            }
        };
    }
    
    // Utility methods
    isSupported() {
        return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
    }
    
    async getAvailableCameras() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices.filter(device => device.kind === 'videoinput');
        } catch (error) {
            console.error('Error getting camera devices:', error);
            return [];
        }
    }
    
    async switchCamera(deviceId) {
        if (!this.isActive) return;
        
        try {
            // Stop current stream
            if (this.stream) {
                this.stream.getTracks().forEach(track => track.stop());
            }
            
            // Start new stream with specific device
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    deviceId: { exact: deviceId },
                    width: { ideal: 1280 },
                    height: { ideal: 720 },
                    frameRate: { ideal: 30 }
                },
                audio: false
            });
            
            this.video.srcObject = this.stream;
            await this.video.play();
            
            this.resizeCanvas();
            
        } catch (error) {
            console.error('Error switching camera:', error);
            throw error;
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CameraManager;
}