/**
 * Voice Manager for Speech Recognition and TTS Control
 */

class VoiceManager {
    constructor(app) {
        this.app = app;
        this.recognition = null;
        this.isListening = false;
        this.continuousMode = false;
        this.currentAudio = null;
        this.audioQueue = [];
        this.voiceLevel = 0;
        this.voiceLevelElement = document.getElementById('voice-level');
        this.voiceStatusElement = document.getElementById('voice-status');
        this.audioContext = null;
        this.analyser = null;
        this.microphone = null;
        this.isInitialized = false;
    }
    
    async init() {
        try {
            // Check for Web Speech API support
            if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
                throw new Error('Speech Recognition not supported in this browser');
            }
            
            // Initialize Speech Recognition
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = false;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            this.recognition.maxAlternatives = 1;
            
            // Setup recognition event handlers
            this.setupRecognitionHandlers();
            
            // Initialize Audio Context for voice level detection
            await this.initializeAudioContext();
            
            // Setup UI event handlers
            this.setupUIHandlers();
            
            this.isInitialized = true;
            this.updateStatus('Ready');
            
            console.log('Voice manager initialized successfully');
            
        } catch (error) {
            console.error('Error initializing voice manager:', error);
            this.updateStatus('Error: ' + error.message);
            throw error;
        }
    }
    
    async initializeAudioContext() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            // Get microphone access for voice level detection
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            this.microphone = this.audioContext.createMediaStreamSource(stream);
            
            // Create analyser for voice level
            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 256;
            this.microphone.connect(this.analyser);
            
            // Start voice level monitoring
            this.startVoiceLevelMonitoring();
            
        } catch (error) {
            console.warn('Could not initialize audio context for voice level detection:', error);
        }
    }
    
    setupRecognitionHandlers() {
        this.recognition.onstart = () => {
            console.log('Speech recognition started');
            this.updateStatus('Listening...');
            this.isListening = true;
            this.updateVoiceButton(true);
        };
        
        this.recognition.onresult = (event) => {
            let transcript = '';
            let isFinal = false;
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const result = event.results[i];
                transcript += result[0].transcript;
                
                if (result.isFinal) {
                    isFinal = true;
                }
            }
            
            if (isFinal && transcript.trim()) {
                this.handleSpeechResult(transcript.trim());
            } else {
                // Show interim results
                this.updateStatus(`Listening: "${transcript}"`);
            }
        };
        
        this.recognition.onerror = (event) => {
            console.error('Speech recognition error:', event.error);
            this.updateStatus(`Error: ${event.error}`);
            this.isListening = false;
            this.updateVoiceButton(false);
        };
        
        this.recognition.onend = () => {
            console.log('Speech recognition ended');
            this.isListening = false;
            this.updateVoiceButton(false);
            
            if (this.continuousMode) {
                // Restart recognition in continuous mode
                setTimeout(() => {
                    if (this.continuousMode && !this.isListening) {
                        this.startListening();
                    }
                }, 1000);
            } else {
                this.updateStatus('Ready');
            }
        };
    }
    
    setupUIHandlers() {
        // Voice mode toggle
        const voiceModeBtn = document.getElementById('voice-mode-toggle');
        if (voiceModeBtn) {
            voiceModeBtn.addEventListener('click', () => {
                this.toggleMode();
            });
        }
        
        // Voice select
        const voiceSelect = document.getElementById('voice-select');
        if (voiceSelect) {
            voiceSelect.addEventListener('change', (e) => {
                this.setVoice(e.target.value);
            });
        }
    }
    
    startListening() {
        if (!this.isInitialized || !this.recognition) {
            console.error('Voice manager not initialized');
            return;
        }
        
        if (this.isListening) {
            console.log('Already listening');
            return;
        }
        
        try {
            this.recognition.start();
        } catch (error) {
            console.error('Error starting speech recognition:', error);
            this.updateStatus('Error starting recognition');
        }
    }
    
    stopListening() {
        if (this.recognition && this.isListening) {
            this.recognition.stop();
        }
    }
    
    toggleMode() {
        this.continuousMode = !this.continuousMode;
        
        const voiceModeBtn = document.getElementById('voice-mode-toggle');
        const icon = voiceModeBtn?.querySelector('i');
        const text = voiceModeBtn?.querySelector('span');
        
        if (this.continuousMode) {
            if (icon) icon.className = 'fas fa-microphone';
            if (text) text.textContent = 'Continuous';
            voiceModeBtn?.classList.add('active');
            
            // Start continuous listening
            if (!this.isListening) {
                this.startListening();
            }
        } else {
            if (icon) icon.className = 'fas fa-microphone-slash';
            if (text) text.textContent = 'Push to Talk';
            voiceModeBtn?.classList.remove('active');
            
            // Stop continuous listening
            this.stopListening();
        }
        
        this.updateStatus(this.continuousMode ? 'Continuous mode active' : 'Push to talk mode');
    }
    
    handleSpeechResult(transcript) {
        console.log('Speech result:', transcript);
        
        // Add user message to chat
        this.app.addMessage('user', transcript);
        
        // Send to backend for processing
        this.app.components.websocket.send({
            type: 'voice_command',
            command: transcript
        });
        
        this.updateStatus('Processing...');
    }
    
    async playTTS(audioUrl) {
        try {
            // Stop current audio if playing
            if (this.currentAudio) {
                this.currentAudio.pause();
                this.currentAudio = null;
            }
            
            // Create new audio element
            this.currentAudio = new Audio(audioUrl);
            
            // Setup event handlers
            this.currentAudio.onloadstart = () => {
                this.updateStatus('Loading audio...');
            };
            
            this.currentAudio.oncanplay = () => {
                this.updateStatus('Playing audio...');
            };
            
            this.currentAudio.onended = () => {
                this.updateStatus('Ready');
                this.currentAudio = null;
                this.playNextInQueue();
            };
            
            this.currentAudio.onerror = (error) => {
                console.error('Audio playback error:', error);
                this.updateStatus('Audio error');
                this.currentAudio = null;
                this.playNextInQueue();
            };
            
            // Play audio
            await this.currentAudio.play();
            
        } catch (error) {
            console.error('Error playing TTS audio:', error);
            this.updateStatus('Playback failed');
        }
    }
    
    queueTTS(audioUrl) {
        if (this.currentAudio && !this.currentAudio.ended) {
            // Add to queue if audio is currently playing
            this.audioQueue.push(audioUrl);
        } else {
            // Play immediately
            this.playTTS(audioUrl);
        }
    }
    
    playNextInQueue() {
        if (this.audioQueue.length > 0) {
            const nextAudioUrl = this.audioQueue.shift();
            this.playTTS(nextAudioUrl);
        }
    }
    
    stopTTS() {
        if (this.currentAudio) {
            this.currentAudio.pause();
            this.currentAudio = null;
        }
        
        // Clear queue
        this.audioQueue = [];
        
        this.updateStatus('Ready');
    }
    
    setVoice(voiceId) {
        // This will be handled by the backend
        this.app.components.websocket.send({
            type: 'set_voice',
            voice_id: voiceId
        });
        
        console.log('Voice changed to:', voiceId);
    }
    
    startVoiceLevelMonitoring() {
        if (!this.analyser) return;
        
        const bufferLength = this.analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);
        
        const updateLevel = () => {
            if (!this.analyser) return;
            
            this.analyser.getByteFrequencyData(dataArray);
            
            // Calculate average volume
            let sum = 0;
            for (let i = 0; i < bufferLength; i++) {
                sum += dataArray[i];
            }
            
            const average = sum / bufferLength;
            this.voiceLevel = (average / 255) * 100;
            
            // Update visual indicator
            this.updateVoiceLevelDisplay();
            
            requestAnimationFrame(updateLevel);
        };
        
        updateLevel();
    }
    
    updateVoiceLevelDisplay() {
        if (this.voiceLevelElement) {
            const level = Math.min(100, this.voiceLevel);
            this.voiceLevelElement.style.setProperty('--voice-level', `${level}%`);
            
            // Add CSS for voice level visualization
            if (!document.getElementById('voice-level-style')) {
                const style = document.createElement('style');
                style.id = 'voice-level-style';
                style.textContent = `
                    .voice-level::after {
                        width: var(--voice-level, 0%) !important;
                    }
                `;
                document.head.appendChild(style);
            }
        }
    }
    
    updateStatus(status) {
        if (this.voiceStatusElement) {
            this.voiceStatusElement.textContent = status;
        }
    }
    
    updateVoiceButton(active) {
        const voiceBtn = document.getElementById('voice-toggle');
        if (voiceBtn) {
            voiceBtn.classList.toggle('active', active);
            
            const icon = voiceBtn.querySelector('i');
            const text = voiceBtn.querySelector('span');
            
            if (active) {
                if (icon) icon.className = 'fas fa-stop';
                if (text) text.textContent = 'Listening...';
            } else {
                if (icon) icon.className = 'fas fa-microphone';
                if (text) text.textContent = 'Push to Talk';
            }
        }
    }
    
    // Utility methods
    isSupported() {
        return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    }
    
    getStatus() {
        return {
            initialized: this.isInitialized,
            listening: this.isListening,
            continuousMode: this.continuousMode,
            supported: this.isSupported(),
            voiceLevel: this.voiceLevel,
            audioPlaying: !!(this.currentAudio && !this.currentAudio.ended),
            queueLength: this.audioQueue.length
        };
    }
    
    cleanup() {
        // Stop any ongoing recognition
        this.stopListening();
        
        // Stop any playing audio
        this.stopTTS();
        
        // Close audio context
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
        
        // Stop microphone stream
        if (this.microphone && this.microphone.mediaStream) {
            this.microphone.mediaStream.getTracks().forEach(track => track.stop());
        }
        
        this.isInitialized = false;
        console.log('Voice manager cleaned up');
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VoiceManager;
}