#!/usr/bin/env python3
"""
Configuration Manager for GPU-Accelerated Vision Engine
"""

import os
import json
from typing import Dict, Any
from pathlib import Path

class ConfigManager:
    def __init__(self):
        self.config_dir = Path("/workspace/gpu_vision_engine/config")
        self.config_dir.mkdir(exist_ok=True)
        self.config_file = self.config_dir / "settings.json"
        self.load_config()
    
    def load_config(self):
        """Load configuration from file or create defaults"""
        default_config = {
            "ollama": {
                "base_url": "http://localhost:11434",
                "timeout": 30,
                "default_model": "hermes3",
                "stream": True
            },
            "ocr": {
                "confidence_threshold": 0.7,
                "languages": ["en"],
                "detection_threshold": 0.3,
                "gpu_enabled": True,
                "use_cuda": True
            },
            "voice": {
                "elevenlabs_api_key": os.getenv("ELEVENLABS_API_KEY", ""),
                "voice_id": "EXAVITQu4vr4xnSDxMaL",  # Bella voice
                "stability": 0.5,
                "similarity_boost": 0.75,
                "speech_rate": 1.0
            },
            "gpu": {
                "device_id": 0,
                "memory_limit": 0.8,  # Use 80% of GPU memory
                "enable_optimization": True
            },
            "video": {
                "fps": 30,
                "resolution": [1280, 720],
                "format": "MJPG"
            },
            "ui": {
                "theme": "dark",
                "auto_scroll": True,
                "show_confidence": True,
                "highlight_text": True
            }
        }
        
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    loaded_config = json.load(f)
                # Merge with defaults
                self.config = self._merge_configs(default_config, loaded_config)
            except Exception as e:
                print(f"Error loading config: {e}")
                self.config = default_config
        else:
            self.config = default_config
        
        self.save_config()
    
    def _merge_configs(self, default: Dict, loaded: Dict) -> Dict:
        """Recursively merge configurations"""
        result = default.copy()
        for key, value in loaded.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        return result
    
    def save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            print(f"Error saving config: {e}")
    
    def get_config(self, section: str = None) -> Dict[str, Any]:
        """Get configuration section or entire config"""
        if section:
            return self.config.get(section, {})
        return self.config
    
    def update_config(self, section: str, updates: Dict[str, Any]):
        """Update configuration section"""
        if section not in self.config:
            self.config[section] = {}
        self.config[section].update(updates)
        self.save_config()
    
    def get_ollama_config(self) -> Dict[str, Any]:
        """Get Ollama-specific configuration"""
        return self.config.get("ollama", {})
    
    def get_ocr_config(self) -> Dict[str, Any]:
        """Get OCR-specific configuration"""
        return self.config.get("ocr", {})
    
    def get_voice_config(self) -> Dict[str, Any]:
        """Get voice-specific configuration"""
        return self.config.get("voice", {})
    
    def get_gpu_config(self) -> Dict[str, Any]:
        """Get GPU-specific configuration"""
        return self.config.get("gpu", {})
    
    def get_video_config(self) -> Dict[str, Any]:
        """Get video-specific configuration"""
        return self.config.get("video", {})
    
    def get_ui_config(self) -> Dict[str, Any]:
        """Get UI-specific configuration"""
        return self.config.get("ui", {})