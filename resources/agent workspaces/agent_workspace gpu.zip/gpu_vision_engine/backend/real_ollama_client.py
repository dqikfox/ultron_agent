#!/usr/bin/env python3
"""
Real Ollama Client for connecting to actual Ollama server
"""

import aiohttp
import asyncio
import json
import logging
from typing import List, Dict, AsyncGenerator, Optional

logger = logging.getLogger(__name__)

class RealOllamaClient:
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url.rstrip('/')
        self.current_model = "hermes3"  # Default to hermes3 as requested
        self.session = None
        
    async def initialize(self):
        """Initialize the HTTP session"""
        self.session = aiohttp.ClientSession()
        
        # Test connection
        try:
            await self.test_connection()
            logger.info(f"✅ Connected to Ollama server at {self.base_url}")
        except Exception as e:
            logger.warning(f"⚠️  Could not connect to Ollama server: {e}")
    
    async def test_connection(self) -> bool:
        """Test if Ollama server is accessible"""
        try:
            async with self.session.get(f"{self.base_url}/api/tags") as response:
                return response.status == 200
        except Exception:
            return False
    
    async def get_models(self) -> List[Dict]:
        """Get list of available models from Ollama"""
        try:
            async with self.session.get(f"{self.base_url}/api/tags") as response:
                if response.status == 200:
                    data = await response.json()
                    models = []
                    for model in data.get("models", []):
                        models.append({
                            "name": model["name"],
                            "size": model.get("size", "Unknown"),
                            "modified": model.get("modified_at", "")
                        })
                    return models
                else:
                    logger.error(f"Failed to get models: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting models: {e}")
            # Return mock models if Ollama is not available
            return [
                {"name": "hermes3", "size": "4.1GB", "modified": "2024-01-01"},
                {"name": "llama2", "size": "3.8GB", "modified": "2024-01-01"},
                {"name": "mistral", "size": "4.2GB", "modified": "2024-01-01"}
            ]
    
    async def set_model(self, model: str) -> bool:
        """Set the active model"""
        try:
            # Test if model exists
            models = await self.get_models()
            model_names = [m["name"] for m in models]
            
            if model in model_names:
                self.current_model = model
                logger.info(f"✅ Switched to model: {model}")
                return True
            else:
                logger.warning(f"⚠️  Model {model} not found. Available: {model_names}")
                return False
        except Exception as e:
            logger.error(f"Error setting model: {e}")
            return False
    
    async def stream_chat(self, text: str) -> AsyncGenerator[str, None]:
        """Stream chat response from Ollama"""
        try:
            # Prepare the request
            payload = {
                "model": self.current_model,
                "prompt": text,
                "stream": True
            }
            
            async with self.session.post(
                f"{self.base_url}/api/generate", 
                json=payload
            ) as response:
                if response.status == 200:
                    async for line in response.content:
                        if line:
                            try:
                                chunk = json.loads(line.decode('utf-8'))
                                if "response" in chunk:
                                    yield chunk["response"]
                                    
                                # Check if this is the final chunk
                                if chunk.get("done", False):
                                    break
                            except json.JSONDecodeError:
                                continue
                else:
                    logger.error(f"Ollama request failed: {response.status}")
                    # Fallback response
                    fallback = f"[{self.current_model}] Error connecting to Ollama. Response: {text}"
                    for word in fallback.split():
                        yield word + " "
                        await asyncio.sleep(0.1)
                        
        except Exception as e:
            logger.error(f"Error in stream_chat: {e}")
            # Fallback response
            fallback = f"[{self.current_model}] Connection error. Your text: {text}"
            for word in fallback.split():
                yield word + " "
                await asyncio.sleep(0.1)
    
    async def get_status(self) -> Dict:
        """Get current status"""
        is_connected = await self.test_connection() if self.session else False
        return {
            "connected": is_connected,
            "model": self.current_model,
            "server_url": self.base_url
        }
    
    def get_current_model(self) -> str:
        """Get current model name"""
        return self.current_model
    
    async def cleanup(self):
        """Clean up resources"""
        if self.session:
            await self.session.close()

# Test function
async def test_ollama_connection():
    """Test the Ollama connection"""
    client = RealOllamaClient()
    await client.initialize()
    
    print("Testing Ollama connection...")
    
    # Test getting models
    models = await client.get_models()
    print(f"Available models: {[m['name'] for m in models]}")
    
    # Test model switching
    if models:
        test_model = models[0]["name"]
        success = await client.set_model(test_model)
        print(f"Model switch to {test_model}: {'Success' if success else 'Failed'}")
    
    # Test chat
    print("Testing chat...")
    response_parts = []
    async for chunk in client.stream_chat("Hello, how are you?"):
        response_parts.append(chunk)
        print(chunk, end="", flush=True)
    print("\n")
    
    await client.cleanup()

if __name__ == "__main__":
    asyncio.run(test_ollama_connection())
