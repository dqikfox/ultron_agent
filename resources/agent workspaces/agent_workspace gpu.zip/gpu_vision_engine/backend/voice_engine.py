#!/usr/bin/env python3
"""
Voice Engine with ElevenLabs TTS Integration
"""

import asyncio
import aiohttp
import os
import logging
import time
import io
from typing import Dict, Any, Optional
from pathlib import Path
try:
    from elevenlabs import generate, voices, set_api_key
except ImportError:
    generate = None
    voices = None
    set_api_key = None

logger = logging.getLogger(__name__)

class VoiceEngine:
    def __init__(self):
        self.api_key = os.getenv("ELEVENLABS_API_KEY")
        self.voice_id = "EXAVITQu4vr4xnSDxMaL"  # Bella voice (default)
        self.available_voices = []
        self.audio_dir = Path("/workspace/gpu_vision_engine/temp/audio")
        self.audio_dir.mkdir(parents=True, exist_ok=True)
        self.settings = {
            "stability": 0.5,
            "similarity_boost": 0.75,
            "style": 0.0,
            "use_speaker_boost": True
        }
        self.initialized = False
        
    async def initialize(self):
        """Initialize ElevenLabs voice engine"""
        try:
            if not self.api_key:
                logger.error("ElevenLabs API key not found in environment")
                return False
            
            if set_api_key is None:
                logger.error("ElevenLabs library not available. Install with: pip install elevenlabs")
                return False
            
            # Set API key
            set_api_key(self.api_key)
            
            # Load available voices
            await self.load_voices()
            
            self.initialized = True
            logger.info(f"Voice engine initialized with {len(self.available_voices)} voices")
            return True
            
        except Exception as e:
            logger.error(f"Error initializing voice engine: {e}")
            return False
    
    async def load_voices(self):
        """Load available ElevenLabs voices"""
        try:
            if voices is None:
                return
            
            # Run in executor to avoid blocking
            voice_list = await asyncio.get_event_loop().run_in_executor(
                None, voices
            )
            
            self.available_voices = []
            for voice in voice_list:
                self.available_voices.append({
                    "id": voice.voice_id,
                    "name": voice.name,
                    "category": voice.category,
                    "description": getattr(voice, 'description', '')
                })
            
            logger.info(f"Loaded {len(self.available_voices)} voices")
            
        except Exception as e:
            logger.error(f"Error loading voices: {e}")
    
    async def generate_speech(self, text: str, voice_id: Optional[str] = None) -> str:
        """Generate speech from text using ElevenLabs TTS"""
        try:
            if not self.initialized:
                raise Exception("Voice engine not initialized")
            
            if not text or not text.strip():
                raise Exception("Empty text provided")
            
            # Use provided voice_id or default
            target_voice_id = voice_id or self.voice_id
            
            # Generate unique filename
            timestamp = int(time.time() * 1000)
            filename = f"tts_{timestamp}.mp3"
            file_path = self.audio_dir / filename
            
            # Generate audio using ElevenLabs
            audio_data = await asyncio.get_event_loop().run_in_executor(
                None, 
                lambda: generate(
                    text=text,
                    voice=target_voice_id,
                    model="eleven_monolingual_v1",
                    stream=False,
                    latency=1
                )
            )
            
            # Save audio file
            with open(file_path, 'wb') as f:
                f.write(audio_data)
            
            # Return relative URL for web access
            return f"/api/audio/{filename}"
            
        except Exception as e:
            logger.error(f"Error generating speech: {e}")
            raise
    
    async def generate_speech_stream(self, text: str, voice_id: Optional[str] = None):
        """Generate streaming speech from text"""
        try:
            if not self.initialized:
                raise Exception("Voice engine not initialized")
            
            target_voice_id = voice_id or self.voice_id
            
            # For now, return the complete audio file
            # ElevenLabs streaming requires different implementation
            audio_url = await self.generate_speech(text, target_voice_id)
            return audio_url
            
        except Exception as e:
            logger.error(f"Error generating streaming speech: {e}")
            raise
    
    def set_voice(self, voice_id: str) -> bool:
        """Set the current voice"""
        try:
            # Validate voice ID
            valid_voices = [v["id"] for v in self.available_voices]
            if voice_id in valid_voices:
                self.voice_id = voice_id
                logger.info(f"Voice set to: {voice_id}")
                return True
            else:
                logger.error(f"Invalid voice ID: {voice_id}")
                return False
        except Exception as e:
            logger.error(f"Error setting voice: {e}")
            return False
    
    def update_settings(self, settings: Dict[str, Any]):
        """Update voice generation settings"""
        try:
            for key, value in settings.items():
                if key in self.settings:
                    self.settings[key] = value
            logger.info(f"Voice settings updated: {settings}")
        except Exception as e:
            logger.error(f"Error updating voice settings: {e}")
    
    def get_voices(self) -> list:
        """Get list of available voices"""
        return self.available_voices
    
    def get_status(self) -> Dict[str, Any]:
        """Get voice engine status"""
        return {
            "initialized": self.initialized,
            "api_key_set": bool(self.api_key),
            "current_voice_id": self.voice_id,
            "available_voices_count": len(self.available_voices),
            "settings": self.settings.copy(),
            "audio_directory": str(self.audio_dir)
        }
    
    async def test_voice(self, voice_id: Optional[str] = None) -> str:
        """Test voice generation with sample text"""
        try:
            test_text = "Hello! This is a test of the voice synthesis system."
            audio_url = await self.generate_speech(test_text, voice_id)
            return audio_url
        except Exception as e:
            logger.error(f"Error testing voice: {e}")
            raise
    
    def cleanup_old_files(self, max_age_hours: int = 24):
        """Cleanup old audio files"""
        try:
            current_time = time.time()
            max_age_seconds = max_age_hours * 3600
            
            for audio_file in self.audio_dir.glob("*.mp3"):
                file_age = current_time - audio_file.stat().st_mtime
                if file_age > max_age_seconds:
                    audio_file.unlink()
                    logger.info(f"Deleted old audio file: {audio_file.name}")
                    
        except Exception as e:
            logger.error(f"Error cleaning up audio files: {e}")
    
    async def cleanup(self):
        """Cleanup voice engine resources"""
        try:
            # Cleanup old audio files
            self.cleanup_old_files()
            logger.info("Voice engine cleaned up")
        except Exception as e:
            logger.error(f"Error cleaning up voice engine: {e}")