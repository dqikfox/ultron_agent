#!/usr/bin/env python3
"""
GPU-Accelerated OCR Engine using PaddleOCR
"""

import asyncio
import cv2
import numpy as np
import logging
import time
import io
from typing import List, Dict, Any, Optional, Tuple
from PIL import Image
try:
    from paddleocr import PaddleOCR
except ImportError:
    PaddleOCR = None

from gpu_manager import GPUManager

logger = logging.getLogger(__name__)

class OCREngine:
    def __init__(self, gpu_manager: GPUManager):
        self.gpu_manager = gpu_manager
        self.ocr_instance = None
        self.confidence_threshold = 0.7
        self.detection_threshold = 0.3
        self.processing_stats = {
            "total_processed": 0,
            "avg_processing_time": 0,
            "last_processing_time": 0,
            "errors": 0
        }
        self.initialize_ocr()
    
    def initialize_ocr(self):
        """Initialize PaddleOCR with GPU acceleration"""
        try:
            if PaddleOCR is None:
                logger.error("PaddleOCR not available. Install with: pip install paddleocr")
                return False
            
            # Configure PaddleOCR with GPU if available
            use_gpu = self.gpu_manager.is_gpu_available()
            
            self.ocr_instance = PaddleOCR(
                use_angle_cls=True,
                lang='en',
                use_gpu=use_gpu,
                gpu_mem=int(8000 * self.gpu_manager.memory_limit),  # GPU memory in MB
                det_db_thresh=self.detection_threshold,
                det_db_box_thresh=0.6,
                det_db_unclip_ratio=1.5,
                use_space_char=True,
                drop_score=self.confidence_threshold
            )
            
            logger.info(f"PaddleOCR initialized with GPU: {use_gpu}")
            return True
            
        except Exception as e:
            logger.error(f"Error initializing OCR engine: {e}")
            return False
    
    def set_confidence_threshold(self, threshold: float):
        """Set confidence threshold for OCR results"""
        if 0.0 <= threshold <= 1.0:
            self.confidence_threshold = threshold
            logger.info(f"OCR confidence threshold set to {threshold}")
        else:
            logger.warning(f"Invalid confidence threshold: {threshold}")
    
    def set_detection_threshold(self, threshold: float):
        """Set detection threshold for text regions"""
        if 0.0 <= threshold <= 1.0:
            self.detection_threshold = threshold
            logger.info(f"OCR detection threshold set to {threshold}")
        else:
            logger.warning(f"Invalid detection threshold: {threshold}")
    
    async def process_frame(self, frame_data: bytes) -> Dict[str, Any]:
        """Process a single frame for OCR"""
        if not self.ocr_instance:
            return {"error": "OCR engine not initialized", "results": []}
        
        start_time = time.time()
        
        try:
            # Convert bytes to numpy array
            nparr = np.frombuffer(frame_data, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if frame is None:
                return {"error": "Invalid frame data", "results": []}
            
            # Run OCR processing
            result = await asyncio.get_event_loop().run_in_executor(
                None, self._process_image, frame
            )
            
            processing_time = time.time() - start_time
            self._update_stats(processing_time, success=True)
            
            return {
                "results": result,
                "processing_time": processing_time,
                "frame_shape": frame.shape,
                "timestamp": time.time()
            }
            
        except Exception as e:
            processing_time = time.time() - start_time
            self._update_stats(processing_time, success=False)
            logger.error(f"Error processing frame: {e}")
            return {"error": str(e), "results": []}
    
    def _process_image(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """Process image with PaddleOCR"""
        try:
            # Run OCR
            ocr_results = self.ocr_instance.ocr(image, cls=True)
            
            if not ocr_results or not ocr_results[0]:
                return []
            
            processed_results = []
            for detection in ocr_results[0]:
                if len(detection) >= 2:
                    bbox, (text, confidence) = detection
                    
                    # Filter by confidence threshold
                    if confidence >= self.confidence_threshold:
                        processed_results.append({
                            "text": text,
                            "confidence": float(confidence),
                            "bbox": [[float(point[0]), float(point[1])] for point in bbox],
                            "center": self._get_bbox_center(bbox)
                        })
            
            return processed_results
            
        except Exception as e:
            logger.error(f"Error in PaddleOCR processing: {e}")
            return []
    
    def _get_bbox_center(self, bbox: List[List[float]]) -> Tuple[float, float]:
        """Calculate center point of bounding box"""
        try:
            x_coords = [point[0] for point in bbox]
            y_coords = [point[1] for point in bbox]
            center_x = sum(x_coords) / len(x_coords)
            center_y = sum(y_coords) / len(y_coords)
            return (center_x, center_y)
        except:
            return (0.0, 0.0)
    
    def _update_stats(self, processing_time: float, success: bool):
        """Update processing statistics"""
        self.processing_stats["last_processing_time"] = processing_time
        
        if success:
            total = self.processing_stats["total_processed"]
            avg = self.processing_stats["avg_processing_time"]
            new_avg = (avg * total + processing_time) / (total + 1)
            
            self.processing_stats["total_processed"] += 1
            self.processing_stats["avg_processing_time"] = new_avg
        else:
            self.processing_stats["errors"] += 1
    
    def get_status(self) -> Dict[str, Any]:
        """Get OCR engine status and statistics"""
        return {
            "initialized": self.ocr_instance is not None,
            "gpu_enabled": self.gpu_manager.is_gpu_available(),
            "confidence_threshold": self.confidence_threshold,
            "detection_threshold": self.detection_threshold,
            "stats": self.processing_stats.copy()
        }
    
    def extract_text_only(self, results: List[Dict[str, Any]]) -> str:
        """Extract only text from OCR results"""
        if not results:
            return ""
        
        texts = [result["text"] for result in results if "text" in result]
        return " ".join(texts)
    
    def get_high_confidence_text(self, results: List[Dict[str, Any]], min_confidence: float = 0.8) -> List[Dict[str, Any]]:
        """Filter results by minimum confidence"""
        return [result for result in results if result.get("confidence", 0) >= min_confidence]
    
    def process_image_file(self, image_path: str) -> Dict[str, Any]:
        """Process an image file for OCR"""
        try:
            image = cv2.imread(image_path)
            if image is None:
                return {"error": "Could not load image", "results": []}
            
            start_time = time.time()
            results = self._process_image(image)
            processing_time = time.time() - start_time
            
            self._update_stats(processing_time, success=True)
            
            return {
                "results": results,
                "processing_time": processing_time,
                "image_shape": image.shape,
                "timestamp": time.time()
            }
            
        except Exception as e:
            logger.error(f"Error processing image file: {e}")
            return {"error": str(e), "results": []}
    
    def create_overlay_image(self, image: np.ndarray, ocr_results: List[Dict[str, Any]]) -> np.ndarray:
        """Create image with OCR results overlay"""
        try:
            overlay = image.copy()
            
            for result in ocr_results:
                bbox = result.get("bbox", [])
                text = result.get("text", "")
                confidence = result.get("confidence", 0)
                
                if bbox and len(bbox) >= 4:
                    # Convert bbox to integer points
                    points = np.array(bbox, dtype=np.int32)
                    
                    # Draw bounding box
                    cv2.polylines(overlay, [points], True, (0, 255, 0), 2)
                    
                    # Draw text and confidence
                    text_label = f"{text} ({confidence:.2f})"
                    text_pos = (int(bbox[0][0]), int(bbox[0][1]) - 10)
                    cv2.putText(overlay, text_label, text_pos, cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
            
            return overlay
            
        except Exception as e:
            logger.error(f"Error creating overlay: {e}")
            return image
    
    def cleanup(self):
        """Cleanup OCR resources"""
        try:
            if self.ocr_instance:
                # PaddleOCR cleanup if needed
                self.ocr_instance = None
            logger.info("OCR engine cleaned up")
        except Exception as e:
            logger.error(f"Error cleaning up OCR engine: {e}")