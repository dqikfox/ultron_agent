#!/usr/bin/env python3
"""
GPU-Accelerated Vision Engine - Production Server

Connects to real Ollama server with configurable URL
"""

import asyncio
import json
import logging
import os
from typing import List
from datetime import datetime
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn

from real_ollama_client import RealOllamaClient

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://host.docker.internal:11434")  # Default for Docker
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")

class RealVoiceEngine:
    def __init__(self):
        self.enabled = bool(ELEVENLABS_API_KEY)
        self.voice_id = "EXAVITQu4vr4xnSDxMaL"  # Default voice
        
    async def initialize(self):
        if self.enabled:
            logger.info("✅ ElevenLabs Voice Engine initialized")
        else:
            logger.warning("⚠️  ElevenLabs API key not found, TTS disabled")
    
    async def generate_speech(self, text: str):
        if not self.enabled:
            return f"/api/audio/mock_tts_{datetime.now().strftime('%H%M%S')}.mp3"
        
        try:
            # Use ElevenLabs API
            import elevenlabs
            
            audio = elevenlabs.generate(
                text=text,
                voice=self.voice_id,
                api_key=ELEVENLABS_API_KEY
            )
            
            # Save audio file
            filename = f"tts_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp3"
            filepath = f"/workspace/gpu_vision_engine/temp/audio/{filename}"
            
            with open(filepath, "wb") as f:
                f.write(audio)
            
            return f"/api/audio/{filename}"
        except Exception as e:
            logger.error(f"TTS Error: {e}")
            return f"/api/audio/mock_tts_{datetime.now().strftime('%H%M%S')}.mp3"

class MockOCREngine:
    def __init__(self):
        self.is_running = False
        self.sample_texts = [
            "GPU-Accelerated Vision Engine",
            "Real-time OCR Processing Active", 
            f"Connected to Ollama: {OLLAMA_URL}",
            "AI Model Integration Ready",
            "Voice Commands Enabled",
            "Dynamic Model Switching Available"
        ]
        self.text_index = 0
    
    async def get_mock_result(self):
        text = self.sample_texts[self.text_index % len(self.sample_texts)]
        self.text_index += 1
        return {
            "text": text,
            "confidence": 0.95,
            "bounding_boxes": [{"x": 50, "y": 50, "width": 400, "height": 40}],
            "timestamp": datetime.now().isoformat()
        }

# Global components
ollama_client = RealOllamaClient(OLLAMA_URL)
voice_engine = RealVoiceEngine()
ocr_engine = MockOCREngine()

# WebSocket manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"✅ Client connected. Total: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"❌ Client disconnected. Total: {len(self.active_connections)}")
    
    async def send_to_client(self, websocket: WebSocket, message: dict):
        try:
            await websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Error sending message: {e}")
            self.disconnect(websocket)
    
    async def broadcast(self, message: dict):
        """Send message to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_text(json.dumps(message))
            except Exception:
                disconnected.append(connection)
        
        for conn in disconnected:
            self.disconnect(conn)

manager = ConnectionManager()

# Lifespan events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("🚀 GPU-Accelerated Vision Engine Starting...")
    logger.info(f"🔗 Ollama URL: {OLLAMA_URL}")
    logger.info(f"🎤 ElevenLabs TTS: {'Enabled' if ELEVENLABS_API_KEY else 'Disabled'}")
    
    await ollama_client.initialize()
    await voice_engine.initialize()
    
    # Test Ollama connection
    status = await ollama_client.get_status()
    if status["connected"]:
        models = await ollama_client.get_models()
        logger.info(f"✅ Ollama connected. Available models: {[m['name'] for m in models]}")
    else:
        logger.warning(f"⚠️  Ollama not connected to {OLLAMA_URL}")
    
    logger.info("✅ All components initialized!")
    yield
    
    # Shutdown
    logger.info("🛑 Server shutting down...")
    await ollama_client.cleanup()

# Initialize FastAPI app
app = FastAPI(
    title="GPU-Accelerated Vision Engine",
    description="Real-time OCR with Ollama AI and Voice Interaction",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    
    # Send initial connection info
    status = await ollama_client.get_status()
    await manager.send_to_client(websocket, {
        "type": "connection_established",
        "message": "Connected to GPU Vision Engine",
        "ollama_status": status,
        "server_config": {
            "ollama_url": OLLAMA_URL,
            "tts_enabled": voice_engine.enabled
        }
    })
    
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            await handle_message(websocket, message)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)

async def handle_message(websocket: WebSocket, message: dict):
    """Handle WebSocket messages"""
    msg_type = message.get("type")
    
    try:
        if msg_type == "get_models":
            models = await ollama_client.get_models()
            await manager.send_to_client(websocket, {
                "type": "models_list",
                "models": models,
                "current_model": ollama_client.get_current_model()
            })
        
        elif msg_type == "change_model":
            model = message.get("model", "")
            success = await ollama_client.set_model(model)
            
            # Broadcast model change to all clients
            await manager.broadcast({
                "type": "model_changed",
                "model": model,
                "success": success,
                "message": f"{'Successfully switched to' if success else 'Failed to switch to'} {model}"
            })
        
        elif msg_type == "process_text":
            text = message.get("text", "")
            
            # Send processing started
            await manager.send_to_client(websocket, {
                "type": "ai_processing_started",
                "text": text,
                "model": ollama_client.get_current_model()
            })
            
            # Stream AI response
            full_response = ""
            async for chunk in ollama_client.stream_chat(text):
                full_response += chunk
                await manager.send_to_client(websocket, {
                    "type": "ai_response_chunk",
                    "chunk": chunk
                })
            
            # Send completion
            await manager.send_to_client(websocket, {
                "type": "ai_response_complete",
                "full_text": full_response.strip()
            })
            
            # Generate TTS if enabled
            if voice_engine.enabled and full_response.strip():
                audio_url = await voice_engine.generate_speech(full_response.strip())
                await manager.send_to_client(websocket, {
                    "type": "tts_ready",
                    "audio_url": audio_url,
                    "text": full_response.strip()
                })
        
        elif msg_type == "start_ocr":
            ocr_engine.is_running = True
            await manager.send_to_client(websocket, {
                "type": "ocr_started",
                "message": "OCR processing started (demo mode)"
            })
            
            # Start OCR simulation
            asyncio.create_task(simulate_ocr(websocket))
        
        elif msg_type == "stop_ocr":
            ocr_engine.is_running = False
            await manager.send_to_client(websocket, {
                "type": "ocr_stopped", 
                "message": "OCR processing stopped"
            })
        
        elif msg_type == "voice_command":
            command = message.get("command", "").lower()
            
            await manager.send_to_client(websocket, {
                "type": "voice_command_received",
                "command": command
            })
            
            if "read" in command or "analyze" in command or "what do you see" in command:
                # Get OCR result and process it
                mock_result = await ocr_engine.get_mock_result()
                extracted_text = mock_result["text"]
                
                await handle_message(websocket, {
                    "type": "process_text",
                    "text": f"Voice command '{command}'. I can see: {extracted_text}. Please analyze this."
                })
            elif "start ocr" in command:
                await handle_message(websocket, {"type": "start_ocr"})
            elif "stop ocr" in command:
                await handle_message(websocket, {"type": "stop_ocr"})
            else:
                # Process voice command directly with AI
                await handle_message(websocket, {
                    "type": "process_text",
                    "text": command
                })
        
        elif msg_type == "get_status":
            ollama_status = await ollama_client.get_status()
            status = {
                "ollama": ollama_status,
                "voice": {"enabled": voice_engine.enabled},
                "ocr": {"running": ocr_engine.is_running, "type": "Demo Mode"},
                "gpu": {"available": True, "type": "RTX 3050 Ready"},
                "server": {"ollama_url": OLLAMA_URL}
            }
            await manager.send_to_client(websocket, {
                "type": "system_status",
                "status": status
            })
        
        elif msg_type == "configure_ollama":
            # Allow runtime configuration of Ollama URL
            new_url = message.get("url", "")
            if new_url:
                # Note: In production, this would need proper global state management
                await manager.send_to_client(websocket, {
                    "type": "ollama_reconfigured",
                    "url": new_url,
                    "message": "Ollama URL updated. Please restart server for changes to take effect."
                })
        
        else:
            await manager.send_to_client(websocket, {
                "type": "error",
                "message": f"Unknown message type: {msg_type}"
            })
    
    except Exception as e:
        logger.error(f"Error handling {msg_type}: {e}")
        await manager.send_to_client(websocket, {
            "type": "error",
            "message": f"Error processing {msg_type}: {str(e)}"
        })

async def simulate_ocr(websocket: WebSocket):
    """Simulate continuous OCR processing"""
    while ocr_engine.is_running:
        try:
            result = await ocr_engine.get_mock_result()
            await manager.send_to_client(websocket, {
                "type": "ocr_result",
                "data": result,
                "timestamp": datetime.now().isoformat()
            })
            await asyncio.sleep(4)  # OCR every 4 seconds
        except Exception as e:
            logger.error(f"OCR simulation error: {e}")
            break

# REST endpoints
@app.get("/")
async def root():
    """Serve main web interface"""
    return FileResponse("/workspace/gpu_vision_engine/frontend/index.html")

@app.get("/api/health")
async def health_check():
    ollama_status = await ollama_client.get_status()
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "ollama_connected": ollama_status["connected"],
        "current_model": ollama_status["model"]
    }

@app.get("/api/system/info")
async def system_info():
    ollama_status = await ollama_client.get_status()
    return {
        "version": "1.0.0 Production",
        "components": {
            "ollama": ollama_status["connected"], 
            "voice": voice_engine.enabled, 
            "ocr": True
        },
        "current_model": ollama_status["model"],
        "ollama_url": OLLAMA_URL,
        "connected_clients": len(manager.active_connections)
    }

@app.get("/api/audio/{filename}")
async def get_audio(filename: str):
    """Serve audio files"""
    from pathlib import Path
    audio_path = Path(f"/workspace/gpu_vision_engine/temp/audio/{filename}")
    if audio_path.exists():
        return FileResponse(audio_path, media_type="audio/mpeg")
    else:
        return {"error": "Audio file not found", "filename": filename}

# Mount static files
app.mount("/static", StaticFiles(directory="/workspace/gpu_vision_engine/frontend"), name="static")

if __name__ == "__main__":
    # Create necessary directories
    import os
    os.makedirs("/workspace/gpu_vision_engine/temp/audio", exist_ok=True)
    os.makedirs("/workspace/gpu_vision_engine/logs", exist_ok=True)
    
    print("🚀 GPU-Accelerated Vision Engine - Production Server")
    print(f"🔗 Ollama URL: {OLLAMA_URL}")
    print(f"🎤 ElevenLabs TTS: {'Enabled' if ELEVENLABS_API_KEY else 'Disabled'}")
    print("📝 To connect to your Ollama server:")
    print("   Set environment variable: OLLAMA_URL=http://your-ip:11434")
    print("   Or configure through the web interface")
    print("\n🌐 Starting server on http://localhost:8001")
    
    uvicorn.run(
        "production_server:app",
        host="0.0.0.0",
        port=8001,
        reload=False,
        log_level="info"
    )
