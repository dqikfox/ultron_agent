#!/usr/bin/env python3
"""
Ollama Client for AI Model Integration
"""

import asyncio
import aiohttp
import json
import logging
import time
from typing import Dict, Any, List, Optional, AsyncGenerator

logger = logging.getLogger(__name__)

class OllamaClient:
    def __init__(self, config: Dict[str, Any]):
        self.base_url = config.get("base_url", "http://localhost:11434")
        self.timeout = config.get("timeout", 30)
        self.current_model = config.get("default_model", "hermes3")
        self.stream_enabled = config.get("stream", True)
        self.session = None
        self.available_models = []
        self.last_complete_response = ""
        self.conversation_history = []
        
    async def initialize(self):
        """Initialize Ollama client and check connection"""
        try:
            # Create aiohttp session
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self.session = aiohttp.ClientSession(timeout=timeout)
            
            # Test connection
            await self.check_connection()
            
            # Load available models
            await self.refresh_models()
            
            logger.info(f"Ollama client initialized. Base URL: {self.base_url}")
            logger.info(f"Available models: {len(self.available_models)}")
            
            return True
            
        except Exception as e:
            logger.error(f"Error initializing Ollama client: {e}")
            return False
    
    async def check_connection(self) -> bool:
        """Check if Ollama server is accessible"""
        try:
            if not self.session:
                return False
                
            async with self.session.get(f"{self.base_url}/api/version") as response:
                if response.status == 200:
                    version_info = await response.json()
                    logger.info(f"Connected to Ollama server: {version_info}")
                    return True
                else:
                    logger.error(f"Ollama server returned status: {response.status}")
                    return False
                    
        except Exception as e:
            logger.error(f"Error connecting to Ollama server: {e}")
            return False
    
    async def refresh_models(self) -> List[str]:
        """Refresh list of available models"""
        try:
            if not self.session:
                return []
                
            async with self.session.get(f"{self.base_url}/api/tags") as response:
                if response.status == 200:
                    data = await response.json()
                    models = data.get("models", [])
                    self.available_models = [model["name"] for model in models]
                    logger.info(f"Refreshed models: {self.available_models}")
                    return self.available_models
                else:
                    logger.error(f"Error getting models: {response.status}")
                    return []
                    
        except Exception as e:
            logger.error(f"Error refreshing models: {e}")
            return []
    
    async def get_models(self) -> List[str]:
        """Get list of available models"""
        if not self.available_models:
            await self.refresh_models()
        return self.available_models
    
    async def set_model(self, model_name: str) -> bool:
        """Set the current model"""
        try:
            # Check if model is available
            if model_name not in self.available_models:
                await self.refresh_models()
                
            if model_name in self.available_models:
                self.current_model = model_name
                logger.info(f"Current model set to: {model_name}")
                return True
            else:
                logger.error(f"Model not available: {model_name}")
                return False
                
        except Exception as e:
            logger.error(f"Error setting model: {e}")
            return False
    
    async def generate_response(self, prompt: str, context: str = "") -> str:
        """Generate a single response from Ollama"""
        try:
            if not self.session:
                raise Exception("Ollama client not initialized")
            
            # Prepare the prompt with context
            full_prompt = f"{context}\n\n{prompt}" if context else prompt
            
            payload = {
                "model": self.current_model,
                "prompt": full_prompt,
                "stream": False
            }
            
            async with self.session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    response_text = data.get("response", "")
                    self.last_complete_response = response_text
                    return response_text
                else:
                    raise Exception(f"Ollama API error: {response.status}")
                    
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            raise
    
    async def stream_chat(self, message: str, context: str = "") -> AsyncGenerator[str, None]:
        """Stream chat response from Ollama"""
        try:
            if not self.session:
                raise Exception("Ollama client not initialized")
            
            # Add message to conversation history
            self.conversation_history.append({"role": "user", "content": message})
            
            # Prepare messages for chat API
            messages = self.conversation_history.copy()
            if context:
                messages.insert(0, {"role": "system", "content": context})
            
            payload = {
                "model": self.current_model,
                "messages": messages,
                "stream": True
            }
            
            complete_response = ""
            
            async with self.session.post(
                f"{self.base_url}/api/chat",
                json=payload
            ) as response:
                if response.status == 200:
                    async for line in response.content:
                        if line:
                            try:
                                chunk_data = json.loads(line.decode('utf-8'))
                                if "message" in chunk_data:
                                    content = chunk_data["message"].get("content", "")
                                    if content:
                                        complete_response += content
                                        yield content
                                        
                                if chunk_data.get("done", False):
                                    break
                                    
                            except json.JSONDecodeError:
                                continue
                else:
                    raise Exception(f"Ollama API error: {response.status}")
            
            # Add assistant response to conversation history
            if complete_response:
                self.conversation_history.append({"role": "assistant", "content": complete_response})
                self.last_complete_response = complete_response
                
                # Keep conversation history manageable
                if len(self.conversation_history) > 20:
                    self.conversation_history = self.conversation_history[-20:]
                    
        except Exception as e:
            logger.error(f"Error streaming chat: {e}")
            yield f"Error: {str(e)}"
    
    async def analyze_text(self, text: str) -> str:
        """Analyze extracted OCR text"""
        try:
            prompt = f"Please analyze the following text that was extracted from an image using OCR. Provide insights, corrections if needed, and explain what this text might be about:\n\n{text}"
            return await self.generate_response(prompt)
        except Exception as e:
            logger.error(f"Error analyzing text: {e}")
            return f"Error analyzing text: {str(e)}"
    
    async def summarize_text(self, text: str) -> str:
        """Summarize extracted OCR text"""
        try:
            prompt = f"Please provide a concise summary of the following text:\n\n{text}"
            return await self.generate_response(prompt)
        except Exception as e:
            logger.error(f"Error summarizing text: {e}")
            return f"Error summarizing text: {str(e)}"
    
    async def translate_text(self, text: str, target_language: str = "Spanish") -> str:
        """Translate extracted OCR text"""
        try:
            prompt = f"Please translate the following text to {target_language}:\n\n{text}"
            return await self.generate_response(prompt)
        except Exception as e:
            logger.error(f"Error translating text: {e}")
            return f"Error translating text: {str(e)}"
    
    def get_last_complete_response(self) -> str:
        """Get the last complete response"""
        return self.last_complete_response
    
    def clear_conversation(self):
        """Clear conversation history"""
        self.conversation_history = []
        logger.info("Conversation history cleared")
    
    async def get_status(self) -> Dict[str, Any]:
        """Get Ollama client status"""
        is_connected = await self.check_connection() if self.session else False
        
        return {
            "connected": is_connected,
            "base_url": self.base_url,
            "current_model": self.current_model,
            "available_models": self.available_models,
            "conversation_length": len(self.conversation_history),
            "stream_enabled": self.stream_enabled
        }
    
    async def cleanup(self):
        """Cleanup Ollama client resources"""
        try:
            if self.session:
                await self.session.close()
                self.session = None
            logger.info("Ollama client cleaned up")
        except Exception as e:
            logger.error(f"Error cleaning up Ollama client: {e}")