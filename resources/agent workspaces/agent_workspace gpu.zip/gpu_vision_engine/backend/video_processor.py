#!/usr/bin/env python3
"""
Video Processor for Real-time OCR Processing
"""

import asyncio
import cv2
import numpy as np
import logging
import time
import threading
import queue
from typing import Dict, Any, Callable, Optional
from concurrent.futures import ThreadPoolExecutor

from ocr_engine import OCREngine
from gpu_manager import GPUManager

logger = logging.getLogger(__name__)

class VideoProcessor:
    def __init__(self, ocr_engine: OCREngine, gpu_manager: GPUManager):
        self.ocr_engine = ocr_engine
        self.gpu_manager = gpu_manager
        self.processing = False
        self.frame_queue = queue.Queue(maxsize=10)
        self.result_callback = None
        self.processing_thread = None
        self.capture_thread = None
        self.camera = None
        self.fps = 30
        self.frame_skip = 2  # Process every 2nd frame
        self.frame_count = 0
        self.stats = {
            "frames_processed": 0,
            "avg_fps": 0,
            "last_processing_time": 0,
            "errors": 0,
            "active": False
        }
        self.executor = ThreadPoolExecutor(max_workers=2)
        
    async def start_processing(self, config: Dict[str, Any], callback: Callable):
        """Start video processing with OCR"""
        try:
            if self.processing:
                logger.warning("Video processing already active")
                return
            
            self.result_callback = callback
            self.processing = True
            self.stats["active"] = True
            
            # Configure processing parameters
            self.fps = config.get("fps", 30)
            self.frame_skip = config.get("frame_skip", 2)
            camera_index = config.get("camera_index", 0)
            
            # Initialize camera
            self.camera = cv2.VideoCapture(camera_index)
            if not self.camera.isOpened():
                raise Exception(f"Could not open camera {camera_index}")
            
            # Set camera properties
            self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
            self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
            self.camera.set(cv2.CAP_PROP_FPS, self.fps)
            
            # Start processing threads
            self.capture_thread = threading.Thread(target=self._capture_frames, daemon=True)
            self.processing_thread = threading.Thread(target=self._process_frames, daemon=True)
            
            self.capture_thread.start()
            self.processing_thread.start()
            
            logger.info(f"Video processing started with camera {camera_index}")
            
        except Exception as e:
            logger.error(f"Error starting video processing: {e}")
            self.processing = False
            self.stats["active"] = False
            raise
    
    def stop_processing(self):
        """Stop video processing"""
        try:
            self.processing = False
            self.stats["active"] = False
            
            # Release camera
            if self.camera:
                self.camera.release()
                self.camera = None
            
            # Clear frame queue
            while not self.frame_queue.empty():
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    break
            
            logger.info("Video processing stopped")
            
        except Exception as e:
            logger.error(f"Error stopping video processing: {e}")
    
    def _capture_frames(self):
        """Capture frames from camera in separate thread"""
        try:
            frame_time = 1.0 / self.fps
            last_capture = 0
            
            while self.processing and self.camera:
                current_time = time.time()
                
                # Control frame rate
                if current_time - last_capture < frame_time:
                    time.sleep(0.001)  # Small sleep to prevent busy waiting
                    continue
                
                ret, frame = self.camera.read()
                if not ret:
                    logger.error("Failed to capture frame")
                    continue
                
                self.frame_count += 1
                
                # Skip frames based on frame_skip setting
                if self.frame_count % self.frame_skip != 0:
                    continue
                
                # Add frame to queue (non-blocking)
                try:
                    self.frame_queue.put_nowait({
                        "frame": frame,
                        "timestamp": current_time,
                        "frame_id": self.frame_count
                    })
                except queue.Full:
                    # Remove oldest frame if queue is full
                    try:
                        self.frame_queue.get_nowait()
                        self.frame_queue.put_nowait({
                            "frame": frame,
                            "timestamp": current_time,
                            "frame_id": self.frame_count
                        })
                    except queue.Empty:
                        pass
                
                last_capture = current_time
                
        except Exception as e:
            logger.error(f"Error in frame capture: {e}")
            self.stats["errors"] += 1
    
    def _process_frames(self):
        """Process frames with OCR in separate thread"""
        try:
            while self.processing:
                try:
                    # Get frame from queue
                    frame_data = self.frame_queue.get(timeout=1.0)
                    frame = frame_data["frame"]
                    timestamp = frame_data["timestamp"]
                    frame_id = frame_data["frame_id"]
                    
                    start_time = time.time()
                    
                    # Convert frame to bytes for OCR processing
                    _, buffer = cv2.imencode('.jpg', frame)
                    frame_bytes = buffer.tobytes()
                    
                    # Process with OCR (run in executor to avoid blocking)
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    ocr_result = loop.run_until_complete(
                        self.ocr_engine.process_frame(frame_bytes)
                    )
                    loop.close()
                    
                    processing_time = time.time() - start_time
                    
                    # Update statistics
                    self._update_processing_stats(processing_time)
                    
                    # Prepare result with frame info
                    result = {
                        "frame_id": frame_id,
                        "timestamp": timestamp,
                        "processing_time": processing_time,
                        "ocr_results": ocr_result.get("results", []),
                        "frame_shape": frame.shape,
                        "text_found": len(ocr_result.get("results", [])) > 0
                    }
                    
                    # Send result via callback
                    if self.result_callback:
                        try:
                            self.result_callback(result)
                        except Exception as e:
                            logger.error(f"Error in result callback: {e}")
                    
                except queue.Empty:
                    continue
                except Exception as e:
                    logger.error(f"Error processing frame: {e}")
                    self.stats["errors"] += 1
                    
        except Exception as e:
            logger.error(f"Error in frame processing thread: {e}")
    
    def _update_processing_stats(self, processing_time: float):
        """Update processing statistics"""
        self.stats["frames_processed"] += 1
        self.stats["last_processing_time"] = processing_time
        
        # Calculate average FPS
        if self.stats["frames_processed"] > 0:
            self.stats["avg_fps"] = 1.0 / processing_time if processing_time > 0 else 0
    
    async def capture_single_frame(self) -> Optional[Dict[str, Any]]:
        """Capture and process a single frame"""
        try:
            if not self.camera or not self.camera.isOpened():
                # Try to open camera for single frame capture
                self.camera = cv2.VideoCapture(0)
                if not self.camera.isOpened():
                    raise Exception("Could not open camera")
            
            ret, frame = self.camera.read()
            if not ret:
                raise Exception("Failed to capture frame")
            
            # Convert frame to bytes
            _, buffer = cv2.imencode('.jpg', frame)
            frame_bytes = buffer.tobytes()
            
            # Process with OCR
            start_time = time.time()
            ocr_result = await self.ocr_engine.process_frame(frame_bytes)
            processing_time = time.time() - start_time
            
            return {
                "timestamp": time.time(),
                "processing_time": processing_time,
                "ocr_results": ocr_result.get("results", []),
                "frame_shape": frame.shape,
                "text_found": len(ocr_result.get("results", [])) > 0
            }
            
        except Exception as e:
            logger.error(f"Error capturing single frame: {e}")
            raise
    
    async def process_screen_capture(self) -> Optional[Dict[str, Any]]:
        """Capture and process screen content"""
        try:
            # Use different method for screen capture
            # This is a placeholder - actual implementation would use
            # libraries like mss or pyautogui for screen capture
            
            # For now, return camera capture
            return await self.capture_single_frame()
            
        except Exception as e:
            logger.error(f"Error in screen capture: {e}")
            raise
    
    def get_status(self) -> Dict[str, Any]:
        """Get video processor status"""
        status = self.stats.copy()
        status.update({
            "camera_available": self.camera is not None and self.camera.isOpened() if self.camera else False,
            "processing_active": self.processing,
            "queue_size": self.frame_queue.qsize(),
            "frame_skip": self.frame_skip,
            "target_fps": self.fps
        })
        return status
    
    def set_frame_skip(self, skip: int):
        """Set frame skip rate (process every Nth frame)"""
        if skip >= 1:
            self.frame_skip = skip
            logger.info(f"Frame skip set to: {skip}")
    
    def set_fps(self, fps: int):
        """Set target FPS"""
        if 1 <= fps <= 60:
            self.fps = fps
            if self.camera:
                self.camera.set(cv2.CAP_PROP_FPS, fps)
            logger.info(f"Target FPS set to: {fps}")
    
    def cleanup(self):
        """Cleanup video processor resources"""
        try:
            self.stop_processing()
            
            if self.executor:
                self.executor.shutdown(wait=False)
            
            logger.info("Video processor cleaned up")
            
        except Exception as e:
            logger.error(f"Error cleaning up video processor: {e}")