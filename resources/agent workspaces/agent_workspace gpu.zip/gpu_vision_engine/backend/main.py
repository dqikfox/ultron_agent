#!/usr/bin/env python3
"""
GPU-Accelerated Vision Engine - Main FastAPI Server

Real-time OCR processing with Ollama integration and ElevenLabs TTS
Optimized for RTX 3050 GPU acceleration
"""

import asyncio
import os
import json
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
import threading
import queue
import time
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
import uvicorn

# Import custom modules
from ocr_engine import OCREngine
from ollama_client import OllamaClient
from voice_engine import VoiceEngine
from gpu_manager import GPUManager
from video_processor import VideoProcessor
from config_manager import ConfigManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="GPU-Accelerated Vision Engine",
    description="Real-time OCR with Ollama AI and Voice Interaction",
    version="1.0.0"
)

# CORS configuration for web interface
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global components
config_manager = ConfigManager()
ocr_engine = None
ollama_client = None
voice_engine = None
gpu_manager = None
video_processor = None

# WebSocket connections manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.lock = threading.Lock()
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        with self.lock:
            self.active_connections.append(websocket)
        logger.info(f"Client connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        with self.lock:
            if websocket in self.active_connections:
                self.active_connections.remove(websocket)
        logger.info(f"Client disconnected. Total connections: {len(self.active_connections)}")
    
    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        if not self.active_connections:
            return
        
        message_str = json.dumps(message)
        disconnected = []
        
        for connection in self.active_connections.copy():
            try:
                await connection.send_text(message_str)
            except Exception as e:
                logger.error(f"Error sending message: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)
    
    async def send_to_client(self, websocket: WebSocket, message: dict):
        """Send message to specific client"""
        try:
            await websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Error sending message to client: {e}")
            self.disconnect(websocket)

manager = ConnectionManager()

@app.on_event("startup")
async def startup_event():
    """Initialize all system components"""
    global ocr_engine, ollama_client, voice_engine, gpu_manager, video_processor
    
    logger.info("Initializing GPU-Accelerated Vision Engine...")
    
    try:
        # Initialize GPU manager first
        gpu_manager = GPUManager()
        gpu_info = gpu_manager.get_gpu_info()
        logger.info(f"GPU Info: {gpu_info}")
        
        # Initialize OCR engine with GPU acceleration
        ocr_engine = OCREngine(gpu_manager=gpu_manager)
        logger.info("OCR Engine initialized")
        
        # Initialize Ollama client
        ollama_client = OllamaClient(config_manager.get_ollama_config())
        await ollama_client.initialize()
        logger.info("Ollama Client initialized")
        
        # Initialize voice engine with ElevenLabs
        voice_engine = VoiceEngine()
        await voice_engine.initialize()
        logger.info("Voice Engine initialized")
        
        # Initialize video processor
        video_processor = VideoProcessor(ocr_engine, gpu_manager)
        logger.info("Video Processor initialized")
        
        logger.info("All components initialized successfully!")
        
    except Exception as e:
        logger.error(f"Startup error: {e}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup resources"""
    global ocr_engine, ollama_client, voice_engine, gpu_manager, video_processor
    
    logger.info("Shutting down GPU-Accelerated Vision Engine...")
    
    if voice_engine:
        await voice_engine.cleanup()
    if ollama_client:
        await ollama_client.cleanup()
    if video_processor:
        video_processor.cleanup()
    if gpu_manager:
        gpu_manager.cleanup()
    
    logger.info("Shutdown complete")

# WebSocket endpoint for real-time communication
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    
    try:
        while True:
            # Receive messages from client
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle different message types
            await handle_websocket_message(websocket, message)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)

async def handle_websocket_message(websocket: WebSocket, message: dict):
    """Handle incoming WebSocket messages"""
    msg_type = message.get("type")
    
    try:
        if msg_type == "start_ocr":
            await start_ocr_processing(websocket, message.get("config", {}))
        elif msg_type == "stop_ocr":
            await stop_ocr_processing(websocket)
        elif msg_type == "process_text":
            await process_text_with_ollama(websocket, message.get("text", ""))
        elif msg_type == "voice_command":
            await handle_voice_command(websocket, message.get("command", ""))
        elif msg_type == "get_models":
            await send_available_models(websocket)
        elif msg_type == "change_model":
            await change_ollama_model(websocket, message.get("model", ""))
        elif msg_type == "get_status":
            await send_system_status(websocket)
        else:
            await manager.send_to_client(websocket, {
                "type": "error",
                "message": f"Unknown message type: {msg_type}"
            })
    except Exception as e:
        logger.error(f"Error handling message {msg_type}: {e}")
        await manager.send_to_client(websocket, {
            "type": "error",
            "message": str(e)
        })

async def start_ocr_processing(websocket: WebSocket, config: dict):
    """Start OCR processing with given configuration"""
    try:
        if video_processor:
            await video_processor.start_processing(config, lambda result: asyncio.create_task(
                manager.send_to_client(websocket, {
                    "type": "ocr_result",
                    "data": result,
                    "timestamp": datetime.now().isoformat()
                })
            ))
            
            await manager.send_to_client(websocket, {
                "type": "ocr_started",
                "message": "OCR processing started"
            })
    except Exception as e:
        logger.error(f"Error starting OCR: {e}")
        raise

async def stop_ocr_processing(websocket: WebSocket):
    """Stop OCR processing"""
    try:
        if video_processor:
            video_processor.stop_processing()
            
            await manager.send_to_client(websocket, {
                "type": "ocr_stopped",
                "message": "OCR processing stopped"
            })
    except Exception as e:
        logger.error(f"Error stopping OCR: {e}")
        raise

async def process_text_with_ollama(websocket: WebSocket, text: str):
    """Process extracted text with Ollama AI"""
    try:
        if not ollama_client:
            raise Exception("Ollama client not initialized")
        
        # Send processing started notification
        await manager.send_to_client(websocket, {
            "type": "ai_processing_started",
            "text": text
        })
        
        # Process with Ollama (streaming response)
        async for chunk in ollama_client.stream_chat(text):
            await manager.send_to_client(websocket, {
                "type": "ai_response_chunk",
                "chunk": chunk
            })
        
        # Generate TTS audio for the complete response
        complete_response = ollama_client.get_last_complete_response()
        if complete_response and voice_engine:
            audio_url = await voice_engine.generate_speech(complete_response)
            await manager.send_to_client(websocket, {
                "type": "tts_ready",
                "audio_url": audio_url,
                "text": complete_response
            })
        
    except Exception as e:
        logger.error(f"Error processing text with Ollama: {e}")
        await manager.send_to_client(websocket, {
            "type": "ai_error",
            "message": str(e)
        })

async def handle_voice_command(websocket: WebSocket, command: str):
    """Handle voice commands"""
    try:
        # Process voice command
        if "start ocr" in command.lower():
            await start_ocr_processing(websocket, {})
        elif "stop ocr" in command.lower():
            await stop_ocr_processing(websocket)
        elif "read" in command.lower() or "analyze" in command.lower():
            # Trigger OCR and AI processing
            await manager.send_to_client(websocket, {
                "type": "voice_command_executed",
                "command": command,
                "action": "ocr_and_analyze"
            })
        else:
            # Send command to Ollama for processing
            await process_text_with_ollama(websocket, command)
        
    except Exception as e:
        logger.error(f"Error handling voice command: {e}")
        await manager.send_to_client(websocket, {
            "type": "voice_error",
            "message": str(e)
        })

async def send_available_models(websocket: WebSocket):
    """Send list of available Ollama models"""
    try:
        if ollama_client:
            models = await ollama_client.get_models()
            await manager.send_to_client(websocket, {
                "type": "models_list",
                "models": models
            })
    except Exception as e:
        logger.error(f"Error getting models: {e}")
        await manager.send_to_client(websocket, {
            "type": "error",
            "message": str(e)
        })

async def change_ollama_model(websocket: WebSocket, model: str):
    """Change active Ollama model"""
    try:
        if ollama_client:
            success = await ollama_client.set_model(model)
            await manager.send_to_client(websocket, {
                "type": "model_changed",
                "model": model,
                "success": success
            })
    except Exception as e:
        logger.error(f"Error changing model: {e}")
        await manager.send_to_client(websocket, {
            "type": "error",
            "message": str(e)
        })

async def send_system_status(websocket: WebSocket):
    """Send system status information"""
    try:
        status = {
            "gpu": gpu_manager.get_status() if gpu_manager else {},
            "ocr": ocr_engine.get_status() if ocr_engine else {},
            "ollama": await ollama_client.get_status() if ollama_client else {},
            "voice": voice_engine.get_status() if voice_engine else {},
            "video": video_processor.get_status() if video_processor else {}
        }
        
        await manager.send_to_client(websocket, {
            "type": "system_status",
            "status": status
        })
    except Exception as e:
        logger.error(f"Error getting system status: {e}")
        await manager.send_to_client(websocket, {
            "type": "error",
            "message": str(e)
        })

# REST API endpoints
@app.get("/")
async def root():
    """Serve the main web interface"""
    return FileResponse("/workspace/gpu_vision_engine/frontend/index.html")

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.get("/api/system/info")
async def system_info():
    """Get system information"""
    try:
        info = {
            "gpu": gpu_manager.get_gpu_info() if gpu_manager else {},
            "components": {
                "ocr_engine": ocr_engine is not None,
                "ollama_client": ollama_client is not None,
                "voice_engine": voice_engine is not None,
                "video_processor": video_processor is not None
            }
        }
        return info
    except Exception as e:
        logger.error(f"Error getting system info: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/upload/frame")
async def upload_frame(file: UploadFile = File(...)):
    """Upload a frame for OCR processing"""
    try:
        if not ocr_engine:
            raise HTTPException(status_code=503, detail="OCR engine not available")
        
        # Read and process the uploaded frame
        content = await file.read()
        result = await ocr_engine.process_frame(content)
        
        return {"result": result, "timestamp": datetime.now().isoformat()}
    except Exception as e:
        logger.error(f"Error processing uploaded frame: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/audio/{filename}")
async def get_audio(filename: str):
    """Serve generated audio files"""
    audio_path = Path(f"/workspace/gpu_vision_engine/temp/audio/{filename}")
    if audio_path.exists():
        return FileResponse(audio_path, media_type="audio/mpeg")
    else:
        raise HTTPException(status_code=404, detail="Audio file not found")

# Mount static files
app.mount("/static", StaticFiles(directory="/workspace/gpu_vision_engine/frontend"), name="static")

if __name__ == "__main__":
    # Create necessary directories
    os.makedirs("/workspace/gpu_vision_engine/temp/audio", exist_ok=True)
    os.makedirs("/workspace/gpu_vision_engine/logs", exist_ok=True)
    
    # Run the server
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="info"
    )