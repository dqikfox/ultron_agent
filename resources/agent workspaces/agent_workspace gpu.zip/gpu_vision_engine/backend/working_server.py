#!/usr/bin/env python3
"""
GPU-Accelerated Vision Engine - Working Server

A simple working version that demonstrates core functionality.
"""

import asyncio
import json
import logging
from typing import List
from datetime import datetime
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Mock classes for testing basic functionality
class MockOllamaClient:
    def __init__(self):
        self.current_model = "hermes3"
        self.available_models = ["hermes3", "llama2", "mistral", "codellama", "qwen", "phi"]
    
    async def get_models(self):
        return [{"name": model, "size": "4.1GB"} for model in self.available_models]
    
    async def set_model(self, model: str):
        if model in self.available_models:
            self.current_model = model
            logger.info(f"Switched to model: {model}")
            return True
        return False
    
    async def stream_chat(self, text: str):
        response = f"[{self.current_model}] AI Analysis: {text}"
        words = response.split()
        for i, word in enumerate(words):
            yield word + (" " if i < len(words) - 1 else "")
            await asyncio.sleep(0.1)
    
    def get_current_model(self):
        return self.current_model

class MockVoiceEngine:
    def __init__(self):
        self.enabled = True
    
    async def generate_speech(self, text: str):
        return f"/api/audio/mock_tts_{datetime.now().strftime('%H%M%S')}.mp3"

class MockOCREngine:
    def __init__(self):
        self.is_running = False
        self.sample_texts = [
            "Welcome to Vision Engine",
            "GPU Acceleration Active", 
            "Real-time OCR Processing",
            "AI Model Integration Ready"
        ]
        self.text_index = 0
    
    async def get_mock_result(self):
        text = self.sample_texts[self.text_index % len(self.sample_texts)]
        self.text_index += 1
        return {
            "text": text,
            "confidence": 0.95,
            "bounding_boxes": [{"x": 50, "y": 50, "width": 300, "height": 40}]
        }

# Global components
ollama_client = MockOllamaClient()
voice_engine = MockVoiceEngine()
ocr_engine = MockOCREngine()

# WebSocket manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"Client connected. Total: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"Client disconnected. Total: {len(self.active_connections)}")
    
    async def send_to_client(self, websocket: WebSocket, message: dict):
        try:
            await websocket.send_text(json.dumps(message))
        except Exception as e:
            logger.error(f"Error sending message: {e}")
            self.disconnect(websocket)

manager = ConnectionManager()

# Lifespan events
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("🚀 GPU-Accelerated Vision Engine Starting...")
    logger.info("✅ Mock components initialized")
    yield
    # Shutdown
    logger.info("🛑 Server shutting down...")

# Initialize FastAPI app with lifespan
app = FastAPI(
    title="GPU-Accelerated Vision Engine",
    description="Real-time OCR with Ollama AI and Voice Interaction",
    version="1.0.0",
    lifespan=lifespan
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    
    # Send initial status
    await manager.send_to_client(websocket, {
        "type": "connection_established",
        "message": "Connected to GPU Vision Engine"
    })
    
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            await handle_message(websocket, message)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)

async def handle_message(websocket: WebSocket, message: dict):
    """Handle WebSocket messages"""
    msg_type = message.get("type")
    
    try:
        if msg_type == "get_models":
            models = await ollama_client.get_models()
            await manager.send_to_client(websocket, {
                "type": "models_list",
                "models": models,
                "current_model": ollama_client.get_current_model()
            })
        
        elif msg_type == "change_model":
            model = message.get("model", "")
            success = await ollama_client.set_model(model)
            await manager.send_to_client(websocket, {
                "type": "model_changed",
                "model": model,
                "success": success,
                "message": f"{'Successfully' if success else 'Failed to'} switch to {model}"
            })
        
        elif msg_type == "process_text":
            text = message.get("text", "")
            
            # Send processing started
            await manager.send_to_client(websocket, {
                "type": "ai_processing_started",
                "text": text
            })
            
            # Stream AI response
            full_response = ""
            async for chunk in ollama_client.stream_chat(text):
                full_response += chunk
                await manager.send_to_client(websocket, {
                    "type": "ai_response_chunk",
                    "chunk": chunk
                })
            
            # Generate TTS
            audio_url = await voice_engine.generate_speech(full_response.strip())
            await manager.send_to_client(websocket, {
                "type": "tts_ready",
                "audio_url": audio_url,
                "text": full_response.strip()
            })
        
        elif msg_type == "start_ocr":
            ocr_engine.is_running = True
            await manager.send_to_client(websocket, {
                "type": "ocr_started",
                "message": "OCR processing started"
            })
            
            # Simulate OCR results
            asyncio.create_task(simulate_ocr(websocket))
        
        elif msg_type == "stop_ocr":
            ocr_engine.is_running = False
            await manager.send_to_client(websocket, {
                "type": "ocr_stopped",
                "message": "OCR processing stopped"
            })
        
        elif msg_type == "voice_command":
            command = message.get("command", "").lower()
            if "read" in command or "analyze" in command:
                # Simulate getting text from OCR and processing it
                mock_result = await ocr_engine.get_mock_result()
                extracted_text = mock_result["text"]
                
                await manager.send_to_client(websocket, {
                    "type": "voice_command_executed",
                    "command": command,
                    "extracted_text": extracted_text
                })
                
                # Process with AI
                await handle_message(websocket, {
                    "type": "process_text",
                    "text": f"Voice command '{command}': {extracted_text}"
                })
            else:
                # Process voice command directly
                await handle_message(websocket, {
                    "type": "process_text", 
                    "text": command
                })
        
        elif msg_type == "get_status":
            status = {
                "ollama": {"connected": True, "model": ollama_client.get_current_model()},
                "voice": {"enabled": True},
                "ocr": {"running": ocr_engine.is_running},
                "gpu": {"available": True, "type": "RTX 3050"}
            }
            await manager.send_to_client(websocket, {
                "type": "system_status",
                "status": status
            })
        
        else:
            await manager.send_to_client(websocket, {
                "type": "error",
                "message": f"Unknown message type: {msg_type}"
            })
    
    except Exception as e:
        logger.error(f"Error handling {msg_type}: {e}")
        await manager.send_to_client(websocket, {
            "type": "error", 
            "message": str(e)
        })

async def simulate_ocr(websocket: WebSocket):
    """Simulate continuous OCR processing"""
    while ocr_engine.is_running:
        try:
            result = await ocr_engine.get_mock_result()
            await manager.send_to_client(websocket, {
                "type": "ocr_result",
                "data": result,
                "timestamp": datetime.now().isoformat()
            })
            await asyncio.sleep(3)  # OCR every 3 seconds
        except Exception as e:
            logger.error(f"OCR simulation error: {e}")
            break

# REST endpoints
@app.get("/")
async def root():
    """Serve main web interface"""
    return FileResponse("/workspace/gpu_vision_engine/frontend/index.html")

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.get("/api/system/info")
async def system_info():
    return {
        "version": "1.0.0",
        "components": {"ollama": True, "voice": True, "ocr": True},
        "current_model": ollama_client.get_current_model()
    }

@app.get("/api/audio/{filename}")
async def get_audio(filename: str):
    return {"message": f"Mock audio: {filename}", "url": f"/static/audio/{filename}"}

# Mount static files
app.mount("/static", StaticFiles(directory="/workspace/gpu_vision_engine/frontend"), name="static")

if __name__ == "__main__":
    uvicorn.run(
        "working_server:app",
        host="0.0.0.0",
        port=8001,
        reload=False,
        log_level="info"
    )
