#!/usr/bin/env python3
"""
GPU Manager for RTX 3050 Optimization
"""

import os
import psutil
import logging
from typing import Dict, Any, Optional
try:
    import cv2
    import numpy as np
except ImportError:
    cv2 = None
    np = None

logger = logging.getLogger(__name__)

class GPUManager:
    def __init__(self):
        self.gpu_available = False
        self.cuda_available = False
        self.gpu_info = {}
        self.memory_limit = 0.8  # Use 80% of GPU memory
        self.initialize_gpu()
    
    def initialize_gpu(self):
        """Initialize GPU and check CUDA availability"""
        try:
            if cv2 is None:
                logger.warning("OpenCV not available, GPU features disabled")
                return
            
            # Check CUDA availability
            cuda_devices = cv2.cuda.getCudaEnabledDeviceCount()
            if cuda_devices > 0:
                self.cuda_available = True
                self.gpu_available = True
                logger.info(f"CUDA devices found: {cuda_devices}")
                
                # Get GPU device info
                self.gpu_info = {
                    "cuda_devices": cuda_devices,
                    "opencv_cuda": cv2.cuda.getCudaEnabledDeviceCount() > 0,
                    "device_count": cuda_devices
                }
                
                # Try to get more detailed GPU info
                try:
                    import subprocess
                    result = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total,memory.used,memory.free', '--format=csv,noheader,nounits'], 
                                         capture_output=True, text=True, timeout=5)
                    if result.returncode == 0:
                        gpu_data = result.stdout.strip().split(',')
                        if len(gpu_data) >= 4:
                            self.gpu_info.update({
                                "name": gpu_data[0].strip(),
                                "memory_total": int(gpu_data[1].strip()),
                                "memory_used": int(gpu_data[2].strip()),
                                "memory_free": int(gpu_data[3].strip())
                            })
                except Exception as e:
                    logger.warning(f"Could not get detailed GPU info: {e}")
                
            else:
                logger.warning("No CUDA devices found")
                
        except Exception as e:
            logger.error(f"Error initializing GPU: {e}")
    
    def get_gpu_info(self) -> Dict[str, Any]:
        """Get GPU information"""
        info = self.gpu_info.copy()
        info.update({
            "available": self.gpu_available,
            "cuda_available": self.cuda_available,
            "memory_limit": self.memory_limit
        })
        return info
    
    def get_status(self) -> Dict[str, Any]:
        """Get current GPU status"""
        status = {
            "available": self.gpu_available,
            "cuda_enabled": self.cuda_available,
            "memory_usage": self._get_memory_usage(),
            "temperature": self._get_gpu_temperature()
        }
        return status
    
    def _get_memory_usage(self) -> Dict[str, Any]:
        """Get GPU memory usage"""
        try:
            import subprocess
            result = subprocess.run(['nvidia-smi', '--query-gpu=memory.used,memory.total', '--format=csv,noheader,nounits'], 
                                 capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                memory_data = result.stdout.strip().split(',')
                if len(memory_data) >= 2:
                    used = int(memory_data[0].strip())
                    total = int(memory_data[1].strip())
                    return {
                        "used_mb": used,
                        "total_mb": total,
                        "free_mb": total - used,
                        "usage_percent": (used / total) * 100 if total > 0 else 0
                    }
        except Exception as e:
            logger.error(f"Error getting GPU memory usage: {e}")
        
        return {"used_mb": 0, "total_mb": 0, "free_mb": 0, "usage_percent": 0}
    
    def _get_gpu_temperature(self) -> float:
        """Get GPU temperature"""
        try:
            import subprocess
            result = subprocess.run(['nvidia-smi', '--query-gpu=temperature.gpu', '--format=csv,noheader,nounits'], 
                                 capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                temp_str = result.stdout.strip()
                return float(temp_str) if temp_str.isdigit() else 0.0
        except Exception as e:
            logger.error(f"Error getting GPU temperature: {e}")
        
        return 0.0
    
    def optimize_for_ocr(self):
        """Optimize GPU settings for OCR processing"""
        if not self.cuda_available:
            logger.warning("CUDA not available, cannot optimize GPU for OCR")
            return False
        
        try:
            # Set GPU memory growth if using TensorFlow/similar
            # This is placeholder for actual optimization
            logger.info("GPU optimized for OCR processing")
            return True
        except Exception as e:
            logger.error(f"Error optimizing GPU for OCR: {e}")
            return False
    
    def create_gpu_mat(self, image):
        """Create GPU matrix for OpenCV operations"""
        if not self.cuda_available or cv2 is None:
            return image
        
        try:
            gpu_mat = cv2.cuda_GpuMat()
            gpu_mat.upload(image)
            return gpu_mat
        except Exception as e:
            logger.error(f"Error creating GPU matrix: {e}")
            return image
    
    def download_gpu_mat(self, gpu_mat):
        """Download matrix from GPU to CPU"""
        if not self.cuda_available or cv2 is None:
            return gpu_mat
        
        try:
            if hasattr(gpu_mat, 'download'):
                result = gpu_mat.download()
                return result
            return gpu_mat
        except Exception as e:
            logger.error(f"Error downloading GPU matrix: {e}")
            return gpu_mat
    
    def cleanup(self):
        """Cleanup GPU resources"""
        try:
            if self.cuda_available and cv2:
                # Cleanup CUDA context
                logger.info("GPU resources cleaned up")
        except Exception as e:
            logger.error(f"Error cleaning up GPU resources: {e}")
    
    def set_memory_limit(self, limit: float):
        """Set GPU memory limit (0.0 to 1.0)"""
        if 0.0 <= limit <= 1.0:
            self.memory_limit = limit
            logger.info(f"GPU memory limit set to {limit * 100}%")
        else:
            logger.warning(f"Invalid memory limit: {limit}")
    
    def is_gpu_available(self) -> bool:
        """Check if GPU is available for processing"""
        return self.gpu_available and self.cuda_available