# GPU-Accelerated Vision Engine

A comprehensive real-time OCR system with AI integration and voice interaction, optimized for RTX 3050 GPU acceleration.

## 🌟 Features

### 🎯 Core Capabilities
- **GPU-Accelerated OCR**: Real-time text extraction using PaddleOCR with CUDA acceleration
- **AI Integration**: Seamless connection to Ollama server for text analysis and conversation
- **Voice Interaction**: High-quality TTS with ElevenLabs and speech recognition
- **Live Video Processing**: Real-time camera and screen capture with OCR overlay
- **Web Interface**: Modern, responsive web UI with real-time updates

### 🔧 Technical Features
- **Real-time Communication**: WebSocket and WebRTC for low-latency streaming
- **Model Management**: Dynamic switching between Ollama AI models
- **Performance Optimization**: GPU memory management and concurrent processing
- **Settings Management**: Comprehensive configuration system
- **Cross-platform**: Web-based interface accessible from any device

## 🚀 Quick Start

### Prerequisites
- **OS**: Windows 11 (optimized for RTX 3050)
- **Python**: 3.8 or higher
- **GPU**: NVIDIA RTX 3050 with CUDA support
- **Ollama**: Running locally on port 11434
- **ElevenLabs API**: API key for voice synthesis

### Installation

1. **Clone and Setup**
   ```bash
   cd /workspace/gpu_vision_engine
   python install_dependencies.py
   ```

2. **Set API Key**
   ```bash
   # Windows
   set ELEVENLABS_API_KEY=your_api_key_here
   
   # Linux/Mac
   export ELEVENLABS_API_KEY=your_api_key_here
   ```

3. **Start Ollama Server**
   ```bash
   ollama serve
   # In another terminal:
   ollama pull hermes3  # or your preferred model
   ```

4. **Run the Application**
   ```bash
   python run_server.py
   ```

5. **Access the Interface**
   Open your browser to `http://localhost:8000`

## 🎮 Usage Guide

### Getting Started
1. **Camera Setup**: Click "Start Camera" to begin live OCR processing
2. **Model Selection**: Choose your preferred Ollama model from the dropdown
3. **Voice Activation**: Use push-to-talk or continuous listening mode
4. **Text Processing**: Detected text is automatically sent to AI for analysis

### Voice Commands
- **"Start OCR"** - Begin camera-based text recognition
- **"Read this text"** - Process current camera view
- **"Analyze document"** - Detailed document analysis
- **"Explain what you see"** - AI description of detected content
- **"Stop"** - Stop current processing

### Keyboard Shortcuts
- **Spacebar**: Push-to-talk (hold and release)
- **Ctrl+S**: Open settings
- **Ctrl+C**: Clear chat
- **Ctrl+E**: Export results
- **Ctrl+R**: Refresh models
- **F11**: Toggle fullscreen
- **Escape**: Close modals

## ⚙️ Configuration

### OCR Settings
- **Confidence Threshold**: Minimum confidence for text detection (0.1-1.0)
- **Frame Skip**: Process every Nth frame for performance (1-10)
- **Languages**: Supported text languages
- **GPU Acceleration**: Enable/disable CUDA processing

### Ollama Integration
- **Server URL**: Ollama server endpoint (default: localhost:11434)
- **Timeout**: Request timeout in seconds
- **Default Model**: Preferred AI model
- **Streaming**: Enable real-time response streaming

### Voice Configuration
- **ElevenLabs Voice**: Select from available voices
- **Stability**: Voice consistency (0.0-1.0)
- **Similarity Boost**: Voice clarity enhancement (0.0-1.0)
- **Speech Rate**: Playback speed adjustment

### GPU Optimization
- **Memory Limit**: GPU memory allocation percentage
- **Device Selection**: CUDA device ID
- **Optimization**: Enable performance optimizations

## 🏗️ Architecture

### Backend Components
- **FastAPI Server**: Main application server with WebSocket support
- **OCR Engine**: PaddleOCR with CUDA acceleration
- **Ollama Client**: AI model communication
- **Voice Engine**: ElevenLabs TTS integration
- **Video Processor**: Real-time frame processing
- **GPU Manager**: Resource optimization

### Frontend Components
- **Web Interface**: Modern HTML5/CSS3/JavaScript UI
- **WebSocket Client**: Real-time server communication
- **Camera Manager**: WebRTC video streaming
- **Voice Manager**: Speech recognition and TTS control
- **Settings Manager**: Configuration management
- **UI Manager**: Interface controls and interactions

### Data Flow
```
Camera → WebRTC → GPU OCR → Text Extraction → Ollama AI → Response → ElevenLabs TTS → Audio Output
          ↓                    ↓                      ↓                        ↓
    Live Video Display → OCR Overlay → Chat Interface → Voice Synthesis → Speaker
```

## 🔧 API Reference

### REST Endpoints
- `GET /` - Main web interface
- `GET /api/health` - Health check
- `GET /api/system/info` - System information
- `POST /api/upload/frame` - Frame upload for processing
- `GET /api/audio/{filename}` - TTS audio file access

### WebSocket Messages
- `start_ocr` - Begin OCR processing
- `stop_ocr` - Stop OCR processing
- `process_text` - Send text to AI
- `voice_command` - Voice command processing
- `get_models` - Request available models
- `change_model` - Switch AI model
- `get_status` - System status request

## 🐛 Troubleshooting

### Common Issues

**Camera Not Working**
- Ensure browser has camera permissions
- Check camera is not in use by other applications
- Try refreshing the page

**GPU Acceleration Not Available**
- Verify CUDA toolkit installation
- Check GPU drivers are up to date
- Ensure OpenCV is built with CUDA support

**Ollama Connection Failed**
- Verify Ollama server is running: `ollama serve`
- Check server URL in settings
- Ensure models are downloaded: `ollama pull modelname`

**Voice Features Not Working**
- Verify ElevenLabs API key is set
- Check microphone permissions in browser
- Ensure stable internet connection

**Poor OCR Performance**
- Adjust confidence threshold in settings
- Ensure good lighting and text visibility
- Try different frame skip settings
- Check GPU memory usage

### Performance Optimization

**For RTX 3050 Optimization**
- Set GPU memory limit to 80% in settings
- Use frame skip of 2-3 for better performance
- Close unnecessary applications
- Monitor GPU temperature

**Network Optimization**
- Use local Ollama server for best performance
- Ensure stable internet for ElevenLabs TTS
- Consider model size vs. processing speed

## 📊 Performance Metrics

The system provides real-time monitoring of:
- **Processing Latency**: OCR + AI + TTS pipeline timing
- **GPU Utilization**: Memory usage and temperature
- **Frame Rate**: Video processing FPS
- **Throughput**: Text processing rate
- **Error Tracking**: System reliability metrics

## 🔒 Security & Privacy

- **Local Processing**: OCR and video processing happen locally
- **API Security**: ElevenLabs API key stored securely
- **No Data Storage**: No persistent storage of processed content
- **Browser Security**: Standard web security practices
- **Optional Cloud**: Only ElevenLabs TTS requires internet

## 🤝 Contributing

Contributions are welcome! Please read our contributing guidelines and submit pull requests for any improvements.

### Development Setup
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **PaddleOCR**: Excellent OCR engine with GPU support
- **Ollama**: Outstanding local AI model serving
- **ElevenLabs**: High-quality text-to-speech synthesis
- **FastAPI**: Modern, fast web framework
- **OpenCV**: Comprehensive computer vision library

## 📧 Support

For support, please:
1. Check the troubleshooting guide above
2. Review existing GitHub issues
3. Create a new issue with detailed information
4. Include system specifications and error logs

---

**Made with ❤️ for the AI and Computer Vision community**