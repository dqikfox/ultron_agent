#!/usr/bin/env python3
"""
GPU-Accelerated Vision Engine - Startup Script

This script starts the FastAPI server with all components initialized.
Optimized for Windows 11 with RTX 3050 GPU.
"""

import os
import sys
import asyncio
import logging
from pathlib import Path

# Add backend directory to Python path
backend_dir = Path(__file__).parent / "backend"
sys.path.insert(0, str(backend_dir))

# Import the main application
from main import app
import uvicorn

def setup_logging():
    """Setup logging configuration"""
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_dir / "vision_engine.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )

def check_environment():
    """Check if the environment is properly configured"""
    checks = []
    
    # Check Python version
    if sys.version_info < (3, 8):
        checks.append("❌ Python 3.8+ is required")
    else:
        checks.append("✅ Python version: OK")
    
    # Check ELEVENLABS_API_KEY
    if os.getenv("ELEVENLABS_API_KEY"):
        checks.append("✅ ElevenLabs API key: Found")
    else:
        checks.append("⚠️  ElevenLabs API key: Not found (TTS will be disabled)")
    
    # Check CUDA availability (optional)
    try:
        import cv2
        cuda_devices = cv2.cuda.getCudaEnabledDeviceCount()
        if cuda_devices > 0:
            checks.append(f"✅ CUDA devices: {cuda_devices} found")
        else:
            checks.append("⚠️  CUDA devices: None found (GPU acceleration disabled)")
    except Exception:
        checks.append("⚠️  OpenCV CUDA: Not available")
    
    # Print environment check results
    print("\n" + "="*50)
    print("GPU-Accelerated Vision Engine - Environment Check")
    print("="*50)
    for check in checks:
        print(check)
    print("="*50 + "\n")
    
    return all("❌" not in check for check in checks)

def create_directories():
    """Create necessary directories"""
    directories = [
        "logs",
        "temp/audio",
        "config",
        "frontend"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)

def print_startup_info():
    """Print startup information"""
    print("\n" + "="*60)
    print("🚀 GPU-Accelerated Vision Engine Starting...")
    print("="*60)
    print(f"📁 Working Directory: {os.getcwd()}")
    print(f"🐍 Python Version: {sys.version.split()[0]}")
    print(f"🔧 Backend: FastAPI with WebSocket support")
    print(f"🎯 Target GPU: RTX 3050 (CUDA acceleration)")
    print(f"🎙️  Voice Engine: ElevenLabs TTS + Web Speech API")
    print(f"👁️  OCR Engine: PaddleOCR with GPU acceleration")
    print(f"🤖 AI Integration: Ollama server connection")
    print("="*60)
    print("\n📋 Available Endpoints:")
    print("   🌐 Web Interface: http://localhost:8000")
    print("   🔌 WebSocket: ws://localhost:8000/ws")
    print("   📊 Health Check: http://localhost:8000/api/health")
    print("   📈 System Info: http://localhost:8000/api/system/info")
    print("="*60)
    print("\n🎮 Controls:")
    print("   • Start Camera: Click 'Start Camera' or voice command 'start ocr'")
    print("   • Voice Commands: 'read this text', 'analyze document', 'explain'")
    print("   • Push-to-Talk: Hold spacebar or mouse button on voice control")
    print("   • Settings: Click gear icon or press Ctrl+S")
    print("   • Stop Server: Press Ctrl+C")
    print("="*60 + "\n")

def main():
    """Main entry point"""
    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    try:
        # Print startup info
        print_startup_info()
        
        # Check environment
        if not check_environment():
            print("⚠️  Some environment checks failed. The application may not work optimally.")
            print("💡 Please install missing dependencies and try again.\n")
        
        # Create necessary directories
        create_directories()
        logger.info("Created necessary directories")
        
        # Set environment variables
        os.environ.setdefault("PYTHONPATH", str(backend_dir))
        
        # Configure uvicorn
        config = uvicorn.Config(
            app="main:app",
            host="0.0.0.0",
            port=8000,
            reload=False,  # Disable reload in production
            log_level="info",
            access_log=True,
            ws_ping_interval=20,
            ws_ping_timeout=20,
            lifespan="on"
        )
        
        server = uvicorn.Server(config)
        
        print("🎉 Server starting on http://localhost:8000")
        print("💻 Open this URL in your web browser to access the interface")
        print("🔄 The system will auto-initialize all components...\n")
        
        # Start the server
        server.run()
        
    except KeyboardInterrupt:
        print("\n\n🛑 Server stopped by user")
        logger.info("Server stopped by user")
    except Exception as e:
        print(f"\n❌ Error starting server: {e}")
        logger.error(f"Error starting server: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())