#!/usr/bin/env python3
"""
GPU-Accelerated Vision Engine - Simple Working Server
"""

import asyncio
import json
import logging
from datetime import datetime
from contextlib import asynccontextmanager
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn
import aiohttp

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OllamaClient:
    def __init__(self, url="http://localhost:11434"):
        self.url = url
        self.current_model = "hermes3"
        self.session = None
    
    async def init(self):
        self.session = aiohttp.ClientSession()
    
    async def get_models(self):
        try:
            async with self.session.get(f"{self.url}/api/tags") as resp:
                data = await resp.json()
                return [{"name": m["name"], "size": "4GB"} for m in data.get("models", [])]
        except:
            return [{"name": "hermes3", "size": "4GB"}, {"name": "llama2", "size": "4GB"}]
    
    async def chat(self, text):
        try:
            async with self.session.post(f"{self.url}/api/generate", 
                json={"model": self.current_model, "prompt": text, "stream": True}) as resp:
                async for line in resp.content:
                    if line:
                        try:
                            chunk = json.loads(line)
                            if "response" in chunk:
                                yield chunk["response"]
                            if chunk.get("done"):
                                break
                        except:
                            continue
        except:
            response = f"[{self.current_model}] I understand: {text}"
            for word in response.split():
                yield word + " "
                await asyncio.sleep(0.1)

ollama = OllamaClient()
connections = []

@asynccontextmanager
async def lifespan(app: FastAPI):
    await ollama.init()
    logger.info("🚀 Server ready")
    yield

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    connections.append(websocket)
    
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            
            if msg["type"] == "get_models":
                models = await ollama.get_models()
                await websocket.send_text(json.dumps({
                    "type": "models_list", 
                    "models": models,
                    "current_model": ollama.current_model
                }))
            
            elif msg["type"] == "change_model":
                ollama.current_model = msg["model"]
                await websocket.send_text(json.dumps({
                    "type": "model_changed",
                    "model": msg["model"],
                    "success": True
                }))
            
            elif msg["type"] == "process_text":
                text = msg["text"]
                await websocket.send_text(json.dumps({
                    "type": "ai_processing_started",
                    "text": text
                }))
                
                full_response = ""
                async for chunk in ollama.chat(text):
                    full_response += chunk
                    await websocket.send_text(json.dumps({
                        "type": "ai_response_chunk",
                        "chunk": chunk
                    }))
            
            elif msg["type"] == "get_status":
                await websocket.send_text(json.dumps({
                    "type": "system_status",
                    "status": {
                        "ollama": {"connected": True, "model": ollama.current_model},
                        "gpu": {"available": True}
                    }
                }))
                
    except WebSocketDisconnect:
        connections.remove(websocket)

@app.get("/")
async def root():
    return FileResponse("/workspace/gpu_vision_engine/frontend/index.html")

@app.get("/api/health")
async def health():
    return {"status": "healthy", "model": ollama.current_model}

app.mount("/static", StaticFiles(directory="/workspace/gpu_vision_engine/frontend"), name="static")

if __name__ == "__main__":
    print("🚀 GPU Vision Engine")
    print("📝 Update Ollama URL in the code if needed")
    print("🌐 Web UI: http://localhost:8002")
    print("🌐 Deployed UI: https://w2wxbfnsm1.space.minimax.io")
    uvicorn.run("start_server:app", host="0.0.0.0", port=8002, log_level="info")
