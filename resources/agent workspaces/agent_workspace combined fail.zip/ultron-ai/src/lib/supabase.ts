import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://nlljewgpwiktvxwlspnt.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sbGpld2dwd2lrdHZ4d2xzcG50Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI3MTc3NDYsImV4cCI6MjA2ODI5Mzc0Nn0.7UC869kTRPC1A61s_FuG-GeY_v86Dl4lv24Um714zPU'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface Profile {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  preferred_ai_provider: string
  voice_enabled: boolean
  theme_preference: string
  system_monitoring_enabled: boolean
  created_at: string
  updated_at: string
}

export interface Conversation {
  id: string
  user_id: string
  title: string
  ai_provider: string
  model_name: string
  message_count: number
  created_at: string
  updated_at: string
}

export interface Message {
  id: string
  conversation_id: string
  user_id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  message_type: string
  file_url?: string
  processing_time_ms?: number
  tokens_used?: number
  created_at: string
}

export interface FileUpload {
  id: string
  user_id: string
  filename: string
  file_url: string
  file_type: string
  file_size: number
  processing_status: string
  processing_result?: string
  ocr_text?: string
  ai_analysis?: string
  created_at: string
  processed_at?: string
}